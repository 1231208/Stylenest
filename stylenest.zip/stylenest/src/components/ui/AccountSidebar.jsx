import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const AccountSidebar = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [userInfo, setUserInfo] = useState({
    name: 'John Doe',
    email: 'john.doe@example.com',
    avatar: null
  });
  const location = useLocation();

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
    
    const savedUserInfo = localStorage.getItem('userInfo');
    if (savedUserInfo) {
      setUserInfo(JSON.parse(savedUserInfo));
    }
  }, []);

  const translations = {
    en: {
      myAccount: 'My Account',
      profile: 'Profile',
      orders: 'My Orders',
      addresses: 'Addresses',
      paymentMethods: 'Payment Methods',
      wishlist: 'Wishlist',
      notifications: 'Notifications',
      preferences: 'Preferences',
      security: 'Security',
      support: 'Help & Support',
      logout: 'Logout'
    },
    es: {
      myAccount: 'Mi Cuenta',
      profile: 'Perfil',
      orders: 'Mis Pedidos',
      addresses: 'Direcciones',
      paymentMethods: 'Métodos de Pago',
      wishlist: 'Lista de Deseos',
      notifications: 'Notificaciones',
      preferences: 'Preferencias',
      security: 'Seguridad',
      support: 'Ayuda y Soporte',
      logout: 'Cerrar Sesión'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const navigationItems = [
    {
      label: t.profile,
      path: '/user-account-dashboard/profile',
      icon: 'User',
      description: 'Personal information and preferences'
    },
    {
      label: t.orders,
      path: '/user-account-dashboard/orders',
      icon: 'Package',
      description: 'Order history and tracking'
    },
    {
      label: t.addresses,
      path: '/user-account-dashboard/addresses',
      icon: 'MapPin',
      description: 'Shipping and billing addresses'
    },
    {
      label: t.paymentMethods,
      path: '/user-account-dashboard/payment-methods',
      icon: 'CreditCard',
      description: 'Saved payment methods'
    },
    {
      label: t.wishlist,
      path: '/user-account-dashboard/wishlist',
      icon: 'Heart',
      description: 'Saved items and favorites'
    },
    {
      label: t.notifications,
      path: '/user-account-dashboard/notifications',
      icon: 'Bell',
      description: 'Email and push notifications'
    },
    {
      label: t.preferences,
      path: '/user-account-dashboard/preferences',
      icon: 'Settings',
      description: 'Language and display settings'
    },
    {
      label: t.security,
      path: '/user-account-dashboard/security',
      icon: 'Shield',
      description: 'Password and security settings'
    },
    {
      label: t.support,
      path: '/user-account-dashboard/support',
      icon: 'HelpCircle',
      description: 'Get help and contact support'
    }
  ];

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('userInfo');
    console.log('User logged out');
    // Navigate to home or login page
  };

  const isActivePath = (path) => {
    return location.pathname === path || location.pathname.startsWith(path + '/');
  };

  return (
    <aside className="w-full lg:w-80 bg-surface lg:bg-background border-r border-border lg:border-0 lg:rounded-premium lg:premium-shadow-sm">
      {/* User Profile Section */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center">
            {userInfo.avatar ? (
              <img
                src={userInfo.avatar}
                alt={userInfo.name}
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <Icon name="User" size={32} className="text-accent-foreground" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="font-heading font-semibold text-text-primary truncate">
              {userInfo.name}
            </h2>
            <p className="text-sm text-text-secondary truncate">
              {userInfo.email}
            </p>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="p-4">
        <h3 className="font-heading font-semibold text-text-primary mb-4 px-2">
          {t.myAccount}
        </h3>
        
        <div className="space-y-1">
          {navigationItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`
                flex items-center space-x-3 px-3 py-3 rounded-premium premium-transition group
                ${isActivePath(item.path)
                  ? 'bg-accent text-accent-foreground'
                  : 'text-text-primary hover:bg-accent hover:bg-opacity-10 hover:text-accent'
                }
              `}
            >
              <Icon 
                name={item.icon} 
                size={20} 
                className={`
                  ${isActivePath(item.path)
                    ? 'text-accent-foreground'
                    : 'text-text-secondary group-hover:text-accent'
                  }
                `}
              />
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{item.label}</div>
                <div className={`
                  text-xs truncate
                  ${isActivePath(item.path)
                    ? 'text-accent-foreground text-opacity-80'
                    : 'text-text-secondary group-hover:text-accent group-hover:text-opacity-80'
                  }
                `}>
                  {item.description}
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Logout Button */}
        <div className="mt-6 pt-4 border-t border-border">
          <button
            onClick={handleLogout}
            className="flex items-center space-x-3 w-full px-3 py-3 text-error hover:bg-error hover:bg-opacity-10 rounded-premium premium-transition group"
          >
            <Icon name="LogOut" size={20} className="text-error" />
            <span className="font-medium">{t.logout}</span>
          </button>
        </div>
      </nav>

      {/* Mobile Bottom Spacing */}
      <div className="lg:hidden h-20" />
    </aside>
  );
};

export default AccountSidebar;