import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';
import Button from './Button';
import Input from './Input';
import { getAllBrands, getAllCategories } from '../../data/products';

const FilterSidebar = ({ isOpen, onClose, onApplyFilters, brandSpecific = false }) => {
  const [filters, setFilters] = useState({
    category: [],
    brand: [],
    priceRange: { min: '', max: '' },
    size: [],
    color: [],
    rating: '',
    inStock: false,
    onSale: false
  });

  const [availableBrands, setAvailableBrands] = useState([]);
  const [availableCategories, setAvailableCategories] = useState([]);

  useEffect(() => {
    setAvailableBrands(getAllBrands());
    setAvailableCategories(getAllCategories());
  }, []);

  const sizeOptions = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '5', '6', '7', '8', '9', '10', '11', '12', 'One Size'];
  const colorOptions = ['Black', 'White', 'Gray', 'Navy', 'Brown', 'Red', 'Blue', 'Pink', 'Green', 'Yellow'];

  const handleFilterChange = (filterType, value, isChecked = null) => {
    setFilters(prev => {
      const newFilters = { ...prev };
      
      if (filterType === 'priceRange') {
        newFilters.priceRange = { ...prev.priceRange, ...value };
      } else if (filterType === 'rating') {
        newFilters.rating = value;
      } else if (filterType === 'inStock' || filterType === 'onSale') {
        newFilters[filterType] = value;
      } else if (Array.isArray(newFilters[filterType])) {
        if (isChecked) {
          newFilters[filterType] = [...prev[filterType], value];
        } else {
          newFilters[filterType] = prev[filterType].filter(item => item !== value);
        }
      }
      
      return newFilters;
    });
  };

  const handleApplyFilters = () => {
    onApplyFilters(filters);
    if (window.innerWidth < 1024) {
      onClose();
    }
  };

  const handleClearFilters = () => {
    const clearedFilters = {
      category: [],
      brand: [],
      priceRange: { min: '', max: '' },
      size: [],
      color: [],
      rating: '',
      inStock: false,
      onSale: false
    };
    setFilters(clearedFilters);
    onApplyFilters(clearedFilters);
  };

  const FilterSection = ({ title, children, isCollapsible = true }) => {
    const [isExpanded, setIsExpanded] = useState(true);

    return (
      <div className="border-b border-border pb-6 mb-6 last:border-b-0">
        <div 
          className={`flex items-center justify-between mb-4 ${isCollapsible ? 'cursor-pointer' : ''}`}
          onClick={() => isCollapsible && setIsExpanded(!isExpanded)}
        >
          <h3 className="font-heading font-semibold text-text-primary">{title}</h3>
          {isCollapsible && (
            <Icon 
              name={isExpanded ? "ChevronUp" : "ChevronDown"} 
              size={16} 
              className="text-text-secondary premium-transition"
            />
          )}
        </div>
        {(!isCollapsible || isExpanded) && children}
      </div>
    );
  };

  const CheckboxFilter = ({ options, filterType, selectedValues }) => (
    <div className="space-y-3 max-h-48 overflow-y-auto">
      {options.map((option) => (
        <label key={option} className="flex items-center space-x-3 cursor-pointer group">
          <input
            type="checkbox"
            checked={selectedValues.includes(option)}
            onChange={(e) => handleFilterChange(filterType, option, e.target.checked)}
            className="w-4 h-4 text-accent rounded border-border focus:ring-accent focus:ring-2"
          />
          <span className="text-text-primary group-hover:text-accent premium-transition">
            {option}
          </span>
        </label>
      ))}
    </div>
  );

  if (!isOpen) return null;

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed lg:static inset-y-0 left-0 z-50 w-80 bg-surface border-r border-border
        transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0
        premium-transition-long overflow-y-auto
      `}>
        <div className="p-6">
          {/* Mobile Header */}
          <div className="flex items-center justify-between mb-6 lg:hidden">
            <h2 className="font-heading font-bold text-xl text-text-primary">Filters</h2>
            <Button variant="ghost" onClick={onClose} iconName="X" />
          </div>

          {/* Desktop Header */}
          <div className="hidden lg:flex items-center justify-between mb-6">
            <h2 className="font-heading font-bold text-xl text-text-primary">Filters</h2>
            <Button variant="ghost" onClick={handleClearFilters} className="text-sm">
              Clear All
            </Button>
          </div>

          {/* Categories */}
          {!brandSpecific && (
            <FilterSection title="Category">
              <CheckboxFilter
                options={availableCategories}
                filterType="category"
                selectedValues={filters.category}
              />
            </FilterSection>
          )}

          {/* Brands */}
          {!brandSpecific && (
            <FilterSection title="Brand">
              <CheckboxFilter
                options={availableBrands}
                filterType="brand"
                selectedValues={filters.brand}
              />
            </FilterSection>
          )}

          {/* Subcategory for brand pages */}
          {brandSpecific && (
            <FilterSection title="Category">
              <CheckboxFilter
                options={['Clothing', 'Shoes', 'Beauty']}
                filterType="category"
                selectedValues={filters.category}
              />
            </FilterSection>
          )}

          {/* Price Range */}
          <FilterSection title="Price Range">
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <Input
                  type="number"
                  placeholder="Min"
                  value={filters.priceRange.min}
                  onChange={(e) => handleFilterChange('priceRange', { min: e.target.value })}
                  className="text-sm"
                />
                <Input
                  type="number"
                  placeholder="Max"
                  value={filters.priceRange.max}
                  onChange={(e) => handleFilterChange('priceRange', { max: e.target.value })}
                  className="text-sm"
                />
              </div>
              <div className="flex flex-wrap gap-2">
                {[
                  { label: 'Under $25', min: '', max: '25' },
                  { label: '$25 - $50', min: '25', max: '50' },
                  { label: '$50 - $100', min: '50', max: '100' },
                  { label: 'Over $100', min: '100', max: '' }
                ].map((range) => (
                  <button
                    key={range.label}
                    onClick={() => handleFilterChange('priceRange', { min: range.min, max: range.max })}
                    className="text-xs px-3 py-1 border border-border rounded-premium hover:border-accent hover:text-accent premium-transition"
                  >
                    {range.label}
                  </button>
                ))}
              </div>
            </div>
          </FilterSection>

          {/* Size */}
          <FilterSection title="Size">
            <div className="grid grid-cols-3 gap-2">
              {sizeOptions.map((size) => (
                <button
                  key={size}
                  onClick={() => handleFilterChange('size', size, !filters.size.includes(size))}
                  className={`
                    text-sm px-3 py-2 border rounded-premium premium-transition
                    ${filters.size.includes(size)
                      ? 'border-accent bg-accent text-accent-foreground'
                      : 'border-border hover:border-accent hover:text-accent'
                    }
                  `}
                >
                  {size}
                </button>
              ))}
            </div>
          </FilterSection>

          {/* Color */}
          <FilterSection title="Color">
            <div className="grid grid-cols-5 gap-2">
              {colorOptions.map((color) => (
                <button
                  key={color}
                  onClick={() => handleFilterChange('color', color, !filters.color.includes(color))}
                  className={`
                    w-8 h-8 rounded-full border-2 premium-transition
                    ${filters.color.includes(color)
                      ? 'border-accent ring-2 ring-accent ring-opacity-50' :'border-border hover:border-accent'
                    }
                  `}
                  style={{ backgroundColor: color.toLowerCase() }}
                  title={color}
                />
              ))}
            </div>
          </FilterSection>

          {/* Rating */}
          <FilterSection title="Customer Rating">
            <div className="space-y-2">
              {[4, 3, 2, 1].map((rating) => (
                <label key={rating} className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="rating"
                    checked={filters.rating === rating}
                    onChange={() => handleFilterChange('rating', rating)}
                    className="w-4 h-4 text-accent"
                  />
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Icon
                        key={i}
                        name="Star"
                        size={12}
                        className={i < rating ? 'text-accent fill-current' : 'text-border'}
                      />
                    ))}
                    <span className="text-sm text-text-secondary">& up</span>
                  </div>
                </label>
              ))}
            </div>
          </FilterSection>

          {/* Additional Filters */}
          <FilterSection title="Availability & Offers">
            <div className="space-y-3">
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={filters.inStock}
                  onChange={(e) => handleFilterChange('inStock', e.target.checked)}
                  className="w-4 h-4 text-accent rounded border-border"
                />
                <span className="text-text-primary">In Stock Only</span>
              </label>
              
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={filters.onSale}
                  onChange={(e) => handleFilterChange('onSale', e.target.checked)}
                  className="w-4 h-4 text-accent rounded border-border"
                />
                <span className="text-text-primary">On Sale</span>
              </label>
            </div>
          </FilterSection>

          {/* Apply Button (Mobile) */}
          <div className="lg:hidden">
            <Button
              variant="primary"
              onClick={handleApplyFilters}
              className="w-full"
            >
              Apply Filters
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default FilterSidebar;