import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';
import Input from './Input';

const GlobalHeader = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [cartCount, setCartCount] = useState(0);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const location = useLocation();

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
    
    const savedCartCount = localStorage.getItem('cartCount') || '0';
    setCartCount(parseInt(savedCartCount));
    
    const authStatus = localStorage.getItem('isAuthenticated') === 'true';
    setIsAuthenticated(authStatus);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const toggleSearch = () => {
    setIsSearchOpen(!isSearchOpen);
    if (isSearchOpen) {
      setSearchQuery('');
    }
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      console.log('Search query:', searchQuery);
      // Navigate to search results
    }
  };

  const handleCartClick = () => {
    // Navigate to cart
    console.log('Navigate to cart');
  };

  const handleAccountClick = () => {
    if (isAuthenticated) {
      // Navigate to account dashboard
      console.log('Navigate to account');
    } else {
      // Navigate to login
      console.log('Navigate to login');
    }
  };

  const translations = {
    en: {
      search: 'Search products...',
      women: 'Women',
      men: 'Men',
      children: 'Children',
      beauty: 'Beauty',
      brands: 'Brands',
      sale: 'Sale',
      account: 'Account',
      cart: 'Cart',
      menu: 'Menu'
    },
    es: {
      search: 'Buscar productos...',
      women: 'Mujeres',
      men: 'Hombres',
      children: 'Niños',
      beauty: 'Belleza',
      brands: 'Marcas',
      sale: 'Ofertas',
      account: 'Cuenta',
      cart: 'Carrito',
      menu: 'Menú'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const navigationItems = [
    { label: t.women, path: '/product-catalog-browse?category=women', icon: 'User' },
    { label: t.men, path: '/product-catalog-browse?category=men', icon: 'User' },
    { label: t.children, path: '/product-catalog-browse?category=children', icon: 'Baby' },
    { label: t.beauty, path: '/product-catalog-browse?category=beauty', icon: 'Sparkles' },
    { label: t.brands, path: '/brand-collection-pages', icon: 'Star' },
    { label: t.sale, path: '/product-catalog-browse?sale=true', icon: 'Tag' }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 bg-background border-b border-border z-navigation">
      <div className="max-w-screen-2xl mx-auto px-5 lg:px-8">
        {/* Main Header */}
        <div className="flex items-center justify-between h-16 lg:h-18">
          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="lg:hidden p-2 -ml-2 text-text-primary hover:text-accent premium-transition"
            aria-label={t.menu}
          >
            <Icon name={isMenuOpen ? "X" : "Menu"} size={24} />
          </button>

          {/* Logo */}
          <Link 
            to="/home-landing-page" 
            className="flex items-center space-x-2 text-primary hover:text-accent premium-transition"
          >
            <div className="w-8 h-8 bg-primary rounded-premium flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">SN</span>
            </div>
            <span className="font-heading font-bold text-xl hidden sm:block">StyleNest</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navigationItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`text-sm font-medium premium-transition hover:text-accent ${
                  location.pathname === item.path ? 'text-accent' : 'text-text-primary'
                }`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Search Bar - Desktop */}
          <div className="hidden lg:flex flex-1 max-w-md mx-8">
            <form onSubmit={handleSearchSubmit} className="w-full relative">
              <Input
                type="search"
                placeholder={t.search}
                value={searchQuery}
                onChange={handleSearchChange}
                className="w-full pl-10 pr-4 py-2 bg-surface border-border rounded-premium focus:ring-2 focus:ring-accent focus:border-accent"
              />
              <Icon 
                name="Search" 
                size={20} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary" 
              />
            </form>
          </div>

          {/* Right Actions */}
          <div className="flex items-center space-x-2 lg:space-x-4">
            {/* Mobile Search Button */}
            <button
              onClick={toggleSearch}
              className="lg:hidden p-2 text-text-primary hover:text-accent premium-transition"
              aria-label="Search"
            >
              <Icon name="Search" size={24} />
            </button>

            {/* Account */}
            <button
              onClick={handleAccountClick}
              className="p-2 text-text-primary hover:text-accent premium-transition"
              aria-label={t.account}
            >
              <Icon name="User" size={24} />
            </button>

            {/* Cart */}
            <button
              onClick={handleCartClick}
              className="relative p-2 text-text-primary hover:text-accent premium-transition"
              aria-label={t.cart}
            >
              <Icon name="ShoppingBag" size={24} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-accent text-accent-foreground text-xs font-medium rounded-full w-5 h-5 flex items-center justify-center">
                  {cartCount > 99 ? '99+' : cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Search Bar */}
        {isSearchOpen && (
          <div className="lg:hidden py-4 border-t border-border animate-slide-down">
            <form onSubmit={handleSearchSubmit} className="relative">
              <Input
                type="search"
                placeholder={t.search}
                value={searchQuery}
                onChange={handleSearchChange}
                className="w-full pl-10 pr-4 py-3 bg-surface border-border rounded-premium focus:ring-2 focus:ring-accent focus:border-accent"
                autoFocus
              />
              <Icon 
                name="Search" 
                size={20} 
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-secondary" 
              />
            </form>
          </div>
        )}
      </div>

      {/* Mobile Menu Overlay */}
      {isMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-16 bg-background z-navigation-menu animate-fade-in">
          <nav className="px-5 py-6 space-y-6">
            {navigationItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsMenuOpen(false)}
                className={`flex items-center space-x-3 text-lg font-medium premium-transition hover:text-accent ${
                  location.pathname === item.path ? 'text-accent' : 'text-text-primary'
                }`}
              >
                <Icon name={item.icon} size={24} />
                <span>{item.label}</span>
              </Link>
            ))}
            
            <div className="pt-6 border-t border-border">
              <Link
                to="/user-account-dashboard"
                onClick={() => setIsMenuOpen(false)}
                className="flex items-center space-x-3 text-lg font-medium text-text-primary hover:text-accent premium-transition"
              >
                <Icon name="User" size={24} />
                <span>{t.account}</span>
              </Link>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default GlobalHeader;