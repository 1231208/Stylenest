// Comprehensive product database with 500+ items
const productDatabase = [
  // CLOTHING - WOMEN
  {
    id: 1,
    name: "Premium Cotton Blend T-Shirt",
    brand: "Nike",
    price: 29.99,
    originalPrice: 39.99,
    images: [
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400",
      "https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=400"
    ],
    category: "Women",
    subcategory: "Clothing",
    type: "T-Shirt",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black", "White", "Gray", "Navy"],
    rating: 4.5,
    reviewCount: 128,
    inStock: true,
    isOnSale: true,
    isNew: false,
    description: "Comfortable cotton blend t-shirt perfect for everyday wear"
  },
  {
    id: 2,
    name: "Classic Denim Jacket",
    brand: "Zara",
    price: 89.99,
    images: [
      "https://images.unsplash.com/photo-1544966503-7cc5ac882d5f?w=400",
      "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400"
    ],
    category: "Women",
    subcategory: "Clothing",
    type: "Jacket",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Blue", "Black"],
    rating: 4.2,
    reviewCount: 89,
    inStock: true,
    isOnSale: false,
    isNew: true,
    description: "Timeless denim jacket with classic fit"
  },
  {
    id: 3,
    name: "Floral Summer Dress",
    brand: "H&M",
    price: 59.99,
    images: [
      "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=400"
    ],
    category: "Women",
    subcategory: "Clothing",
    type: "Dress",
    sizes: ["XS", "S", "M", "L"],
    colors: ["Floral", "White"],
    rating: 4.4,
    reviewCount: 91,
    inStock: true,
    isOnSale: false,
    isNew: false,
    description: "Beautiful floral dress perfect for summer occasions"
  },
  {
    id: 4,
    name: "Professional Blazer",
    brand: "Zara",
    price: 129.99,
    originalPrice: 159.99,
    images: [
      "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=400"
    ],
    category: "Women",
    subcategory: "Clothing",
    type: "Blazer",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black", "Navy", "Gray"],
    rating: 4.7,
    reviewCount: 156,
    inStock: true,
    isOnSale: true,
    isNew: false,
    description: "Professional blazer for business and formal occasions"
  },
  {
    id: 5,
    name: "Silk Evening Gown",
    brand: "Gucci",
    price: 899.99,
    images: [
      "https://images.unsplash.com/photo-1566479179817-c0b0c5c8b7d4?w=400"
    ],
    category: "Women",
    subcategory: "Clothing",
    type: "Dress",
    sizes: ["XS", "S", "M", "L"],
    colors: ["Black", "Red", "Navy"],
    rating: 4.9,
    reviewCount: 67,
    inStock: true,
    isOnSale: false,
    isNew: true,
    description: "Luxury silk evening gown for special occasions"
  },

  // CLOTHING - MEN
  {
    id: 50,
    name: "Classic Oxford Shirt",
    brand: "Ralph Lauren",
    price: 79.99,
    images: [
      "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400"
    ],
    category: "Men",
    subcategory: "Clothing",
    type: "Shirt",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["White", "Blue", "Pink"],
    rating: 4.6,
    reviewCount: 203,
    inStock: true,
    isOnSale: false,
    isNew: false,
    description: "Classic Oxford shirt for professional and casual wear"
  },
  {
    id: 51,
    name: "Slim Fit Jeans",
    brand: "Levi\'s",
    price: 89.99,
    originalPrice: 109.99,
    images: [
      "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400"
    ],
    category: "Men",
    subcategory: "Clothing",
    type: "Jeans",
    sizes: ["30", "32", "34", "36", "38"],
    colors: ["Blue", "Black", "Gray"],
    rating: 4.5,
    reviewCount: 445,
    inStock: true,
    isOnSale: true,
    isNew: false,
    description: "Premium slim fit jeans with comfort stretch"
  },
  {
    id: 52,
    name: "Wool Blend Suit",
    brand: "Hugo Boss",
    price: 599.99,
    images: [
      "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=400"
    ],
    category: "Men",
    subcategory: "Clothing",
    type: "Suit",
    sizes: ["38", "40", "42", "44", "46"],
    colors: ["Black", "Navy", "Gray"],
    rating: 4.8,
    reviewCount: 89,
    inStock: true,
    isOnSale: false,
    isNew: true,
    description: "Premium wool blend suit for formal occasions"
  },

  // SHOES - WOMEN
  {
    id: 100,
    name: "Classic High Heels",
    brand: "Jimmy Choo",
    price: 695.00,
    images: [
      "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=400"
    ],
    category: "Women",
    subcategory: "Shoes",
    type: "Heels",
    sizes: ["5", "6", "7", "8", "9", "10"],
    colors: ["Black", "Red", "Nude"],
    rating: 4.7,
    reviewCount: 234,
    inStock: true,
    isOnSale: false,
    isNew: false,
    description: "Elegant high heels perfect for formal events"
  },
  {
    id: 101,
    name: "Comfortable Sneakers",
    brand: "Adidas",
    price: 89.99,
    originalPrice: 119.99,
    images: [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400"
    ],
    category: "Women",
    subcategory: "Shoes",
    type: "Sneakers",
    sizes: ["5", "6", "7", "8", "9", "10"],
    colors: ["White", "Black", "Pink"],
    rating: 4.5,
    reviewCount: 567,
    inStock: true,
    isOnSale: true,
    isNew: false,
    description: "Comfortable sneakers for daily activities"
  },
  {
    id: 102,
    name: "Ankle Boots",
    brand: "Zara",
    price: 79.99,
    images: [
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400"
    ],
    category: "Women",
    subcategory: "Shoes",
    type: "Boots",
    sizes: ["5", "6", "7", "8", "9", "10"],
    colors: ["Black", "Brown", "Tan"],
    rating: 4.3,
    reviewCount: 178,
    inStock: true,
    isOnSale: false,
    isNew: true,
    description: "Stylish ankle boots for versatile styling"
  },

  // SHOES - MEN
  {
    id: 150,
    name: "Formal Oxford Shoes",
    brand: "Cole Haan",
    price: 249.99,
    images: [
      "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=400"
    ],
    category: "Men",
    subcategory: "Shoes",
    type: "Formal",
    sizes: ["7", "8", "9", "10", "11", "12"],
    colors: ["Black", "Brown"],
    rating: 4.6,
    reviewCount: 189,
    inStock: true,
    isOnSale: false,
    isNew: false,
    description: "Classic Oxford shoes for business and formal wear"
  },
  {
    id: 151,
    name: "Athletic Running Shoes",
    brand: "Nike",
    price: 129.99,
    originalPrice: 159.99,
    images: [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400",
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=400"
    ],
    category: "Men",
    subcategory: "Shoes",
    type: "Athletic",
    sizes: ["7", "8", "9", "10", "11", "12"],
    colors: ["Black", "White", "Red"],
    rating: 4.7,
    reviewCount: 256,
    inStock: true,
    isOnSale: true,
    isNew: false,
    description: "High-performance running shoes for athletes"
  },

  // BEAUTY PRODUCTS
  {
    id: 200,
    name: "Matte Lipstick Set",
    brand: "MAC",
    price: 89.99,
    originalPrice: 109.99,
    images: [
      "https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=400"
    ],
    category: "Beauty",
    subcategory: "Makeup",
    type: "Lipstick",
    sizes: ["One Size"],
    colors: ["Red", "Pink", "Nude", "Berry"],
    rating: 4.6,
    reviewCount: 134,
    inStock: true,
    isOnSale: true,
    isNew: false,
    description: "Long-lasting matte lipstick collection"
  },
  {
    id: 201,
    name: "Foundation Palette",
    brand: "Fenty Beauty",
    price: 54.99,
    images: [
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400"
    ],
    category: "Beauty",
    subcategory: "Makeup",
    type: "Foundation",
    sizes: ["One Size"],
    colors: ["Light", "Medium", "Dark"],
    rating: 4.8,
    reviewCount: 267,
    inStock: true,
    isOnSale: false,
    isNew: true,
    description: "Full coverage foundation for all skin tones"
  },
  {
    id: 202,
    name: "Luxury Perfume",
    brand: "Chanel",
    price: 198.99,
    images: [
      "https://images.unsplash.com/photo-1541643600914-78b084683601?w=400"
    ],
    category: "Beauty",
    subcategory: "Fragrance",
    type: "Perfume",
    sizes: ["50ml", "100ml"],
    colors: ["Gold"],
    rating: 4.9,
    reviewCount: 445,
    inStock: true,
    isOnSale: false,
    isNew: false,
    description: "Iconic luxury fragrance with timeless appeal"
  },
  {
    id: 203,
    name: "Anti-Aging Serum",
    brand: "Estée Lauder",
    price: 124.99,
    images: [
      "https://images.unsplash.com/photo-1570194065650-d99fb4bedf0a?w=400"
    ],
    category: "Beauty",
    subcategory: "Skincare",
    type: "Serum",
    sizes: ["30ml"],
    colors: ["Clear"],
    rating: 4.7,
    reviewCount: 356,
    inStock: true,
    isOnSale: false,
    isNew: true,
    description: "Advanced anti-aging serum with peptides"
  }
];

// Generate additional products to reach 500+ items
const generateAdditionalProducts = () => {
  const additionalProducts = [];
  const baseProducts = productDatabase;
  
  // Categories and their variations
  const variations = {
    Women: {
      Clothing: ['Dress', 'Blouse', 'Skirt', 'Pants', 'Sweater', 'Cardigan', 'Jumpsuit'],
      Shoes: ['Heels', 'Flats', 'Sneakers', 'Boots', 'Sandals'],
    },
    Men: {
      Clothing: ['Shirt', 'T-Shirt', 'Pants', 'Jeans', 'Suit', 'Jacket', 'Sweater'],
      Shoes: ['Formal', 'Casual', 'Athletic', 'Boots'],
    },
    Beauty: {
      Makeup: ['Lipstick', 'Foundation', 'Eyeshadow', 'Mascara', 'Blush'],
      Skincare: ['Cleanser', 'Moisturizer', 'Serum', 'Sunscreen'],
      Fragrance: ['Perfume', 'Cologne', 'Body Spray']
    }
  };

  const brands = {
    Women: ['Zara', 'H&M', 'Mango', 'Uniqlo', 'Forever21', 'Topshop', 'ASOS'],
    Men: ['Nike', 'Adidas', 'Ralph Lauren', 'Tommy Hilfiger', 'Calvin Klein', 'Hugo Boss'],
    Beauty: ['MAC', 'Sephora', 'Urban Decay', 'Too Faced', 'NARS', 'Charlotte Tilbury']
  };

  let currentId = 300;

  Object.keys(variations).forEach(category => {
    Object.keys(variations[category]).forEach(subcategory => {
      variations[category][subcategory].forEach(type => {
        for (let i = 0; i < 15; i++) { // 15 products per type
          const brand = brands[category][Math.floor(Math.random() * brands[category].length)];
          const basePrice = Math.floor(Math.random() * 300) + 20;
          const isOnSale = Math.random() > 0.7;
          const originalPrice = isOnSale ? basePrice + Math.floor(Math.random() * 50) + 10 : null;
          
          additionalProducts.push({
            id: currentId++,
            name: `${type} ${String.fromCharCode(65 + (i % 26))} - ${brand}`,
            brand: brand,
            price: basePrice,
            originalPrice: originalPrice,
            images: [
              `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 100000000)}?w=400`,
              `https://images.unsplash.com/photo-${1500000000000 + Math.floor(Math.random() * 100000000)}?w=400`
            ],
            category: category,
            subcategory: subcategory,
            type: type,
            sizes: category === 'Beauty' ? ['One Size'] : 
                   category === 'Men' ? ['S', 'M', 'L', 'XL', 'XXL'] : 
                   ['XS', 'S', 'M', 'L', 'XL'],
            colors: ['Black', 'White', 'Gray', 'Navy', 'Brown'].slice(0, Math.floor(Math.random() * 3) + 2),
            rating: Math.round((Math.random() * 2 + 3) * 10) / 10, // 3.0 to 5.0
            reviewCount: Math.floor(Math.random() * 500) + 10,
            inStock: Math.random() > 0.1, // 90% in stock
            isOnSale: isOnSale,
            isNew: Math.random() > 0.8, // 20% new
            description: `Premium ${type.toLowerCase()} from ${brand} collection`
          });
        }
      });
    });
  });

  return additionalProducts;
};

const allProducts = [...productDatabase, ...generateAdditionalProducts()];

export default allProducts;

// Helper functions for filtering and searching
export const getProductsByCategory = (category) => {
  return allProducts.filter(product => product.category === category);
};

export const getProductsByBrand = (brand) => {
  return allProducts.filter(product => product.brand === brand);
};

export const getProductsBySubcategory = (subcategory) => {
  return allProducts.filter(product => product.subcategory === subcategory);
};

export const getAllBrands = () => {
  const brands = new Set(allProducts.map(product => product.brand));
  return Array.from(brands).sort();
};

export const getAllCategories = () => {
  const categories = new Set(allProducts.map(product => product.category));
  return Array.from(categories).sort();
};

export const getProductById = (id) => {
  return allProducts.find(product => product.id === parseInt(id));
};