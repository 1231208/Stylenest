import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import GlobalHeader from '../../components/ui/GlobalHeader';
import FilterSidebar from '../../components/ui/FilterSidebar';
import ProductGrid from '../product-catalog-browse/components/ProductGrid';
import SortDropdown from '../product-catalog-browse/components/SortDropdown';
import QuickAddModal from '../product-catalog-browse/components/QuickAddModal';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import { getProductsByBrand } from '../../data/products';

const BrandPage = () => {
  const { brandName } = useParams();
  const [searchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [isFilterSidebarOpen, setIsFilterSidebarOpen] = useState(false);
  const [isQuickAddModalOpen, setIsQuickAddModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [currentSort, setCurrentSort] = useState('relevance');
  const [isLoading, setIsLoading] = useState(false);
  const [wishlistedProducts, setWishlistedProducts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  const [filters, setFilters] = useState({
    category: [],
    subcategory: [],
    priceRange: { min: '', max: '' },
    size: [],
    color: [],
    rating: '',
    inStock: false,
    onSale: false
  });

  // Load brand products
  useEffect(() => {
    if (brandName) {
      const decodedBrandName = decodeURIComponent(brandName);
      const brandProducts = getProductsByBrand(decodedBrandName);
      setProducts(brandProducts);
      
      // Apply URL parameters
      const category = searchParams.get('category');
      if (category) {
        setFilters(prev => ({
          ...prev,
          category: [category.charAt(0).toUpperCase() + category.slice(1)]
        }));
      }
    }

    // Load wishlist from localStorage
    const savedWishlist = localStorage.getItem('wishlist');
    if (savedWishlist) {
      setWishlistedProducts(JSON.parse(savedWishlist));
    }
  }, [brandName, searchParams]);

  // Filter and sort products
  useEffect(() => {
    let filtered = [...products];

    // Apply filters
    if (filters.category.length > 0) {
      filtered = filtered.filter(product => 
        filters.category.includes(product.category)
      );
    }

    if (filters.subcategory.length > 0) {
      filtered = filtered.filter(product => 
        filters.subcategory.includes(product.subcategory)
      );
    }

    if (filters.size.length > 0) {
      filtered = filtered.filter(product => 
        product.sizes?.some(size => filters.size.includes(size))
      );
    }

    if (filters.color.length > 0) {
      filtered = filtered.filter(product => 
        product.colors?.some(color => filters.color.includes(color))
      );
    }

    if (filters.priceRange.min || filters.priceRange.max) {
      const min = parseFloat(filters.priceRange.min) || 0;
      const max = parseFloat(filters.priceRange.max) || Infinity;
      filtered = filtered.filter(product => 
        product.price >= min && product.price <= max
      );
    }

    if (filters.rating) {
      filtered = filtered.filter(product => 
        product.rating >= filters.rating
      );
    }

    if (filters.inStock) {
      filtered = filtered.filter(product => product.inStock);
    }

    if (filters.onSale) {
      filtered = filtered.filter(product => product.isOnSale);
    }

    // Apply sorting
    switch (currentSort) {
      case 'price-low-high':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high-low':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      case 'newest':
        filtered.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
        break;
      case 'popularity':
        filtered.sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0));
        break;
      case 'name-a-z':
        filtered.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'name-z-a':
        filtered.sort((a, b) => b.name.localeCompare(a.name));
        break;
      default:
        break;
    }

    setFilteredProducts(filtered);
    setCurrentPage(1);
    setHasMore(filtered.length > 24);
  }, [products, filters, currentSort]);

  const handleApplyFilters = (newFilters) => {
    setFilters(newFilters);
  };

  const handleQuickAdd = (product) => {
    setSelectedProduct(product);
    setIsQuickAddModalOpen(true);
  };

  const handleAddToCart = (cartItem) => {
    const existingCart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existingItemIndex = existingCart.findIndex(item => 
      item.id === cartItem.id && 
      item.size === cartItem.size && 
      item.color === cartItem.color
    );

    if (existingItemIndex > -1) {
      existingCart[existingItemIndex].quantity += cartItem.quantity;
    } else {
      existingCart.push(cartItem);
    }

    localStorage.setItem('cart', JSON.stringify(existingCart));
    const totalItems = existingCart.reduce((sum, item) => sum + item.quantity, 0);
    localStorage.setItem('cartCount', totalItems.toString());
  };

  const handleToggleWishlist = (productId) => {
    setWishlistedProducts(prev => {
      const newWishlist = prev.includes(productId)
        ? prev.filter(id => id !== productId)
        : [...prev, productId];
      
      localStorage.setItem('wishlist', JSON.stringify(newWishlist));
      return newWishlist;
    });
  };

  const handleLoadMore = () => {
    setIsLoading(true);
    setTimeout(() => {
      setCurrentPage(prev => prev + 1);
      setIsLoading(false);
      
      if (currentPage >= 3) {
        setHasMore(false);
      }
    }, 1000);
  };

  const displayedProducts = filteredProducts.slice(0, currentPage * 24);
  const decodedBrandName = brandName ? decodeURIComponent(brandName) : '';

  return (
    <>
      <Helmet>
        <title>{decodedBrandName} - StyleNest</title>
        <meta name="description" content={`Shop ${decodedBrandName} collection at StyleNest. Premium fashion and beauty products.`} />
      </Helmet>

      <div className="min-h-screen bg-background">
        <GlobalHeader />
        
        <main className="pt-16 lg:pt-18">
          {/* Brand Header */}
          <div className="bg-surface border-b border-border">
            <div className="max-w-screen-2xl mx-auto px-5 lg:px-8 py-8">
              <div className="text-center">
                <h1 className="font-heading font-bold text-4xl text-text-primary mb-4">
                  {decodedBrandName}
                </h1>
                <p className="text-text-secondary text-lg max-w-2xl mx-auto">
                  Discover the complete {decodedBrandName} collection featuring clothing, shoes, and beauty products
                </p>
                <div className="flex items-center justify-center space-x-4 mt-6">
                  <div className="flex items-center space-x-2 text-sm text-text-secondary">
                    <Icon name="Package" size={16} />
                    <span>{products.length} Products</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-text-secondary">
                    <Icon name="Truck" size={16} />
                    <span>Free Shipping</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-text-secondary">
                    <Icon name="ShieldCheck" size={16} />
                    <span>Authentic Products</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="max-w-screen-2xl mx-auto px-5 lg:px-8 py-6">
            <div className="flex gap-8">
              {/* Desktop Filter Sidebar */}
              <div className="hidden lg:block w-80 flex-shrink-0">
                <div className="sticky top-24">
                  <FilterSidebar
                    isOpen={true}
                    onClose={() => {}}
                    onApplyFilters={handleApplyFilters}
                    brandSpecific={true}
                  />
                </div>
              </div>

              {/* Main Content */}
              <div className="flex-1 min-w-0">
                {/* Mobile Controls */}
                <div className="flex items-center justify-between mb-6 lg:hidden">
                  <Button
                    variant="outline"
                    onClick={() => setIsFilterSidebarOpen(true)}
                    iconName="Filter"
                    iconPosition="left"
                  >
                    Filters
                  </Button>
                  
                  <SortDropdown
                    currentSort={currentSort}
                    onSortChange={setCurrentSort}
                  />
                </div>

                {/* Desktop Sort */}
                <div className="hidden lg:flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <h2 className="font-heading font-bold text-2xl text-text-primary">
                      All Products
                    </h2>
                    <span className="text-text-secondary">
                      ({filteredProducts.length} items)
                    </span>
                  </div>
                  
                  <SortDropdown
                    currentSort={currentSort}
                    onSortChange={setCurrentSort}
                  />
                </div>

                {/* Category Quick Filters */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {['All', 'Clothing', 'Shoes', 'Beauty'].map(category => (
                    <Button
                      key={category}
                      variant={filters.category.includes(category) || (category === 'All' && filters.category.length === 0) ? 'primary' : 'outline'}
                      onClick={() => {
                        if (category === 'All') {
                          setFilters(prev => ({ ...prev, category: [] }));
                        } else {
                          setFilters(prev => ({ 
                            ...prev, 
                            category: prev.category.includes(category) 
                              ? prev.category.filter(c => c !== category)
                              : [...prev.category, category]
                          }));
                        }
                      }}
                      className="text-sm"
                    >
                      {category}
                    </Button>
                  ))}
                </div>

                {/* Product Grid */}
                <ProductGrid
                  products={displayedProducts}
                  onQuickAdd={handleQuickAdd}
                  onToggleWishlist={handleToggleWishlist}
                  wishlistedProducts={wishlistedProducts}
                  isLoading={isLoading}
                  hasMore={hasMore}
                  onLoadMore={handleLoadMore}
                />
              </div>
            </div>
          </div>
        </main>

        {/* Mobile Filter Sidebar */}
        <FilterSidebar
          isOpen={isFilterSidebarOpen}
          onClose={() => setIsFilterSidebarOpen(false)}
          onApplyFilters={handleApplyFilters}
          brandSpecific={true}
        />

        {/* Quick Add Modal */}
        <QuickAddModal
          isOpen={isQuickAddModalOpen}
          onClose={() => setIsQuickAddModalOpen(false)}
          product={selectedProduct}
          onAddToCart={handleAddToCart}
        />
      </div>
    </>
  );
};

export default BrandPage;