import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import GlobalHeader from '../../components/ui/GlobalHeader';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Icon from '../../components/AppIcon';

const Checkout = () => {
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('cod'); // 'cod' or 'upi'
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');

  const [shippingAddress, setShippingAddress] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    pinCode: '',
    country: 'India'
  });

  const [addressErrors, setAddressErrors] = useState({});

  useEffect(() => {
    // Load cart items
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
      setCartItems(JSON.parse(savedCart));
    } else {
      // Redirect to cart if no items
      navigate('/shopping-cart');
    }
  }, [navigate]);

  const validateAddress = () => {
    const errors = {};
    
    if (!shippingAddress.fullName.trim()) {
      errors.fullName = 'Full name is required';
    }
    
    if (!shippingAddress.email.trim()) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(shippingAddress.email)) {
      errors.email = 'Email is invalid';
    }
    
    if (!shippingAddress.phone.trim()) {
      errors.phone = 'Phone number is required';
    } else if (!/^\d{10}$/.test(shippingAddress.phone.replace(/\D/g, ''))) {
      errors.phone = 'Phone number must be 10 digits';
    }
    
    if (!shippingAddress.address.trim()) {
      errors.address = 'Address is required';
    }
    
    if (!shippingAddress.city.trim()) {
      errors.city = 'City is required';
    }
    
    if (!shippingAddress.state.trim()) {
      errors.state = 'State is required';
    }
    
    if (!shippingAddress.pinCode.trim()) {
      errors.pinCode = 'PIN code is required';
    } else if (!/^\d{6}$/.test(shippingAddress.pinCode)) {
      errors.pinCode = 'PIN code must be 6 digits';
    }

    setAddressErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleAddressChange = (field, value) => {
    setShippingAddress(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error for this field
    if (addressErrors[field]) {
      setAddressErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const calculateTotals = () => {
    const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const shipping = 0; // Free shipping as per requirement
    const tax = subtotal * 0.08; // 8% tax
    const total = subtotal + shipping + tax;
    
    return { subtotal, shipping, tax, total };
  };

  const generateOrderNumber = () => {
    return 'SN' + Date.now().toString().slice(-8) + Math.floor(Math.random() * 100);
  };

  const handleUPIPayment = () => {
    const { total } = calculateTotals();
    const upiId = '8134007404@ybl';
    const amount = total.toFixed(2);
    const orderRef = generateOrderNumber();
    
    // Create UPI payment URL
    const upiUrl = `upi://pay?pa=${upiId}&pn=StyleNest&am=${amount}&cu=INR&tn=StyleNest Order ${orderRef}`;
    
    // Try to open UPI app
    const link = document.createElement('a');
    link.href = upiUrl;
    link.click();
    
    // Show order confirmation after payment attempt
    setTimeout(() => {
      setOrderNumber(orderRef);
      setOrderPlaced(true);
      localStorage.removeItem('cart');
      localStorage.setItem('cartCount', '0');
    }, 3000);
  };

  const handleCODOrder = () => {
    if (!validateAddress()) {
      return;
    }

    setIsProcessing(true);
    
    // Simulate order processing
    setTimeout(() => {
      const orderRef = generateOrderNumber();
      setOrderNumber(orderRef);
      setOrderPlaced(true);
      setIsProcessing(false);
      
      // Clear cart
      localStorage.removeItem('cart');
      localStorage.setItem('cartCount', '0');
    }, 2000);
  };

  const handlePlaceOrder = () => {
    if (!validateAddress()) {
      return;
    }

    if (paymentMethod === 'upi') {
      handleUPIPayment();
    } else {
      handleCODOrder();
    }
  };

  const { subtotal, shipping, tax, total } = calculateTotals();

  if (orderPlaced) {
    return (
      <>
        <Helmet>
          <title>Order Confirmed - StyleNest</title>
        </Helmet>
        
        <div className="min-h-screen bg-background">
          <GlobalHeader />
          
          <main className="pt-20 pb-12">
            <div className="max-w-2xl mx-auto px-5 lg:px-8 text-center">
              <div className="bg-surface rounded-premium p-8 premium-shadow-sm">
                <div className="w-20 h-20 bg-success bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Icon name="CheckCircle" size={40} className="text-success" />
                </div>
                
                <h1 className="font-heading font-bold text-3xl text-text-primary mb-4">
                  Order Placed Successfully!
                </h1>
                
                <p className="text-text-secondary mb-6">
                  Thank you for your purchase. Your order has been confirmed and will be processed shortly.
                </p>
                
                <div className="bg-background border border-border rounded-premium p-4 mb-6">
                  <p className="text-sm text-text-secondary mb-2">Order Number</p>
                  <p className="font-heading font-bold text-xl text-text-primary">{orderNumber}</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                  <div className="text-center">
                    <Icon name="Package" size={24} className="text-accent mx-auto mb-2" />
                    <p className="text-sm font-medium text-text-primary">Processing</p>
                    <p className="text-xs text-text-secondary">1-2 business days</p>
                  </div>
                  <div className="text-center">
                    <Icon name="Truck" size={24} className="text-accent mx-auto mb-2" />
                    <p className="text-sm font-medium text-text-primary">Shipping</p>
                    <p className="text-xs text-text-secondary">Free delivery</p>
                  </div>
                  <div className="text-center">
                    <Icon name="Home" size={24} className="text-accent mx-auto mb-2" />
                    <p className="text-sm font-medium text-text-primary">Delivery</p>
                    <p className="text-xs text-text-secondary">6-7 days</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <Button
                    variant="primary"
                    onClick={() => navigate('/user-account-dashboard')}
                    className="w-full"
                  >
                    Track Your Order
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={() => navigate('/')}
                    className="w-full"
                  >
                    Continue Shopping
                  </Button>
                </div>
              </div>
            </div>
          </main>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Checkout - StyleNest</title>
        <meta name="description" content="Complete your StyleNest purchase with secure checkout" />
      </Helmet>
      
      <div className="min-h-screen bg-background">
        <GlobalHeader />
        
        <main className="pt-20 pb-12">
          <div className="max-w-6xl mx-auto px-5 lg:px-8">
            <h1 className="font-heading font-bold text-3xl text-text-primary mb-8">
              Checkout
            </h1>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Shipping Address */}
              <div className="lg:col-span-2">
                <div className="bg-surface border border-border rounded-premium p-6 mb-6">
                  <h2 className="font-heading font-bold text-xl text-text-primary mb-6">
                    Shipping Address
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2">
                      <Input
                        label="Full Name *"
                        value={shippingAddress.fullName}
                        onChange={(e) => handleAddressChange('fullName', e.target.value)}
                        error={addressErrors.fullName}
                        placeholder="Enter your full name"
                      />
                    </div>
                    
                    <Input
                      label="Email Address *"
                      type="email"
                      value={shippingAddress.email}
                      onChange={(e) => handleAddressChange('email', e.target.value)}
                      error={addressErrors.email}
                      placeholder="Enter your email"
                    />
                    
                    <Input
                      label="Phone Number *"
                      type="tel"
                      value={shippingAddress.phone}
                      onChange={(e) => handleAddressChange('phone', e.target.value)}
                      error={addressErrors.phone}
                      placeholder="Enter your phone number"
                    />
                    
                    <div className="md:col-span-2">
                      <Input
                        label="Address *"
                        value={shippingAddress.address}
                        onChange={(e) => handleAddressChange('address', e.target.value)}
                        error={addressErrors.address}
                        placeholder="House no, Building name, Street"
                      />
                    </div>
                    
                    <Input
                      label="City *"
                      value={shippingAddress.city}
                      onChange={(e) => handleAddressChange('city', e.target.value)}
                      error={addressErrors.city}
                      placeholder="Enter your city"
                    />
                    
                    <Input
                      label="State *"
                      value={shippingAddress.state}
                      onChange={(e) => handleAddressChange('state', e.target.value)}
                      error={addressErrors.state}
                      placeholder="Enter your state"
                    />
                    
                    <Input
                      label="PIN Code *"
                      value={shippingAddress.pinCode}
                      onChange={(e) => handleAddressChange('pinCode', e.target.value)}
                      error={addressErrors.pinCode}
                      placeholder="Enter PIN code"
                    />
                    
                    <Input
                      label="Country"
                      value={shippingAddress.country}
                      onChange={(e) => handleAddressChange('country', e.target.value)}
                      disabled
                    />
                  </div>
                </div>
                
                {/* Payment Method */}
                <div className="bg-surface border border-border rounded-premium p-6">
                  <h2 className="font-heading font-bold text-xl text-text-primary mb-6">
                    Payment Method
                  </h2>
                  
                  <div className="space-y-4">
                    <label className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="cod"
                        checked={paymentMethod === 'cod'}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                        className="w-4 h-4 text-accent"
                      />
                      <div className="flex items-center space-x-3">
                        <Icon name="Banknote" size={20} className="text-accent" />
                        <div>
                          <p className="font-medium text-text-primary">Cash on Delivery</p>
                          <p className="text-sm text-text-secondary">Pay when you receive your order</p>
                        </div>
                      </div>
                    </label>
                    
                    <label className="flex items-center space-x-3 cursor-pointer">
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="upi"
                        checked={paymentMethod === 'upi'}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                        className="w-4 h-4 text-accent"
                      />
                      <div className="flex items-center space-x-3">
                        <Icon name="Smartphone" size={20} className="text-accent" />
                        <div>
                          <p className="font-medium text-text-primary">UPI Payment</p>
                          <p className="text-sm text-text-secondary">Pay instantly via UPI apps</p>
                        </div>
                      </div>
                    </label>
                  </div>
                  
                  {paymentMethod === 'upi' && (
                    <div className="mt-4 p-4 bg-accent bg-opacity-10 border border-accent border-opacity-30 rounded-premium">
                      <p className="text-sm text-accent font-medium mb-2">UPI Payment Instructions:</p>
                      <ol className="text-sm text-text-secondary space-y-1">
                        <li>1. Click "Place Order" to open your UPI app</li>
                        <li>2. Verify the amount and UPI ID: 8134007404@ybl</li>
                        <li>3. Complete the payment in your UPI app</li>
                        <li>4. Your order will be confirmed automatically</li>
                      </ol>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Order Summary */}
              <div className="lg:col-span-1">
                <div className="bg-surface border border-border rounded-premium p-6 sticky top-24">
                  <h2 className="font-heading font-bold text-xl text-text-primary mb-6">
                    Order Summary
                  </h2>
                  
                  {/* Cart Items */}
                  <div className="space-y-3 mb-6">
                    {cartItems.map((item) => (
                      <div key={`${item.id}-${item.size}-${item.color}`} className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-background rounded border border-border flex-shrink-0">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover rounded"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-text-primary text-sm truncate">
                            {item.name}
                          </p>
                          <p className="text-xs text-text-secondary">
                            {item.size && `Size: ${item.size}`} {item.color && `• Color: ${item.color}`}
                          </p>
                          <p className="text-xs text-text-secondary">
                            Qty: {item.quantity}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-text-primary text-sm">
                            ${(item.price * item.quantity).toFixed(2)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Totals */}
                  <div className="space-y-3 mb-6 pt-4 border-t border-border">
                    <div className="flex justify-between text-sm">
                      <span className="text-text-secondary">Subtotal</span>
                      <span className="text-text-primary">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-text-secondary">Shipping</span>
                      <span className="text-success font-medium">Free</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-text-secondary">Tax</span>
                      <span className="text-text-primary">${tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-lg font-bold pt-3 border-t border-border">
                      <span className="text-text-primary">Total</span>
                      <span className="text-text-primary">${total.toFixed(2)}</span>
                    </div>
                  </div>
                  
                  {/* Delivery Info */}
                  <div className="bg-background border border-border rounded-premium p-4 mb-6">
                    <div className="flex items-center space-x-2 mb-2">
                      <Icon name="Truck" size={16} className="text-accent" />
                      <span className="text-sm font-medium text-text-primary">Delivery Information</span>
                    </div>
                    <p className="text-xs text-text-secondary">
                      Expected delivery: 6-7 business days
                    </p>
                    <p className="text-xs text-text-secondary">
                      Free shipping on all orders
                    </p>
                  </div>
                  
                  {/* Place Order Button */}
                  <Button
                    variant="primary"
                    onClick={handlePlaceOrder}
                    disabled={isProcessing}
                    loading={isProcessing}
                    className="w-full h-12 text-lg font-semibold"
                  >
                    {paymentMethod === 'upi' ? 'Pay Now' : 'Place Order'}
                  </Button>
                  
                  <div className="flex items-center justify-center space-x-2 mt-4 text-xs text-text-secondary">
                    <Icon name="Shield" size={16} />
                    <span>Secure checkout with SSL encryption</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </>
  );
};

export default Checkout;