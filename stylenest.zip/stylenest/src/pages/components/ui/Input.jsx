import React, { useEffect } from 'react';

const Input = () => {
  React.useEffect(() => {
    // eslint-disable-next-line no-console
    console.warn('Placeholder: Input is not implemented yet.');
  }, []);
  return (
    <>
  { /*Input */} 
 </>
  );
};

export default Input;
