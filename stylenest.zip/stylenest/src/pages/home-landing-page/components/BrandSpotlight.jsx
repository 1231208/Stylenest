import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Image from '../../components/AppImage';
import Icon from '../../components/AppIcon';

const BrandSpotlight = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      premiumBrands: 'Premium Brands',
      trustedPartners: 'Trusted by fashion enthusiasts worldwide',
      viewCollection: 'View Collection',
      exploreAll: 'Explore All Brands'
    },
    es: {
      premiumBrands: 'Marcas Premium',
      trustedPartners: 'Confiado por entusiastas de la moda en todo el mundo',
      viewCollection: 'Ver Colección',
      exploreAll: 'Explorar Todas las Marcas'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const brands = [
    {
      id: 1,
      name: 'Gucci',
      logo: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=200&h=100&q=80',
      description: 'Luxury Italian fashion house',
      featured: true,
      link: '/brand-collection-pages?brand=gucci'
    },
    {
      id: 2,
      name: 'Chanel',
      logo: 'https://images.pexels.com/photos/1667088/pexels-photo-1667088.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      description: 'Timeless French elegance',
      featured: true,
      link: '/brand-collection-pages?brand=chanel'
    },
    {
      id: 3,
      name: 'Prada',
      logo: 'https://images.pixabay.com/photo/2017/08/01/11/48/woman-2564660_1280.jpg',
      description: 'Contemporary luxury fashion',
      featured: false,
      link: '/brand-collection-pages?brand=prada'
    },
    {
      id: 4,
      name: 'Versace',
      logo: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=200&h=100&q=80',
      description: 'Bold Italian glamour',
      featured: false,
      link: '/brand-collection-pages?brand=versace'
    },
    {
      id: 5,
      name: 'Dior',
      logo: 'https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      description: 'Haute couture excellence',
      featured: true,
      link: '/brand-collection-pages?brand=dior'
    },
    {
      id: 6,
      name: 'Louis Vuitton',
      logo: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=200&h=100&q=80',
      description: 'Iconic luxury craftsmanship',
      featured: false,
      link: '/brand-collection-pages?brand=louis-vuitton'
    },
    {
      id: 7,
      name: 'Hermès',
      logo: 'https://images.pixabay.com/photo/2016/11/29/13/14/attractive-1869761_1280.jpg',
      description: 'Artisanal luxury goods',
      featured: false,
      link: '/brand-collection-pages?brand=hermes'
    },
    {
      id: 8,
      name: 'Burberry',
      logo: 'https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      description: 'British heritage fashion',
      featured: false,
      link: '/brand-collection-pages?brand=burberry'
    }
  ];

  const featuredBrands = brands.filter(brand => brand.featured);
  const allBrands = brands;

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-5 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-heading font-bold text-text-primary mb-4">
            {t.premiumBrands}
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            {t.trustedPartners}
          </p>
          <div className="w-24 h-1 bg-accent mx-auto rounded-full mt-6" />
        </div>

        {/* Featured Brands */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {featuredBrands.map((brand) => (
            <Link
              key={brand.id}
              to={brand.link}
              className="group relative overflow-hidden rounded-premium premium-shadow-md premium-hover-scale premium-transition-long bg-surface"
            >
              <div className="aspect-[16/10] overflow-hidden">
                <Image
                  src={brand.logo}
                  alt={brand.name}
                  className="w-full h-full object-cover group-hover:scale-110 premium-transition-long"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              </div>
              
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <h3 className="text-xl font-heading font-bold mb-2">
                  {brand.name}
                </h3>
                <p className="text-sm text-white/90 mb-4">
                  {brand.description}
                </p>
                <div className="flex items-center space-x-2 text-sm font-medium">
                  <span>{t.viewCollection}</span>
                  <Icon 
                    name="ArrowRight" 
                    size={16} 
                    className="group-hover:translate-x-1 premium-transition" 
                  />
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* All Brands Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-4 mb-8">
          {allBrands.map((brand) => (
            <Link
              key={brand.id}
              to={brand.link}
              className="group aspect-square bg-surface rounded-premium premium-shadow-sm premium-hover-scale premium-transition flex items-center justify-center p-4 hover:bg-accent hover:bg-opacity-10"
            >
              <div className="text-center">
                <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center mx-auto mb-2 group-hover:scale-110 premium-transition">
                  <span className="text-accent-foreground font-bold text-lg">
                    {brand.name.charAt(0)}
                  </span>
                </div>
                <span className="text-xs font-medium text-text-primary group-hover:text-accent premium-transition">
                  {brand.name}
                </span>
              </div>
            </Link>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center">
          <Link
            to="/brand-collection-pages"
            className="inline-flex items-center space-x-2 px-8 py-3 bg-accent text-accent-foreground rounded-premium font-medium premium-hover-scale premium-transition hover:bg-opacity-90"
          >
            <span>{t.exploreAll}</span>
            <Icon name="ArrowRight" size={20} />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default BrandSpotlight;