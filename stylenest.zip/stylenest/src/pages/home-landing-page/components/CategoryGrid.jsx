import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Image from '../../components/AppImage';
import Icon from '../../components/AppIcon';

const CategoryGrid = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      shopByCategory: 'Shop by Category',
      women: 'Women',
      men: 'Men',
      children: 'Children',
      beauty: 'Beauty & Makeup',
      womenDesc: 'Discover the latest fashion trends for women',
      menDesc: 'Premium menswear collection and accessories',
      childrenDesc: 'Stylish and comfortable clothing for kids',
      beautyDesc: 'Luxury cosmetics, skincare & fragrances',
      explore: 'Explore',
      newArrivals: 'New Arrivals',
      saleItems: 'Sale Items',
      trending: 'Trending Now'
    },
    es: {
      shopByCategory: 'Comprar por Categoría',
      women: 'Mujeres',
      men: 'Hombres',
      children: 'Niños',
      beauty: 'Belleza y Maquillaje',
      womenDesc: 'Descubre las últimas tendencias para mujeres',
      menDesc: 'Colección premium para hombres y accesorios',
      childrenDesc: 'Ropa elegante y cómoda para niños',
      beautyDesc: 'Cosméticos, cuidado de la piel y fragancias de lujo',
      explore: 'Explorar',
      newArrivals: 'Nuevos Productos',
      saleItems: 'En Oferta',
      trending: 'Tendencias'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const categories = [
    {
      id: 'women',
      title: t.women,
      description: t.womenDesc,
      image: 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      link: '/product-catalog-browse?category=women',
      icon: 'User',
      color: 'from-pink-500/80 to-purple-600/80',
      stats: '2,500+ items'
    },
    {
      id: 'men',
      title: t.men,
      description: t.menDesc,
      image: 'https://images.pixabay.com/photo/2016/11/29/09/00/denim-1868684_1280.jpg',
      link: '/product-catalog-browse?category=men',
      icon: 'User',
      color: 'from-blue-500/80 to-indigo-600/80',
      stats: '1,800+ items'
    },
    {
      id: 'children',
      title: t.children,
      description: t.childrenDesc,
      image: 'https://images.unsplash.com/photo-1503919545889-aef636e10ad4?auto=format&fit=crop&w=800&h=600&q=80',
      link: '/product-catalog-browse?category=children',
      icon: 'Baby',
      color: 'from-green-500/80 to-teal-600/80',
      stats: '800+ items'
    },
    {
      id: 'beauty',
      title: t.beauty,
      description: t.beautyDesc,
      image: 'https://images.pexels.com/photos/2113855/pexels-photo-2113855.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop',
      link: '/product-catalog-browse?category=beauty',
      icon: 'Sparkles',
      color: 'from-rose-500/80 to-pink-600/80',
      stats: '1,200+ items'
    }
  ];

  const quickLinks = [
    {
      title: t.newArrivals,
      link: '/product-catalog-browse?new=true',
      icon: 'Star',
      color: 'text-accent'
    },
    {
      title: t.saleItems,
      link: '/product-catalog-browse?sale=true',
      icon: 'Tag',
      color: 'text-error'
    },
    {
      title: t.trending,
      link: '/product-catalog-browse?trending=true',
      icon: 'TrendingUp',
      color: 'text-success'
    }
  ];

  return (
    <section className="py-16 bg-surface">
      <div className="container mx-auto px-5 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-heading font-bold text-text-primary mb-4">
            {t.shopByCategory}
          </h2>
          <p className="text-text-secondary text-lg max-w-2xl mx-auto mb-6">
            Browse our extensive collection of over 5,000 premium products across all categories
          </p>
          <div className="w-24 h-1 bg-accent mx-auto rounded-full" />
        </div>

        {/* Quick Links */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {quickLinks.map((link) => (
            <Link
              key={link.title}
              to={link.link}
              className="flex items-center space-x-2 bg-background border border-border rounded-premium px-4 py-2 hover:border-accent premium-transition group"
            >
              <Icon name={link.icon} size={16} className={`${link.color} group-hover:scale-110 premium-transition`} />
              <span className="font-medium text-text-primary group-hover:text-accent premium-transition">
                {link.title}
              </span>
            </Link>
          ))}
        </div>

        {/* Category Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <Link
              key={category.id}
              to={category.link}
              className="group relative overflow-hidden rounded-premium premium-shadow-md premium-hover-scale premium-transition-long"
            >
              <div className="relative aspect-[4/5] overflow-hidden">
                <Image
                  src={category.image}
                  alt={category.title}
                  className="w-full h-full object-cover group-hover:scale-110 premium-transition-long"
                />
                
                {/* Overlay */}
                <div className={`absolute inset-0 bg-gradient-to-t ${category.color} opacity-60 group-hover:opacity-70 premium-transition`} />
                
                {/* Content */}
                <div className="absolute inset-0 flex flex-col justify-end p-6">
                  <div className="text-white">
                    <div className="flex items-center space-x-2 mb-2">
                      <Icon name={category.icon} size={24} className="text-white" />
                      <h3 className="text-xl font-heading font-bold">
                        {category.title}
                      </h3>
                    </div>
                    <p className="text-sm text-white/90 mb-2 leading-relaxed">
                      {category.description}
                    </p>
                    <p className="text-xs text-white/80 mb-4">
                      {category.stats}
                    </p>
                    <div className="flex items-center space-x-2 text-sm font-medium">
                      <span>{t.explore}</span>
                      <Icon 
                        name="ArrowRight" 
                        size={16} 
                        className="group-hover:translate-x-1 premium-transition" 
                      />
                    </div>
                  </div>
                </div>

                {/* Hover Effect */}
                <div className="absolute inset-0 border-2 border-white/20 rounded-premium opacity-0 group-hover:opacity-100 premium-transition" />
              </div>
            </Link>
          ))}
        </div>

        {/* Featured Brands Section */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-heading font-bold text-text-primary mb-8">
            Featured Brands
          </h3>
          <div className="flex flex-wrap justify-center items-center gap-8">
            {['Nike', 'Zara', 'H&M', 'Adidas', 'Gucci', 'MAC', 'Chanel', 'Ralph Lauren'].map((brand) => (
              <Link
                key={brand}
                to={`/brand/${encodeURIComponent(brand)}`}
                className="text-text-secondary hover:text-accent font-medium premium-transition text-lg"
              >
                {brand}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CategoryGrid;