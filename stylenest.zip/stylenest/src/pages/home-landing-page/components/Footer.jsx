import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/AppIcon';

const Footer = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const currentYear = new Date().getFullYear();

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      aboutUs: 'About StyleNest',
      aboutDescription: 'Your premier destination for luxury fashion and beauty products. We curate the finest collections from world-renowned brands.',
      quickLinks: 'Quick Links',
      customerService: 'Customer Service',
      followUs: 'Follow Us',
      newsletter: 'Newsletter',
      newsletterDesc: 'Subscribe for exclusive offers',
      subscribe: 'Subscribe',
      paymentMethods: 'Payment Methods',
      securePayments: 'Secure Payments',
      copyright: 'All rights reserved.',
      privacyPolicy: 'Privacy Policy',
      termsOfService: 'Terms of Service',
      cookiePolicy: 'Cookie Policy'
    },
    es: {
      aboutUs: 'Acerca de StyleNest',
      aboutDescription: 'Tu destino principal para productos de moda y belleza de lujo. Curamos las mejores colecciones de marcas mundialmente reconocidas.',
      quickLinks: 'Enlaces Rápidos',
      customerService: 'Servicio al Cliente',
      followUs: 'Síguenos',
      newsletter: 'Boletín',
      newsletterDesc: 'Suscríbete para ofertas exclusivas',
      subscribe: 'Suscribirse',
      paymentMethods: 'Métodos de Pago',
      securePayments: 'Pagos Seguros',
      copyright: 'Todos los derechos reservados.',
      privacyPolicy: 'Política de Privacidad',
      termsOfService: 'Términos de Servicio',
      cookiePolicy: 'Política de Cookies'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const quickLinks = [
    { label: 'Women', path: '/product-catalog-browse?category=women' },
    { label: 'Men', path: '/product-catalog-browse?category=men' },
    { label: 'Children', path: '/product-catalog-browse?category=children' },
    { label: 'Beauty', path: '/product-catalog-browse?category=beauty' },
    { label: 'Brands', path: '/brand-collection-pages' },
    { label: 'Sale', path: '/product-catalog-browse?sale=true' }
  ];

  const customerServiceLinks = [
    { label: 'Contact Us', path: '/contact' },
    { label: 'Size Guide', path: '/size-guide' },
    { label: 'Shipping Info', path: '/shipping' },
    { label: 'Returns', path: '/returns' },
    { label: 'FAQ', path: '/faq' },
    { label: 'Track Order', path: '/track-order' }
  ];

  const socialLinks = [
    { name: 'Facebook', icon: 'Facebook', url: 'https://facebook.com/stylenest' },
    { name: 'Instagram', icon: 'Instagram', url: 'https://instagram.com/stylenest' },
    { name: 'Twitter', icon: 'Twitter', url: 'https://twitter.com/stylenest' },
    { name: 'Pinterest', icon: 'Zap', url: 'https://pinterest.com/stylenest' },
    { name: 'YouTube', icon: 'Youtube', url: 'https://youtube.com/stylenest' }
  ];

  const paymentMethods = [
    { name: 'Visa', icon: 'CreditCard' },
    { name: 'Mastercard', icon: 'CreditCard' },
    { name: 'American Express', icon: 'CreditCard' },
    { name: 'PayPal', icon: 'Wallet' },
    { name: 'Apple Pay', icon: 'Smartphone' },
    { name: 'Google Pay', icon: 'Smartphone' }
  ];

  return (
    <footer className="bg-primary text-primary-foreground">
      {/* Main Footer Content */}
      <div className="container mx-auto px-5 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* About Section */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-8 h-8 bg-accent rounded-premium flex items-center justify-center">
                <span className="text-accent-foreground font-bold text-sm">SN</span>
              </div>
              <span className="font-heading font-bold text-xl">StyleNest</span>
            </div>
            <p className="text-primary-foreground opacity-80 mb-6 leading-relaxed">
              {t.aboutDescription}
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-primary-foreground bg-opacity-10 rounded-premium flex items-center justify-center hover:bg-accent hover:text-accent-foreground premium-transition"
                  aria-label={social.name}
                >
                  <Icon name={social.icon} size={20} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-heading font-semibold text-lg mb-6">
              {t.quickLinks}
            </h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-primary-foreground opacity-80 hover:opacity-100 hover:text-accent premium-transition"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="font-heading font-semibold text-lg mb-6">
              {t.customerService}
            </h3>
            <ul className="space-y-3">
              {customerServiceLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-primary-foreground opacity-80 hover:opacity-100 hover:text-accent premium-transition"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter & Contact */}
          <div>
            <h3 className="font-heading font-semibold text-lg mb-6">
              {t.newsletter}
            </h3>
            <p className="text-primary-foreground opacity-80 mb-4">
              {t.newsletterDesc}
            </p>
            <div className="flex space-x-2 mb-6">
              <input
                type="email"
                placeholder="Enter email"
                className="flex-1 px-3 py-2 bg-primary-foreground bg-opacity-10 border border-primary-foreground border-opacity-20 rounded-premium text-primary-foreground placeholder-primary-foreground placeholder-opacity-60 focus:outline-none focus:ring-2 focus:ring-accent"
              />
              <button className="px-4 py-2 bg-accent text-accent-foreground rounded-premium hover:bg-opacity-90 premium-transition">
                <Icon name="Send" size={16} />
              </button>
            </div>

            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3 text-primary-foreground opacity-80">
                <Icon name="Phone" size={16} />
                <span className="text-sm">+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-3 text-primary-foreground opacity-80">
                <Icon name="Mail" size={16} />
                <span className="text-sm">support@stylenest.com</span>
              </div>
              <div className="flex items-center space-x-3 text-primary-foreground opacity-80">
                <Icon name="MapPin" size={16} />
                <span className="text-sm">New York, NY 10001</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t border-primary-foreground border-opacity-20">
        <div className="container mx-auto px-5 lg:px-8 py-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            {/* Copyright */}
            <div className="text-center lg:text-left">
              <p className="text-primary-foreground opacity-80 text-sm">
                © {currentYear} StyleNest. {t.copyright}
              </p>
            </div>

            {/* Legal Links */}
            <div className="flex flex-wrap justify-center lg:justify-end space-x-6 text-sm">
              <Link
                to="/privacy-policy"
                className="text-primary-foreground opacity-80 hover:opacity-100 hover:text-accent premium-transition"
              >
                {t.privacyPolicy}
              </Link>
              <Link
                to="/terms-of-service"
                className="text-primary-foreground opacity-80 hover:opacity-100 hover:text-accent premium-transition"
              >
                {t.termsOfService}
              </Link>
              <Link
                to="/cookie-policy"
                className="text-primary-foreground opacity-80 hover:opacity-100 hover:text-accent premium-transition"
              >
                {t.cookiePolicy}
              </Link>
            </div>

            {/* Payment Methods */}
            <div className="flex justify-center lg:justify-end">
              <div className="flex items-center space-x-2">
                <span className="text-primary-foreground opacity-60 text-xs mr-2">
                  {t.securePayments}
                </span>
                {paymentMethods.slice(0, 4).map((method, index) => (
                  <div
                    key={index}
                    className="w-8 h-6 bg-primary-foreground bg-opacity-10 rounded flex items-center justify-center"
                  >
                    <Icon name={method.icon} size={12} className="text-primary-foreground opacity-60" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;