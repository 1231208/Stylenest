import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Image from '../../components/AppImage';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const HeroCarousel = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      shopNow: 'Shop Now',
      explore: 'Explore Collection',
      previous: 'Previous',
      next: 'Next'
    },
    es: {
      shopNow: 'Comprar Ahora',
      explore: 'Explorar Colección',
      previous: 'Anterior',
      next: 'Siguiente'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const slides = [
    {
      id: 1,
      title: "Summer Collection 2024",
      subtitle: "Discover the latest trends in fashion",
      description: "Elevate your style with our premium summer collection featuring the finest fabrics and contemporary designs.",
      image: "https://images.pexels.com/photos/1536619/pexels-photo-1536619.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop",
      ctaText: t.shopNow,
      ctaLink: "/product-catalog-browse?category=summer",
      theme: "light"
    },
    {
      id: 2,
      title: "Premium Beauty Essentials",
      subtitle: "Luxury makeup & skincare",
      description: "Transform your beauty routine with our curated selection of premium cosmetics from world-renowned brands.",
      image: "https://images.pixabay.com/photo/2017/07/31/22/05/makeup-2561401_1920.jpg",
      ctaText: t.explore,
      ctaLink: "/product-catalog-browse?category=beauty",
      theme: "dark"
    },
    {
      id: 3,
      title: "Designer Footwear",
      subtitle: "Step into luxury",
      description: "Complete your look with our exclusive collection of designer shoes crafted for comfort and style.",
      image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=1920&h=1080&q=80",
      ctaText: t.shopNow,
      ctaLink: "/product-catalog-browse?category=shoes",
      theme: "light"
    }
  ];

  useEffect(() => {
    if (!isAutoPlaying) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isAutoPlaying, slides.length]);

  const goToSlide = (index) => {
    setCurrentSlide(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const goToPrevious = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const goToNext = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  return (
    <div className="relative w-full h-[60vh] lg:h-[80vh] overflow-hidden rounded-premium premium-shadow-md">
      {/* Slides */}
      <div className="relative w-full h-full">
        {slides.map((slide, index) => (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-1000 ease-premium ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <div className="relative w-full h-full">
              <Image
                src={slide.image}
                alt={slide.title}
                className="w-full h-full object-cover"
              />
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent" />
              
              {/* Content */}
              <div className="absolute inset-0 flex items-center">
                <div className="container mx-auto px-5 lg:px-8">
                  <div className="max-w-2xl">
                    <h2 className={`text-3xl lg:text-5xl font-heading font-bold mb-4 ${
                      slide.theme === 'dark' ? 'text-white' : 'text-white'
                    }`}>
                      {slide.title}
                    </h2>
                    <p className={`text-lg lg:text-xl mb-2 ${
                      slide.theme === 'dark' ? 'text-gray-200' : 'text-gray-200'
                    }`}>
                      {slide.subtitle}
                    </p>
                    <p className={`text-base lg:text-lg mb-8 leading-relaxed ${
                      slide.theme === 'dark' ? 'text-gray-300' : 'text-gray-300'
                    }`}>
                      {slide.description}
                    </p>
                    <Link to={slide.ctaLink}>
                      <Button
                        variant="primary"
                        size="lg"
                        className="premium-hover-scale"
                        iconName="ArrowRight"
                        iconPosition="right"
                      >
                        {slide.ctaText}
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={goToPrevious}
        className="absolute left-4 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full flex items-center justify-center text-white hover:bg-white/30 premium-transition z-10"
        aria-label={t.previous}
      >
        <Icon name="ChevronLeft" size={24} />
      </button>
      
      <button
        onClick={goToNext}
        className="absolute right-4 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full flex items-center justify-center text-white hover:bg-white/30 premium-transition z-10"
        aria-label={t.next}
      >
        <Icon name="ChevronRight" size={24} />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-3 z-10">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full premium-transition ${
              index === currentSlide
                ? 'bg-white' :'bg-white/50 hover:bg-white/75'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>

      {/* Auto-play indicator */}
      <div className="absolute top-4 right-4 z-10">
        <button
          onClick={() => setIsAutoPlaying(!isAutoPlaying)}
          className="w-10 h-10 bg-white/20 backdrop-blur-sm border border-white/30 rounded-full flex items-center justify-center text-white hover:bg-white/30 premium-transition"
          aria-label={isAutoPlaying ? 'Pause slideshow' : 'Play slideshow'}
        >
          <Icon name={isAutoPlaying ? "Pause" : "Play"} size={16} />
        </button>
      </div>
    </div>
  );
};

export default HeroCarousel;