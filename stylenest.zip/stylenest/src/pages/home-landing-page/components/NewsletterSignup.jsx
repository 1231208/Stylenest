import React, { useState, useEffect } from 'react';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

const NewsletterSignup = () => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      stayInTouch: 'Stay in Touch',
      exclusiveOffers: 'Get exclusive offers and updates',
      description: 'Be the first to know about new arrivals, special promotions, and fashion trends. Join our community of style enthusiasts.',
      emailPlaceholder: 'Enter your email address',
      subscribe: 'Subscribe Now',
      subscribing: 'Subscribing...',
      thankYou: 'Thank You!',
      subscribed: 'You\'ve successfully subscribed to our newsletter.',
      benefits: [
        'Exclusive early access to sales',
        'New arrival notifications',
        'Style tips and trends',
        'Special member discounts'
      ]
    },
    es: {
      stayInTouch: 'Mantente en Contacto',
      exclusiveOffers: 'Obtén ofertas exclusivas y actualizaciones',
      description: 'Sé el primero en conocer las nuevas llegadas, promociones especiales y tendencias de moda. Únete a nuestra comunidad de entusiastas del estilo.',
      emailPlaceholder: 'Ingresa tu dirección de email',
      subscribe: 'Suscribirse Ahora',
      subscribing: 'Suscribiendo...',
      thankYou: '¡Gracias!',
      subscribed: 'Te has suscrito exitosamente a nuestro boletín.',
      benefits: [
        'Acceso exclusivo temprano a ventas',
        'Notificaciones de nuevos productos',
        'Consejos de estilo y tendencias',
        'Descuentos especiales para miembros'
      ]
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubscribed(true);
      setIsLoading(false);
      setEmail('');
      
      // Reset after 5 seconds
      setTimeout(() => {
        setIsSubscribed(false);
      }, 5000);
    }, 1500);
  };

  if (isSubscribed) {
    return (
      <section className="py-16 bg-accent">
        <div className="container mx-auto px-5 lg:px-8">
          <div className="max-w-2xl mx-auto text-center">
            <div className="w-16 h-16 bg-accent-foreground rounded-full flex items-center justify-center mx-auto mb-6">
              <Icon name="Check" size={32} className="text-accent" />
            </div>
            <h2 className="text-3xl font-heading font-bold text-accent-foreground mb-4">
              {t.thankYou}
            </h2>
            <p className="text-lg text-accent-foreground opacity-90">
              {t.subscribed}
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-accent">
      <div className="container mx-auto px-5 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Content */}
            <div className="text-center lg:text-left">
              <h2 className="text-3xl lg:text-4xl font-heading font-bold text-accent-foreground mb-4">
                {t.stayInTouch}
              </h2>
              <p className="text-xl text-accent-foreground opacity-90 mb-6">
                {t.exclusiveOffers}
              </p>
              <p className="text-accent-foreground opacity-80 mb-8 leading-relaxed">
                {t.description}
              </p>

              {/* Benefits List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8 lg:mb-0">
                {t.benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center space-x-3 text-accent-foreground">
                    <Icon name="Check" size={16} className="text-accent-foreground flex-shrink-0" />
                    <span className="text-sm opacity-90">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Newsletter Form */}
            <div className="bg-background rounded-premium p-8 premium-shadow-lg">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="newsletter-email" className="block text-sm font-medium text-text-primary mb-2">
                    Email Address
                  </label>
                  <Input
                    id="newsletter-email"
                    type="email"
                    placeholder={t.emailPlaceholder}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full"
                    disabled={isLoading}
                  />
                </div>

                <Button
                  type="submit"
                  variant="primary"
                  size="lg"
                  fullWidth
                  loading={isLoading}
                  disabled={!email.trim() || isLoading}
                  iconName={isLoading ? undefined : "Mail"}
                  iconPosition="left"
                >
                  {isLoading ? t.subscribing : t.subscribe}
                </Button>

                <p className="text-xs text-text-secondary text-center leading-relaxed">
                  By subscribing, you agree to receive marketing emails from StyleNest. 
                  You can unsubscribe at any time. View our Privacy Policy for more details.
                </p>
              </form>

              {/* Social Proof */}
              <div className="mt-6 pt-6 border-t border-border">
                <div className="flex items-center justify-center space-x-4 text-text-secondary">
                  <div className="flex items-center space-x-2">
                    <Icon name="Users" size={16} />
                    <span className="text-sm">50K+ subscribers</span>
                  </div>
                  <div className="w-1 h-1 bg-text-secondary rounded-full" />
                  <div className="flex items-center space-x-2">
                    <Icon name="Star" size={16} className="text-accent fill-current" />
                    <span className="text-sm">4.9/5 rating</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewsletterSignup;