import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import Image from '../../components/AppImage';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const ProductRecommendations = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [activeSection, setActiveSection] = useState('trending');
  const scrollContainerRef = useRef(null);

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      trending: 'Trending Now',
      newArrivals: 'New Arrivals',
      recommended: 'Recommended for You',
      viewAll: 'View All',
      addToCart: 'Add to Cart',
      quickView: 'Quick View',
      sale: 'Sale',
      new: 'New',
      inStock: 'In Stock',
      outOfStock: 'Out of Stock'
    },
    es: {
      trending: 'Tendencias',
      newArrivals: 'Nuevos Productos',
      recommended: 'Recomendado para Ti',
      viewAll: 'Ver Todo',
      addToCart: 'Añadir al Carrito',
      quickView: 'Vista Rápida',
      sale: 'Oferta',
      new: 'Nuevo',
      inStock: 'En Stock',
      outOfStock: 'Agotado'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const productSections = {
    trending: {
      title: t.trending,
      products: [
        {
          id: 1,
          name: 'Designer Silk Dress',
          brand: 'Gucci',
          price: 1299,
          originalPrice: 1599,
          image: 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=400&h=500&fit=crop',
          rating: 4.8,
          reviews: 124,
          isOnSale: true,
          inStock: true,
          colors: ['black', 'navy', 'burgundy']
        },
        {
          id: 2,
          name: 'Premium Leather Handbag',
          brand: 'Prada',
          price: 899,
          originalPrice: null,
          image: 'https://images.pixabay.com/photo/2017/08/01/11/48/woman-2564660_1280.jpg',
          rating: 4.9,
          reviews: 89,
          isOnSale: false,
          inStock: true,
          colors: ['brown', 'black', 'tan']
        },
        {
          id: 3,
          name: 'Luxury Watch Collection',
          brand: 'Chanel',
          price: 2499,
          originalPrice: null,
          image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&h=500&q=80',
          rating: 4.7,
          reviews: 67,
          isOnSale: false,
          inStock: false,
          colors: ['gold', 'silver', 'rose-gold']
        },
        {
          id: 4,
          name: 'Designer Sunglasses',
          brand: 'Versace',
          price: 349,
          originalPrice: 449,
          image: 'https://images.pexels.com/photos/1667088/pexels-photo-1667088.jpeg?auto=compress&cs=tinysrgb&w=400&h=500&fit=crop',
          rating: 4.6,
          reviews: 156,
          isOnSale: true,
          inStock: true,
          colors: ['black', 'tortoise', 'gold']
        }
      ]
    },
    newArrivals: {
      title: t.newArrivals,
      products: [
        {
          id: 5,
          name: 'Cashmere Sweater',
          brand: 'Burberry',
          price: 599,
          originalPrice: null,
          image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=400&h=500&q=80',
          rating: 4.9,
          reviews: 23,
          isOnSale: false,
          inStock: true,
          colors: ['cream', 'navy', 'camel'],
          isNew: true
        },
        {
          id: 6,
          name: 'Premium Skincare Set',
          brand: 'Dior',
          price: 299,
          originalPrice: null,
          image: 'https://images.pexels.com/photos/2113855/pexels-photo-2113855.jpeg?auto=compress&cs=tinysrgb&w=400&h=500&fit=crop',
          rating: 4.8,
          reviews: 45,
          isOnSale: false,
          inStock: true,
          colors: [],
          isNew: true
        },
        {
          id: 7,
          name: 'Italian Leather Shoes',
          brand: 'Gucci',
          price: 799,
          originalPrice: null,
          image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=400&h=500&q=80',
          rating: 4.7,
          reviews: 78,
          isOnSale: false,
          inStock: true,
          colors: ['black', 'brown', 'burgundy'],
          isNew: true
        },
        {
          id: 8,
          name: 'Silk Scarf Collection',
          brand: 'Hermès',
          price: 450,
          originalPrice: null,
          image: 'https://images.pixabay.com/photo/2016/11/29/13/14/attractive-1869761_1280.jpg',
          rating: 4.9,
          reviews: 34,
          isOnSale: false,
          inStock: true,
          colors: ['floral', 'geometric', 'abstract'],
          isNew: true
        }
      ]
    },
    recommended: {
      title: t.recommended,
      products: [
        {
          id: 9,
          name: 'Evening Gown',
          brand: 'Chanel',
          price: 1899,
          originalPrice: 2299,
          image: 'https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=400&h=500&fit=crop',
          rating: 4.8,
          reviews: 92,
          isOnSale: true,
          inStock: true,
          colors: ['black', 'navy', 'emerald']
        },
        {
          id: 10,
          name: 'Designer Perfume',
          brand: 'Dior',
          price: 129,
          originalPrice: null,
          image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=400&h=500&q=80',
          rating: 4.7,
          reviews: 234,
          isOnSale: false,
          inStock: true,
          colors: []
        },
        {
          id: 11,
          name: 'Luxury Coat',
          brand: 'Burberry',
          price: 1299,
          originalPrice: null,
          image: 'https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=400&h=500&fit=crop',
          rating: 4.9,
          reviews: 67,
          isOnSale: false,
          inStock: true,
          colors: ['beige', 'black', 'navy']
        },
        {
          id: 12,
          name: 'Diamond Jewelry',
          brand: 'Tiffany & Co',
          price: 3499,
          originalPrice: null,
          image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=400&h=500&q=80',
          rating: 5.0,
          reviews: 12,
          isOnSale: false,
          inStock: true,
          colors: ['white-gold', 'yellow-gold', 'rose-gold']
        }
      ]
    }
  };

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -300, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 300, behavior: 'smooth' });
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  const ProductCard = ({ product }) => (
    <div className="flex-shrink-0 w-72 bg-background rounded-premium premium-shadow-sm hover:premium-shadow-md premium-transition group">
      <div className="relative aspect-[4/5] overflow-hidden rounded-t-premium">
        <Link to={`/product-detail-page?id=${product.id}`}>
          <Image
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 premium-transition-long"
          />
        </Link>
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col space-y-2">
          {product.isOnSale && (
            <span className="bg-error text-error-foreground px-2 py-1 rounded-full text-xs font-medium">
              {t.sale}
            </span>
          )}
          {product.isNew && (
            <span className="bg-success text-success-foreground px-2 py-1 rounded-full text-xs font-medium">
              {t.new}
            </span>
          )}
        </div>

        {/* Quick Actions */}
        <div className="absolute top-3 right-3 flex flex-col space-y-2 opacity-0 group-hover:opacity-100 premium-transition">
          <button className="w-8 h-8 bg-white rounded-full flex items-center justify-center premium-shadow-sm hover:bg-accent hover:text-accent-foreground premium-transition">
            <Icon name="Heart" size={16} />
          </button>
          <button className="w-8 h-8 bg-white rounded-full flex items-center justify-center premium-shadow-sm hover:bg-accent hover:text-accent-foreground premium-transition">
            <Icon name="Eye" size={16} />
          </button>
        </div>

        {/* Stock Status */}
        {!product.inStock && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <span className="bg-white text-text-primary px-4 py-2 rounded-premium font-medium">
              {t.outOfStock}
            </span>
          </div>
        )}
      </div>

      <div className="p-4">
        <div className="mb-2">
          <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
            {product.brand}
          </p>
          <Link 
            to={`/product-detail-page?id=${product.id}`}
            className="font-heading font-semibold text-text-primary hover:text-accent premium-transition line-clamp-2"
          >
            {product.name}
          </Link>
        </div>

        {/* Rating */}
        <div className="flex items-center space-x-1 mb-3">
          <div className="flex space-x-1">
            {[...Array(5)].map((_, i) => (
              <Icon
                key={i}
                name="Star"
                size={12}
                className={i < Math.floor(product.rating) ? 'text-accent fill-current' : 'text-border'}
              />
            ))}
          </div>
          <span className="text-xs text-text-secondary">
            ({product.reviews})
          </span>
        </div>

        {/* Colors */}
        {product.colors.length > 0 && (
          <div className="flex space-x-2 mb-3">
            {product.colors.slice(0, 3).map((color, index) => (
              <div
                key={index}
                className="w-4 h-4 rounded-full border border-border"
                style={{ backgroundColor: color === 'tortoise' ? '#8B4513' : color }}
                title={color}
              />
            ))}
            {product.colors.length > 3 && (
              <span className="text-xs text-text-secondary">
                +{product.colors.length - 3}
              </span>
            )}
          </div>
        )}

        {/* Price */}
        <div className="flex items-center space-x-2 mb-4">
          <span className="font-bold text-text-primary">
            {formatPrice(product.price)}
          </span>
          {product.originalPrice && (
            <span className="text-sm text-text-secondary line-through">
              {formatPrice(product.originalPrice)}
            </span>
          )}
        </div>

        {/* Add to Cart Button */}
        <Button
          variant="primary"
          size="sm"
          fullWidth
          disabled={!product.inStock}
          className="premium-transition"
          iconName="ShoppingBag"
          iconPosition="left"
        >
          {product.inStock ? t.addToCart : t.outOfStock}
        </Button>
      </div>
    </div>
  );

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-5 lg:px-8">
        {/* Section Navigation */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <div className="flex space-x-1 mb-4 sm:mb-0 bg-surface rounded-premium p-1">
            {Object.keys(productSections).map((section) => (
              <button
                key={section}
                onClick={() => setActiveSection(section)}
                className={`px-4 py-2 rounded-premium text-sm font-medium premium-transition ${
                  activeSection === section
                    ? 'bg-accent text-accent-foreground'
                    : 'text-text-secondary hover:text-text-primary'
                }`}
              >
                {productSections[section].title}
              </button>
            ))}
          </div>

          <Link
            to={`/product-catalog-browse?section=${activeSection}`}
            className="text-accent hover:text-accent-foreground font-medium text-sm flex items-center space-x-1 premium-transition"
          >
            <span>{t.viewAll}</span>
            <Icon name="ArrowRight" size={16} />
          </Link>
        </div>

        {/* Products Carousel */}
        <div className="relative">
          {/* Navigation Arrows */}
          <button
            onClick={scrollLeft}
            className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-4 w-10 h-10 bg-background border border-border rounded-full flex items-center justify-center text-text-primary hover:bg-accent hover:text-accent-foreground premium-transition z-10 premium-shadow-sm"
            aria-label="Previous products"
          >
            <Icon name="ChevronLeft" size={20} />
          </button>
          
          <button
            onClick={scrollRight}
            className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-4 w-10 h-10 bg-background border border-border rounded-full flex items-center justify-center text-text-primary hover:bg-accent hover:text-accent-foreground premium-transition z-10 premium-shadow-sm"
            aria-label="Next products"
          >
            <Icon name="ChevronRight" size={20} />
          </button>

          {/* Products Container */}
          <div
            ref={scrollContainerRef}
            className="flex space-x-6 overflow-x-auto scrollbar-hide pb-4"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {productSections[activeSection].products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductRecommendations;