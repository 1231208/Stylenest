import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Image from '../../components/AppImage';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const PromotionalBanners = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      specialOffers: 'Special Offers',
      limitedTime: 'Limited Time Only',
      shopNow: 'Shop Now',
      saveUp: 'Save up to',
      newArrivals: 'New Arrivals',
      exclusive: 'Exclusive',
      freeShipping: 'Free Shipping',
      onOrders: 'on orders over $100'
    },
    es: {
      specialOffers: 'Ofertas Especiales',
      limitedTime: 'Solo por Tiempo Limitado',
      shopNow: 'Comprar Ahora',
      saveUp: 'Ahorra hasta',
      newArrivals: 'Nuevos Productos',
      exclusive: 'Exclusivo',
      freeShipping: 'Envío Gratis',
      onOrders: 'en pedidos superiores a $100'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const promotions = [
    {
      id: 1,
      type: 'sale',
      title: 'Summer Sale',
      subtitle: `${t.saveUp} 70%`,
      description: `${t.limitedTime} - Premium fashion at unbeatable prices`,
      image: 'https://images.pexels.com/photos/1926769/pexels-photo-1926769.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop',
      ctaText: t.shopNow,
      ctaLink: '/product-catalog-browse?sale=true',
      badge: '70% OFF',
      color: 'from-red-500/90 to-pink-600/90'
    },
    {
      id: 2,
      type: 'new',
      title: t.newArrivals,
      subtitle: `${t.exclusive} Collection`,
      description: 'Discover the latest trends in premium fashion and beauty',
      image: 'https://images.pixabay.com/photo/2016/11/29/09/00/denim-1868684_1280.jpg',
      ctaText: t.shopNow,
      ctaLink: '/product-catalog-browse?new=true',
      badge: 'NEW',
      color: 'from-blue-500/90 to-indigo-600/90'
    }
  ];

  const servicePromotions = [
    {
      id: 1,
      icon: 'Truck',
      title: t.freeShipping,
      description: t.onOrders,
      color: 'text-green-600'
    },
    {
      id: 2,
      icon: 'RotateCcw',
      title: 'Easy Returns',
      description: '30-day return policy',
      color: 'text-blue-600'
    },
    {
      id: 3,
      icon: 'Shield',
      title: 'Secure Payment',
      description: '100% secure checkout',
      color: 'text-purple-600'
    },
    {
      id: 4,
      icon: 'Headphones',
      title: '24/7 Support',
      description: 'Customer service',
      color: 'text-orange-600'
    }
  ];

  return (
    <section className="py-16 bg-surface">
      <div className="container mx-auto px-5 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-heading font-bold text-text-primary mb-4">
            {t.specialOffers}
          </h2>
          <div className="w-24 h-1 bg-accent mx-auto rounded-full" />
        </div>

        {/* Main Promotional Banners */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {promotions.map((promo) => (
            <div
              key={promo.id}
              className="relative overflow-hidden rounded-premium premium-shadow-lg group"
            >
              <div className="aspect-[16/9] lg:aspect-[16/10] relative">
                <Image
                  src={promo.image}
                  alt={promo.title}
                  className="w-full h-full object-cover group-hover:scale-105 premium-transition-long"
                />
                
                {/* Overlay */}
                <div className={`absolute inset-0 bg-gradient-to-r ${promo.color}`} />
                
                {/* Badge */}
                <div className="absolute top-4 left-4 bg-white text-text-primary px-3 py-1 rounded-full text-sm font-bold">
                  {promo.badge}
                </div>
                
                {/* Content */}
                <div className="absolute inset-0 flex items-center">
                  <div className="p-8 text-white max-w-md">
                    <h3 className="text-2xl lg:text-3xl font-heading font-bold mb-2">
                      {promo.title}
                    </h3>
                    <p className="text-xl lg:text-2xl font-semibold mb-4 text-yellow-200">
                      {promo.subtitle}
                    </p>
                    <p className="text-base mb-6 text-white/90 leading-relaxed">
                      {promo.description}
                    </p>
                    <Link to={promo.ctaLink}>
                      <Button
                        variant="secondary"
                        size="lg"
                        className="premium-hover-scale bg-white text-text-primary hover:bg-gray-100"
                        iconName="ArrowRight"
                        iconPosition="right"
                      >
                        {promo.ctaText}
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Service Promotions */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {servicePromotions.map((service) => (
            <div
              key={service.id}
              className="bg-background rounded-premium p-6 text-center premium-shadow-sm hover:premium-shadow-md premium-transition group"
            >
              <div className={`w-16 h-16 ${service.color} bg-opacity-10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 premium-transition`}>
                <Icon name={service.icon} size={32} className={service.color} />
              </div>
              <h3 className="font-heading font-semibold text-text-primary mb-2">
                {service.title}
              </h3>
              <p className="text-sm text-text-secondary">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PromotionalBanners;