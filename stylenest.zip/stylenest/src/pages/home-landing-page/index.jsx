import React, { useEffect } from 'react';
import GlobalHeader from '../../components/ui/GlobalHeader';
import HeroCarousel from './components/HeroCarousel';
import CategoryGrid from './components/CategoryGrid';
import BrandSpotlight from './components/BrandSpotlight';
import PromotionalBanners from './components/PromotionalBanners';
import ProductRecommendations from './components/ProductRecommendations';
import NewsletterSignup from './components/NewsletterSignup';
import Footer from './components/Footer';

const HomeLandingPage = () => {
  useEffect(() => {
    // Set page title
    document.title = 'StyleNest - Premium Fashion & Beauty';
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Global Header */}
      <GlobalHeader />
      
      {/* Main Content */}
      <main className="pt-16 lg:pt-18">
        {/* Hero Section */}
        <section className="mb-0">
          <HeroCarousel />
        </section>

        {/* Category Grid Section */}
        <CategoryGrid />

        {/* Brand Spotlight Section */}
        <BrandSpotlight />

        {/* Promotional Banners Section */}
        <PromotionalBanners />

        {/* Product Recommendations Section */}
        <ProductRecommendations />

        {/* Newsletter Signup Section */}
        <NewsletterSignup />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default HomeLandingPage;