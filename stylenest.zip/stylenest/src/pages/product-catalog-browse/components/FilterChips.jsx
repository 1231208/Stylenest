import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FilterChips = ({ activeFilters, onRemoveFilter, onClearAll, totalProducts }) => {
  const getFilterChips = () => {
    const chips = [];

    // Category filters
    activeFilters.category?.forEach(category => {
      chips.push({
        type: 'category',
        value: category,
        label: category,
        key: `category-${category}`
      });
    });

    // Brand filters
    activeFilters.brand?.forEach(brand => {
      chips.push({
        type: 'brand',
        value: brand,
        label: brand,
        key: `brand-${brand}`
      });
    });

    // Size filters
    activeFilters.size?.forEach(size => {
      chips.push({
        type: 'size',
        value: size,
        label: `Size ${size}`,
        key: `size-${size}`
      });
    });

    // Color filters
    activeFilters.color?.forEach(color => {
      chips.push({
        type: 'color',
        value: color,
        label: color,
        key: `color-${color}`
      });
    });

    // Price range filter
    if (activeFilters.priceRange?.min || activeFilters.priceRange?.max) {
      const min = activeFilters.priceRange.min || '0';
      const max = activeFilters.priceRange.max || '∞';
      chips.push({
        type: 'priceRange',
        value: activeFilters.priceRange,
        label: `$${min} - $${max}`,
        key: 'price-range'
      });
    }

    // Rating filter
    if (activeFilters.rating) {
      chips.push({
        type: 'rating',
        value: activeFilters.rating,
        label: `${activeFilters.rating}+ Stars`,
        key: 'rating'
      });
    }

    // Availability filters
    if (activeFilters.inStock) {
      chips.push({
        type: 'inStock',
        value: true,
        label: 'In Stock',
        key: 'in-stock'
      });
    }

    if (activeFilters.onSale) {
      chips.push({
        type: 'onSale',
        value: true,
        label: 'On Sale',
        key: 'on-sale'
      });
    }

    return chips;
  };

  const filterChips = getFilterChips();

  if (filterChips.length === 0) {
    return null;
  }

  return (
    <div className="bg-surface border-b border-border px-5 lg:px-8 py-4">
      <div className="max-w-screen-2xl mx-auto">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium text-text-primary">
              {totalProducts.toLocaleString()} products found
            </span>
            {filterChips.length > 0 && (
              <span className="text-sm text-text-secondary">
                • {filterChips.length} filter{filterChips.length !== 1 ? 's' : ''} applied
              </span>
            )}
          </div>
          
          {filterChips.length > 0 && (
            <Button
              variant="ghost"
              onClick={onClearAll}
              className="text-sm text-text-secondary hover:text-accent"
            >
              Clear All
            </Button>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          {filterChips.map((chip) => (
            <div
              key={chip.key}
              className="flex items-center space-x-2 bg-background border border-border rounded-premium px-3 py-1.5 text-sm"
            >
              <span className="text-text-primary">{chip.label}</span>
              <button
                onClick={() => onRemoveFilter(chip.type, chip.value)}
                className="text-text-secondary hover:text-error premium-transition"
                aria-label={`Remove ${chip.label} filter`}
              >
                <Icon name="X" size={14} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FilterChips;