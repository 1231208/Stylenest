import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ProductCard = ({ product, onQuickAdd, onToggleWishlist, isWishlisted }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const handleQuickAdd = (e) => {
    e.preventDefault();
    e.stopPropagation();
    onQuickAdd(product);
  };

  const handleWishlistToggle = (e) => {
    e.preventDefault();
    e.stopPropagation();
    onToggleWishlist(product.id);
  };

  const handleImageHover = () => {
    if (product.images && product.images.length > 1) {
      setCurrentImageIndex(1);
    }
    setIsHovered(true);
  };

  const handleImageLeave = () => {
    setCurrentImageIndex(0);
    setIsHovered(false);
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  return (
    <Link
      to={`/product-detail-page?id=${product.id}`}
      className="group block bg-background rounded-premium premium-shadow-sm hover:premium-shadow-md premium-transition overflow-hidden"
    >
      <div className="relative aspect-[3/4] overflow-hidden bg-surface">
        <Image
          src={product.images[currentImageIndex]}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 premium-transition-long"
          onMouseEnter={handleImageHover}
          onMouseLeave={handleImageLeave}
        />
        
        {/* Sale Badge */}
        {product.isOnSale && (
          <div className="absolute top-3 left-3 bg-error text-error-foreground px-2 py-1 rounded-premium text-xs font-medium">
            SALE
          </div>
        )}

        {/* New Badge */}
        {product.isNew && (
          <div className="absolute top-3 right-3 bg-accent text-accent-foreground px-2 py-1 rounded-premium text-xs font-medium">
            NEW
          </div>
        )}

        {/* Wishlist Button */}
        <button
          onClick={handleWishlistToggle}
          className={`
            absolute top-3 right-3 w-8 h-8 rounded-full premium-transition
            ${product.isOnSale ? 'top-12' : 'top-3'}
            ${isWishlisted 
              ? 'bg-accent text-accent-foreground' 
              : 'bg-background bg-opacity-80 text-text-primary hover:bg-accent hover:text-accent-foreground'
            }
            flex items-center justify-center opacity-0 group-hover:opacity-100
          `}
        >
          <Icon 
            name="Heart" 
            size={16} 
            className={isWishlisted ? 'fill-current' : ''} 
          />
        </button>

        {/* Quick Add Button */}
        <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 premium-transition">
          <Button
            variant="primary"
            onClick={handleQuickAdd}
            className="w-full"
            iconName="Plus"
            iconPosition="left"
          >
            Quick Add
          </Button>
        </div>

        {/* Stock Status */}
        {!product.inStock && (
          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <span className="text-white font-medium">Out of Stock</span>
          </div>
        )}
      </div>

      <div className="p-4">
        {/* Brand */}
        <p className="text-sm text-text-secondary font-medium mb-1">
          {product.brand}
        </p>

        {/* Product Name */}
        <h3 className="font-medium text-text-primary mb-2 line-clamp-2 group-hover:text-accent premium-transition">
          {product.name}
        </h3>

        {/* Price */}
        <div className="flex items-center space-x-2">
          {product.originalPrice && product.originalPrice > product.price ? (
            <>
              <span className="font-semibold text-text-primary">
                {formatPrice(product.price)}
              </span>
              <span className="text-sm text-text-secondary line-through">
                {formatPrice(product.originalPrice)}
              </span>
              <span className="text-xs text-error font-medium">
                {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
              </span>
            </>
          ) : (
            <span className="font-semibold text-text-primary">
              {formatPrice(product.price)}
            </span>
          )}
        </div>

        {/* Rating */}
        {product.rating && (
          <div className="flex items-center space-x-1 mt-2">
            <div className="flex space-x-1">
              {[...Array(5)].map((_, i) => (
                <Icon
                  key={i}
                  name="Star"
                  size={12}
                  className={
                    i < Math.floor(product.rating)
                      ? 'text-accent fill-current' :'text-border'
                  }
                />
              ))}
            </div>
            <span className="text-xs text-text-secondary">
              ({product.reviewCount})
            </span>
          </div>
        )}

        {/* Available Colors */}
        {product.colors && product.colors.length > 0 && (
          <div className="flex items-center space-x-1 mt-2">
            {product.colors.slice(0, 4).map((color, index) => (
              <div
                key={index}
                className="w-4 h-4 rounded-full border border-border"
                style={{ backgroundColor: color.toLowerCase() }}
                title={color}
              />
            ))}
            {product.colors.length > 4 && (
              <span className="text-xs text-text-secondary">
                +{product.colors.length - 4}
              </span>
            )}
          </div>
        )}
      </div>
    </Link>
  );
};

export default ProductCard;