import React from 'react';
import ProductCard from './ProductCard';

const ProductGrid = ({ 
  products, 
  onQuickAdd, 
  onToggleWishlist, 
  wishlistedProducts,
  isLoading,
  hasMore,
  onLoadMore 
}) => {
  if (isLoading && products.length === 0) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4 lg:gap-6">
        {[...Array(12)].map((_, index) => (
          <div key={index} className="bg-surface rounded-premium overflow-hidden animate-pulse">
            <div className="aspect-[3/4] bg-border" />
            <div className="p-4 space-y-2">
              <div className="h-4 bg-border rounded w-1/2" />
              <div className="h-4 bg-border rounded w-3/4" />
              <div className="h-4 bg-border rounded w-1/3" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="w-24 h-24 bg-surface rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-4xl">🔍</span>
        </div>
        <h3 className="font-heading font-semibold text-xl text-text-primary mb-2">
          No products found
        </h3>
        <p className="text-text-secondary mb-6">
          Try adjusting your filters or search terms to find what you're looking for.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4 lg:gap-6">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onQuickAdd={onQuickAdd}
            onToggleWishlist={onToggleWishlist}
            isWishlisted={wishlistedProducts.includes(product.id)}
          />
        ))}
      </div>

      {/* Load More Button */}
      {hasMore && (
        <div className="text-center py-8">
          {isLoading ? (
            <div className="flex items-center justify-center space-x-2">
              <div className="w-4 h-4 bg-accent rounded-full animate-bounce" />
              <div className="w-4 h-4 bg-accent rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
              <div className="w-4 h-4 bg-accent rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
            </div>
          ) : (
            <button
              onClick={onLoadMore}
              className="px-8 py-3 bg-background border border-border rounded-premium text-text-primary hover:border-accent hover:text-accent premium-transition font-medium"
            >
              Load More Products
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default ProductGrid;