import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const QuickAddModal = ({ isOpen, onClose, product, onAddToCart }) => {
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [quantity, setQuantity] = useState(1);

  const handleAddToCart = () => {
    if (product.sizes && product.sizes.length > 0 && !selectedSize) {
      return; // Size is required
    }

    const cartItem = {
      id: product.id,
      name: product.name,
      brand: product.brand,
      price: product.price,
      image: product.images[0],
      size: selectedSize,
      color: selectedColor || product.colors?.[0],
      quantity: quantity
    };

    onAddToCart(cartItem);
    onClose();
    
    // Reset selections
    setSelectedSize('');
    setSelectedColor('');
    setQuantity(1);
  };

  const handleQuantityChange = (change) => {
    const newQuantity = quantity + change;
    if (newQuantity >= 1 && newQuantity <= 10) {
      setQuantity(newQuantity);
    }
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  if (!isOpen || !product) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-modal flex items-center justify-center p-4">
      <div className="bg-background rounded-premium max-w-md w-full max-h-[90vh] overflow-y-auto premium-shadow-lg">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="font-heading font-semibold text-lg text-text-primary">
            Quick Add to Cart
          </h2>
          <button
            onClick={onClose}
            className="p-2 text-text-secondary hover:text-text-primary premium-transition"
          >
            <Icon name="X" size={24} />
          </button>
        </div>

        {/* Product Info */}
        <div className="p-6">
          <div className="flex space-x-4 mb-6">
            <div className="w-20 h-20 bg-surface rounded-premium overflow-hidden flex-shrink-0">
              <Image
                src={product.images[0]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1">
              <p className="text-sm text-text-secondary font-medium mb-1">
                {product.brand}
              </p>
              <h3 className="font-medium text-text-primary mb-2">
                {product.name}
              </h3>
              <p className="font-semibold text-text-primary">
                {formatPrice(product.price)}
              </p>
            </div>
          </div>

          {/* Size Selection */}
          {product.sizes && product.sizes.length > 0 && (
            <div className="mb-6">
              <label className="block text-sm font-medium text-text-primary mb-3">
                Size <span className="text-error">*</span>
              </label>
              <div className="grid grid-cols-4 gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`
                      py-2 px-3 text-sm font-medium border rounded-premium premium-transition
                      ${selectedSize === size
                        ? 'bg-accent text-accent-foreground border-accent'
                        : 'bg-background text-text-primary border-border hover:border-accent'
                      }
                    `}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Color Selection */}
          {product.colors && product.colors.length > 1 && (
            <div className="mb-6">
              <label className="block text-sm font-medium text-text-primary mb-3">
                Color
              </label>
              <div className="flex flex-wrap gap-3">
                {product.colors.map((color) => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`
                      w-8 h-8 rounded-full border-2 premium-transition
                      ${selectedColor === color
                        ? 'border-accent ring-2 ring-accent ring-opacity-30' :'border-border hover:border-accent'
                      }
                    `}
                    style={{ backgroundColor: color.toLowerCase() }}
                    title={color}
                  />
                ))}
              </div>
              {selectedColor && (
                <p className="text-sm text-text-secondary mt-2">
                  Selected: {selectedColor}
                </p>
              )}
            </div>
          )}

          {/* Quantity Selection */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-text-primary mb-3">
              Quantity
            </label>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => handleQuantityChange(-1)}
                disabled={quantity <= 1}
                className="w-8 h-8 flex items-center justify-center border border-border rounded-premium text-text-primary hover:border-accent disabled:opacity-50 disabled:cursor-not-allowed premium-transition"
              >
                <Icon name="Minus" size={16} />
              </button>
              <span className="font-medium text-text-primary min-w-[2rem] text-center">
                {quantity}
              </span>
              <button
                onClick={() => handleQuantityChange(1)}
                disabled={quantity >= 10}
                className="w-8 h-8 flex items-center justify-center border border-border rounded-premium text-text-primary hover:border-accent disabled:opacity-50 disabled:cursor-not-allowed premium-transition"
              >
                <Icon name="Plus" size={16} />
              </button>
            </div>
          </div>

          {/* Total Price */}
          <div className="flex items-center justify-between mb-6 p-4 bg-surface rounded-premium">
            <span className="font-medium text-text-primary">Total:</span>
            <span className="font-bold text-lg text-text-primary">
              {formatPrice(product.price * quantity)}
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              onClick={handleAddToCart}
              disabled={product.sizes && product.sizes.length > 0 && !selectedSize}
              className="flex-1"
              iconName="ShoppingBag"
              iconPosition="left"
            >
              Add to Cart
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickAddModal;