import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import GlobalHeader from '../../components/ui/GlobalHeader';
import FilterSidebar from '../../components/ui/FilterSidebar';
import FilterChips from './components/FilterChips';
import SortDropdown from './components/SortDropdown';
import ProductGrid from './components/ProductGrid';
import QuickAddModal from './components/QuickAddModal';
import Button from '../../components/ui/Button';
import allProducts from '../../data/products';

const ProductCatalogBrowse = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [isFilterSidebarOpen, setIsFilterSidebarOpen] = useState(false);
  const [isQuickAddModalOpen, setIsQuickAddModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [currentSort, setCurrentSort] = useState('relevance');
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [wishlistedProducts, setWishlistedProducts] = useState([]);
  
  const [filters, setFilters] = useState({
    category: [],
    brand: [],
    priceRange: { min: '', max: '' },
    size: [],
    color: [],
    rating: '',
    inStock: false,
    onSale: false
  });

  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);

  // Initialize products and apply URL filters
  useEffect(() => {
    // Apply URL parameters
    const category = searchParams.get('category');
    const sale = searchParams.get('sale');
    
    if (category) {
      setFilters(prev => ({
        ...prev,
        category: [category.charAt(0).toUpperCase() + category.slice(1)]
      }));
    }
    
    if (sale === 'true') {
      setFilters(prev => ({
        ...prev,
        onSale: true
      }));
    }

    setProducts(allProducts);
    
    // Load wishlist from localStorage
    const savedWishlist = localStorage.getItem('wishlist');
    if (savedWishlist) {
      setWishlistedProducts(JSON.parse(savedWishlist));
    }
  }, [searchParams]);

  // Filter and sort products
  useEffect(() => {
    let filtered = [...products];

    // Apply filters
    if (filters.category.length > 0) {
      filtered = filtered.filter(product => 
        filters.category.includes(product.category)
      );
    }

    if (filters.brand.length > 0) {
      filtered = filtered.filter(product => 
        filters.brand.includes(product.brand)
      );
    }

    if (filters.size.length > 0) {
      filtered = filtered.filter(product => 
        product.sizes?.some(size => filters.size.includes(size))
      );
    }

    if (filters.color.length > 0) {
      filtered = filtered.filter(product => 
        product.colors?.some(color => filters.color.includes(color))
      );
    }

    if (filters.priceRange.min || filters.priceRange.max) {
      const min = parseFloat(filters.priceRange.min) || 0;
      const max = parseFloat(filters.priceRange.max) || Infinity;
      filtered = filtered.filter(product => 
        product.price >= min && product.price <= max
      );
    }

    if (filters.rating) {
      filtered = filtered.filter(product => 
        product.rating >= filters.rating
      );
    }

    if (filters.inStock) {
      filtered = filtered.filter(product => product.inStock);
    }

    if (filters.onSale) {
      filtered = filtered.filter(product => product.isOnSale);
    }

    // Apply sorting
    switch (currentSort) {
      case 'price-low-high':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high-low':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      case 'newest':
        filtered.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
        break;
      case 'popularity':
        filtered.sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0));
        break;
      case 'name-a-z':
        filtered.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'name-z-a':
        filtered.sort((a, b) => b.name.localeCompare(a.name));
        break;
      default:
        // relevance - keep original order
        break;
    }

    setFilteredProducts(filtered);
    setCurrentPage(1);
    setHasMore(filtered.length > 24);
  }, [products, filters, currentSort]);

  const handleApplyFilters = useCallback((newFilters) => {
    setFilters(newFilters);
  }, []);

  const handleRemoveFilter = useCallback((filterType, value) => {
    setFilters(prev => {
      const newFilters = { ...prev };
      
      if (filterType === 'priceRange') {
        newFilters.priceRange = { min: '', max: '' };
      } else if (filterType === 'rating') {
        newFilters.rating = '';
      } else if (filterType === 'inStock' || filterType === 'onSale') {
        newFilters[filterType] = false;
      } else if (Array.isArray(newFilters[filterType])) {
        newFilters[filterType] = newFilters[filterType].filter(item => item !== value);
      }
      
      return newFilters;
    });
  }, []);

  const handleClearAllFilters = useCallback(() => {
    setFilters({
      category: [],
      brand: [],
      priceRange: { min: '', max: '' },
      size: [],
      color: [],
      rating: '',
      inStock: false,
      onSale: false
    });
  }, []);

  const handleQuickAdd = useCallback((product) => {
    setSelectedProduct(product);
    setIsQuickAddModalOpen(true);
  }, []);

  const handleAddToCart = useCallback((cartItem) => {
    const existingCart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existingItemIndex = existingCart.findIndex(item => 
      item.id === cartItem.id && 
      item.size === cartItem.size && 
      item.color === cartItem.color
    );

    if (existingItemIndex > -1) {
      existingCart[existingItemIndex].quantity += cartItem.quantity;
    } else {
      existingCart.push(cartItem);
    }

    localStorage.setItem('cart', JSON.stringify(existingCart));
    
    // Update cart count
    const totalItems = existingCart.reduce((sum, item) => sum + item.quantity, 0);
    localStorage.setItem('cartCount', totalItems.toString());
    
    console.log('Added to cart:', cartItem);
  }, []);

  const handleToggleWishlist = useCallback((productId) => {
    setWishlistedProducts(prev => {
      const newWishlist = prev.includes(productId)
        ? prev.filter(id => id !== productId)
        : [...prev, productId];
      
      localStorage.setItem('wishlist', JSON.stringify(newWishlist));
      return newWishlist;
    });
  }, []);

  const handleLoadMore = useCallback(() => {
    setIsLoading(true);
    setTimeout(() => {
      setCurrentPage(prev => prev + 1);
      setIsLoading(false);
      
      // Simulate end of results
      if (currentPage >= 3) {
        setHasMore(false);
      }
    }, 1000);
  }, [currentPage]);

  const displayedProducts = filteredProducts.slice(0, currentPage * 24);

  return (
    <div className="min-h-screen bg-background">
      <GlobalHeader />
      
      <main className="pt-16 lg:pt-18">
        {/* Filter Chips */}
        <FilterChips
          activeFilters={filters}
          onRemoveFilter={handleRemoveFilter}
          onClearAll={handleClearAllFilters}
          totalProducts={filteredProducts.length}
        />

        <div className="max-w-screen-2xl mx-auto px-5 lg:px-8 py-6">
          <div className="flex gap-8">
            {/* Desktop Filter Sidebar */}
            <div className="hidden lg:block w-80 flex-shrink-0">
              <div className="sticky top-24">
                <FilterSidebar
                  isOpen={true}
                  onClose={() => {}}
                  onApplyFilters={handleApplyFilters}
                />
              </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 min-w-0">
              {/* Mobile Controls */}
              <div className="flex items-center justify-between mb-6 lg:hidden">
                <Button
                  variant="outline"
                  onClick={() => setIsFilterSidebarOpen(true)}
                  iconName="Filter"
                  iconPosition="left"
                >
                  Filters
                </Button>
                
                <SortDropdown
                  currentSort={currentSort}
                  onSortChange={setCurrentSort}
                />
              </div>

              {/* Desktop Sort */}
              <div className="hidden lg:flex items-center justify-between mb-6">
                <h1 className="font-heading font-bold text-2xl text-text-primary">
                  Products
                </h1>
                
                <SortDropdown
                  currentSort={currentSort}
                  onSortChange={setCurrentSort}
                />
              </div>

              {/* Product Grid */}
              <ProductGrid
                products={displayedProducts}
                onQuickAdd={handleQuickAdd}
                onToggleWishlist={handleToggleWishlist}
                wishlistedProducts={wishlistedProducts}
                isLoading={isLoading}
                hasMore={hasMore}
                onLoadMore={handleLoadMore}
              />
            </div>
          </div>
        </div>
      </main>

      {/* Mobile Filter Sidebar */}
      <FilterSidebar
        isOpen={isFilterSidebarOpen}
        onClose={() => setIsFilterSidebarOpen(false)}
        onApplyFilters={handleApplyFilters}
      />

      {/* Quick Add Modal */}
      <QuickAddModal
        isOpen={isQuickAddModalOpen}
        onClose={() => setIsQuickAddModalOpen(false)}
        product={selectedProduct}
        onAddToCart={handleAddToCart}
      />
    </div>
  );
};

export default ProductCatalogBrowse;