import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ProductInfo = ({ product, onAddToCart, onAddToWishlist }) => {
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
    
    // Set default selections
    if (product.sizes && product.sizes.length > 0) {
      setSelectedSize(product.sizes[0]);
    }
    if (product.colors && product.colors.length > 0) {
      setSelectedColor(product.colors[0]);
    }
  }, [product]);

  const translations = {
    en: {
      inStock: 'In Stock',
      outOfStock: 'Out of Stock',
      size: 'Size',
      color: 'Color',
      quantity: 'Quantity',
      addToCart: 'Add to Cart',
      addToWishlist: 'Add to Wishlist',
      sizeGuide: 'Size Guide',
      share: 'Share',
      reviews: 'Reviews'
    },
    es: {
      inStock: 'En Stock',
      outOfStock: 'Agotado',
      size: 'Talla',
      color: 'Color',
      quantity: 'Cantidad',
      addToCart: 'Añadir al Carrito',
      addToWishlist: 'Añadir a Favoritos',
      sizeGuide: 'Guía de Tallas',
      share: 'Compartir',
      reviews: 'Reseñas'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const handleQuantityChange = (change) => {
    const newQuantity = quantity + change;
    if (newQuantity >= 1 && newQuantity <= product.stock) {
      setQuantity(newQuantity);
    }
  };

  const handleAddToCart = () => {
    const cartItem = {
      ...product,
      selectedSize,
      selectedColor,
      quantity
    };
    onAddToCart(cartItem);
  };

  const renderStars = (rating) => {
    return [...Array(5)].map((_, i) => (
      <Icon
        key={i}
        name="Star"
        size={16}
        className={i < Math.floor(rating) ? 'text-accent fill-current' : 'text-border'}
      />
    ));
  };

  return (
    <div className="space-y-6">
      {/* Brand and Name */}
      <div>
        <p className="text-sm font-medium text-accent uppercase tracking-wide mb-1">
          {product.brand}
        </p>
        <h1 className="text-2xl lg:text-3xl font-heading font-bold text-text-primary">
          {product.name}
        </h1>
      </div>

      {/* Price and Rating */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {product.originalPrice && product.originalPrice > product.price && (
            <span className="text-lg text-text-secondary line-through">
              ${product.originalPrice}
            </span>
          )}
          <span className="text-2xl font-bold text-text-primary">
            ${product.price}
          </span>
          {product.originalPrice && product.originalPrice > product.price && (
            <span className="bg-error text-error-foreground px-2 py-1 rounded-premium text-sm font-medium">
              -{Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%
            </span>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          <div className="flex space-x-1">
            {renderStars(product.rating)}
          </div>
          <span className="text-sm text-text-secondary">
            ({product.reviewCount} {t.reviews})
          </span>
        </div>
      </div>

      {/* Stock Status */}
      <div className="flex items-center space-x-2">
        <div className={`w-3 h-3 rounded-full ${product.inStock ? 'bg-success' : 'bg-error'}`} />
        <span className={`text-sm font-medium ${product.inStock ? 'text-success' : 'text-error'}`}>
          {product.inStock ? t.inStock : t.outOfStock}
        </span>
        {product.inStock && (
          <span className="text-sm text-text-secondary">
            ({product.stock} available)
          </span>
        )}
      </div>

      {/* Size Selection */}
      {product.sizes && product.sizes.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <label className="text-sm font-medium text-text-primary">{t.size}</label>
            <button className="text-sm text-accent hover:text-accent-foreground premium-transition">
              {t.sizeGuide}
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {product.sizes.map((size) => (
              <button
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`px-4 py-2 border rounded-premium text-sm font-medium premium-transition ${
                  selectedSize === size
                    ? 'border-accent bg-accent text-accent-foreground'
                    : 'border-border text-text-primary hover:border-accent'
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Color Selection */}
      {product.colors && product.colors.length > 0 && (
        <div>
          <label className="block text-sm font-medium text-text-primary mb-3">{t.color}</label>
          <div className="flex flex-wrap gap-3">
            {product.colors.map((color) => (
              <button
                key={color}
                onClick={() => setSelectedColor(color)}
                className={`w-10 h-10 rounded-full border-2 premium-transition ${
                  selectedColor === color
                    ? 'border-accent ring-2 ring-accent ring-opacity-30' :'border-border hover:border-accent'
                }`}
                style={{ backgroundColor: color.toLowerCase() }}
                aria-label={color}
              />
            ))}
          </div>
          {selectedColor && (
            <p className="text-sm text-text-secondary mt-2 capitalize">
              Selected: {selectedColor}
            </p>
          )}
        </div>
      )}

      {/* Quantity Selection */}
      <div>
        <label className="block text-sm font-medium text-text-primary mb-3">{t.quantity}</label>
        <div className="flex items-center space-x-4">
          <div className="flex items-center border border-border rounded-premium">
            <button
              onClick={() => handleQuantityChange(-1)}
              disabled={quantity <= 1}
              className="w-10 h-10 flex items-center justify-center text-text-primary hover:text-accent disabled:opacity-50 disabled:cursor-not-allowed premium-transition"
            >
              <Icon name="Minus" size={16} />
            </button>
            <span className="w-12 text-center font-medium text-text-primary">
              {quantity}
            </span>
            <button
              onClick={() => handleQuantityChange(1)}
              disabled={quantity >= product.stock}
              className="w-10 h-10 flex items-center justify-center text-text-primary hover:text-accent disabled:opacity-50 disabled:cursor-not-allowed premium-transition"
            >
              <Icon name="Plus" size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button
          variant="primary"
          onClick={handleAddToCart}
          disabled={!product.inStock || (!selectedSize && product.sizes?.length > 0) || (!selectedColor && product.colors?.length > 0)}
          className="w-full"
          iconName="ShoppingCart"
          iconPosition="left"
        >
          {t.addToCart}
        </Button>
        
        <div className="flex space-x-3">
          <Button
            variant="outline"
            onClick={onAddToWishlist}
            className="flex-1"
            iconName="Heart"
            iconPosition="left"
          >
            {t.addToWishlist}
          </Button>
          
          <Button
            variant="ghost"
            className="flex-1"
            iconName="Share"
            iconPosition="left"
          >
            {t.share}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductInfo;