import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const ProductTabs = ({ product }) => {
  const [activeTab, setActiveTab] = useState('description');
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      description: 'Description',
      careInstructions: 'Care Instructions',
      sizeGuide: 'Size Guide',
      shipping: 'Shipping & Returns'
    },
    es: {
      description: 'Descripción',
      careInstructions: 'Instrucciones de Cuidado',
      sizeGuide: 'Guía de Tallas',
      shipping: 'Envío y Devoluciones'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const tabs = [
    {
      id: 'description',
      label: t.description,
      icon: 'FileText'
    },
    {
      id: 'care',
      label: t.careInstructions,
      icon: 'Heart'
    },
    {
      id: 'size',
      label: t.sizeGuide,
      icon: 'Ruler'
    },
    {
      id: 'shipping',
      label: t.shipping,
      icon: 'Truck'
    }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'description':
        return (
          <div className="prose prose-sm max-w-none">
            <p className="text-text-primary leading-relaxed">
              {product.description}
            </p>
            {product.features && (
              <div className="mt-4">
                <h4 className="font-medium text-text-primary mb-2">Key Features:</h4>
                <ul className="space-y-1">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <Icon name="Check" size={16} className="text-success mt-0.5 flex-shrink-0" />
                      <span className="text-text-secondary">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        );
      
      case 'care':
        return (
          <div className="space-y-4">
            {product.careInstructions?.map((instruction, index) => (
              <div key={index} className="flex items-start space-x-3">
                <Icon name="Info" size={16} className="text-accent mt-0.5 flex-shrink-0" />
                <span className="text-text-primary">{instruction}</span>
              </div>
            ))}
          </div>
        );
      
      case 'size':
        return (
          <div className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 px-3 text-sm font-medium text-text-primary">Size</th>
                    <th className="text-left py-2 px-3 text-sm font-medium text-text-primary">Chest</th>
                    <th className="text-left py-2 px-3 text-sm font-medium text-text-primary">Waist</th>
                    <th className="text-left py-2 px-3 text-sm font-medium text-text-primary">Hip</th>
                  </tr>
                </thead>
                <tbody>
                  {product.sizeChart?.map((size, index) => (
                    <tr key={index} className="border-b border-border-light">
                      <td className="py-2 px-3 text-sm text-text-primary font-medium">{size.size}</td>
                      <td className="py-2 px-3 text-sm text-text-secondary">{size.chest}</td>
                      <td className="py-2 px-3 text-sm text-text-secondary">{size.waist}</td>
                      <td className="py-2 px-3 text-sm text-text-secondary">{size.hip}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      
      case 'shipping':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <h4 className="font-medium text-text-primary">Shipping Options</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-text-secondary">Standard Shipping</span>
                    <span className="text-text-primary">5-7 days - Free</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-text-secondary">Express Shipping</span>
                    <span className="text-text-primary">2-3 days - $9.99</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-text-secondary">Next Day</span>
                    <span className="text-text-primary">1 day - $19.99</span>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <h4 className="font-medium text-text-primary">Returns</h4>
                <div className="space-y-2 text-sm text-text-secondary">
                  <p>• 30-day return policy</p>
                  <p>• Free returns on orders over $50</p>
                  <p>• Items must be in original condition</p>
                  <p>• Return shipping label provided</p>
                </div>
              </div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="bg-surface rounded-premium p-6">
      {/* Tab Navigation */}
      <div className="flex space-x-1 mb-6 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-premium text-sm font-medium premium-transition whitespace-nowrap ${
              activeTab === tab.id
                ? 'bg-accent text-accent-foreground'
                : 'text-text-secondary hover:text-text-primary hover:bg-background'
            }`}
          >
            <Icon name={tab.icon} size={16} />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="min-h-[200px]">
        {renderTabContent()}
      </div>
    </div>
  );
};

export default ProductTabs;