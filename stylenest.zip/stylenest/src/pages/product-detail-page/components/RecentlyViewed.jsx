import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const RecentlyViewed = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [recentlyViewed, setRecentlyViewed] = useState([]);

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
    
    // Mock recently viewed products
    const mockRecentlyViewed = [
      {
        id: 7,
        name: "Classic White Sneakers",
        brand: "SportLux",
        price: 129.99,
        image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=300&h=300&fit=crop",
        rating: 4.3
      },
      {
        id: 8,
        name: "Denim Jacket",
        brand: "UrbanStyle",
        price: 89.99,
        image: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=300&h=300&fit=crop",
        rating: 4.5
      },
      {
        id: 9,
        name: "Leather Watch",
        brand: "TimeClass",
        price: 199.99,
        image: "https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=300&h=300&fit=crop",
        rating: 4.7
      },
      {
        id: 10,
        name: "Summer Dress",
        brand: "FloralFashion",
        price: 79.99,
        image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=300&h=300&fit=crop",
        rating: 4.4
      }
    ];
    
    setRecentlyViewed(mockRecentlyViewed);
  }, []);

  const translations = {
    en: {
      recentlyViewed: 'Recently Viewed',
      viewAll: 'View All'
    },
    es: {
      recentlyViewed: 'Vistos Recientemente',
      viewAll: 'Ver Todo'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const renderStars = (rating) => {
    return [...Array(5)].map((_, i) => (
      <Icon
        key={i}
        name="Star"
        size={12}
        className={i < Math.floor(rating) ? 'text-accent fill-current' : 'text-border'}
      />
    ));
  };

  if (recentlyViewed.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-heading font-bold text-text-primary">
          {t.recentlyViewed}
        </h2>
        <Link
          to="/product-catalog-browse?recently-viewed=true"
          className="text-sm text-accent hover:text-accent-foreground premium-transition"
        >
          {t.viewAll}
        </Link>
      </div>

      {/* Products List */}
      <div className="flex space-x-4 overflow-x-auto pb-2">
        {recentlyViewed.map((product) => (
          <Link
            key={product.id}
            to={`/product-detail-page?id=${product.id}`}
            className="flex-shrink-0 w-32 group"
          >
            <div className="bg-surface rounded-premium overflow-hidden premium-hover-scale">
              {/* Product Image */}
              <div className="aspect-square overflow-hidden">
                <Image
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 premium-transition"
                />
              </div>

              {/* Product Info */}
              <div className="p-3 space-y-1">
                <p className="text-xs font-medium text-accent uppercase tracking-wide">
                  {product.brand}
                </p>
                <h3 className="text-sm font-medium text-text-primary line-clamp-2 group-hover:text-accent premium-transition">
                  {product.name}
                </h3>
                
                {/* Rating */}
                <div className="flex items-center space-x-1">
                  <div className="flex space-x-1">
                    {renderStars(product.rating)}
                  </div>
                  <span className="text-xs text-text-secondary">
                    {product.rating}
                  </span>
                </div>

                {/* Price */}
                <p className="text-sm font-bold text-text-primary">
                  ${product.price}
                </p>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default RecentlyViewed;