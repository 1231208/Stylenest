import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const RelatedProducts = ({ currentProductId, category }) => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      relatedProducts: 'Related Products',
      youMayAlsoLike: 'You May Also Like',
      addToCart: 'Add to Cart',
      quickView: 'Quick View',
      sale: 'Sale'
    },
    es: {
      relatedProducts: 'Productos Relacionados',
      youMayAlsoLike: 'También Te Puede Gustar',
      addToCart: 'Añadir al Carrito',
      quickView: 'Vista Rápida',
      sale: 'Oferta'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  // Mock related products data
  const relatedProducts = [
    {
      id: 2,
      name: "Premium Silk Blouse",
      brand: "Elegance",
      price: 89.99,
      originalPrice: 129.99,
      image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400&h=400&fit=crop",
      rating: 4.6,
      reviewCount: 89,
      inStock: true,
      isOnSale: true
    },
    {
      id: 3,
      name: "Designer Leather Handbag",
      brand: "LuxeCraft",
      price: 299.99,
      originalPrice: null,
      image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&h=400&fit=crop",
      rating: 4.8,
      reviewCount: 156,
      inStock: true,
      isOnSale: false
    },
    {
      id: 4,
      name: "Cashmere Scarf",
      brand: "WarmLux",
      price: 79.99,
      originalPrice: 99.99,
      image: "https://images.unsplash.com/photo-1601924994987-69e26d50dc26?w=400&h=400&fit=crop",
      rating: 4.4,
      reviewCount: 67,
      inStock: true,
      isOnSale: true
    },
    {
      id: 5,
      name: "Pearl Earrings",
      brand: "Jewelry Co",
      price: 149.99,
      originalPrice: null,
      image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400&h=400&fit=crop",
      rating: 4.9,
      reviewCount: 203,
      inStock: false,
      isOnSale: false
    },
    {
      id: 6,
      name: "Wool Coat",
      brand: "WinterStyle",
      price: 199.99,
      originalPrice: 279.99,
      image: "https://images.unsplash.com/photo-1544966503-7cc5ac882d5f?w=400&h=400&fit=crop",
      rating: 4.5,
      reviewCount: 124,
      inStock: true,
      isOnSale: true
    }
  ];

  const itemsPerView = {
    mobile: 2,
    tablet: 3,
    desktop: 4
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => 
      prev + itemsPerView.desktop >= relatedProducts.length ? 0 : prev + 1
    );
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => 
      prev === 0 ? Math.max(0, relatedProducts.length - itemsPerView.desktop) : prev - 1
    );
  };

  const renderStars = (rating) => {
    return [...Array(5)].map((_, i) => (
      <Icon
        key={i}
        name="Star"
        size={14}
        className={i < Math.floor(rating) ? 'text-accent fill-current' : 'text-border'}
      />
    ));
  };

  const handleAddToCart = (product) => {
    console.log('Adding to cart:', product);
    // Add to cart logic
  };

  const handleQuickView = (product) => {
    console.log('Quick view:', product);
    // Quick view modal logic
  };

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-heading font-bold text-text-primary">
          {t.youMayAlsoLike}
        </h2>
        
        {/* Navigation Arrows - Desktop */}
        <div className="hidden lg:flex items-center space-x-2">
          <button
            onClick={prevSlide}
            className="w-10 h-10 bg-surface hover:bg-accent hover:text-accent-foreground rounded-full flex items-center justify-center premium-transition"
            aria-label="Previous products"
          >
            <Icon name="ChevronLeft" size={20} />
          </button>
          <button
            onClick={nextSlide}
            className="w-10 h-10 bg-surface hover:bg-accent hover:text-accent-foreground rounded-full flex items-center justify-center premium-transition"
            aria-label="Next products"
          >
            <Icon name="ChevronRight" size={20} />
          </button>
        </div>
      </div>

      {/* Products Grid/Carousel */}
      <div className="relative">
        <div className="overflow-hidden">
          <div 
            className="flex transition-transform duration-300 ease-premium"
            style={{
              transform: `translateX(-${currentIndex * (100 / itemsPerView.desktop)}%)`
            }}
          >
            {relatedProducts.map((product) => (
              <div
                key={product.id}
                className="w-1/2 md:w-1/3 lg:w-1/4 flex-shrink-0 px-2"
              >
                <div className="bg-background border border-border rounded-premium overflow-hidden group premium-hover-scale">
                  {/* Product Image */}
                  <div className="relative aspect-square overflow-hidden">
                    <Link to={`/product-detail-page?id=${product.id}`}>
                      <Image
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-105 premium-transition-long"
                      />
                    </Link>
                    
                    {/* Sale Badge */}
                    {product.isOnSale && (
                      <div className="absolute top-3 left-3 bg-error text-error-foreground px-2 py-1 rounded-premium text-xs font-medium">
                        {t.sale}
                      </div>
                    )}

                    {/* Quick Actions */}
                    <div className="absolute top-3 right-3 flex flex-col space-y-2 opacity-0 group-hover:opacity-100 premium-transition">
                      <button
                        onClick={() => handleQuickView(product)}
                        className="w-8 h-8 bg-background bg-opacity-90 hover:bg-accent hover:text-accent-foreground rounded-full flex items-center justify-center premium-transition"
                        aria-label="Quick view"
                      >
                        <Icon name="Eye" size={16} />
                      </button>
                      <button
                        className="w-8 h-8 bg-background bg-opacity-90 hover:bg-accent hover:text-accent-foreground rounded-full flex items-center justify-center premium-transition"
                        aria-label="Add to wishlist"
                      >
                        <Icon name="Heart" size={16} />
                      </button>
                    </div>

                    {/* Stock Status */}
                    {!product.inStock && (
                      <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                        <span className="text-white font-medium">Out of Stock</span>
                      </div>
                    )}
                  </div>

                  {/* Product Info */}
                  <div className="p-4 space-y-2">
                    <div>
                      <p className="text-xs font-medium text-accent uppercase tracking-wide">
                        {product.brand}
                      </p>
                      <Link 
                        to={`/product-detail-page?id=${product.id}`}
                        className="block font-medium text-text-primary hover:text-accent premium-transition line-clamp-2"
                      >
                        {product.name}
                      </Link>
                    </div>

                    {/* Rating */}
                    <div className="flex items-center space-x-2">
                      <div className="flex space-x-1">
                        {renderStars(product.rating)}
                      </div>
                      <span className="text-xs text-text-secondary">
                        ({product.reviewCount})
                      </span>
                    </div>

                    {/* Price */}
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-text-primary">
                        ${product.price}
                      </span>
                      {product.originalPrice && (
                        <span className="text-sm text-text-secondary line-through">
                          ${product.originalPrice}
                        </span>
                      )}
                    </div>

                    {/* Add to Cart Button */}
                    <Button
                      variant="outline"
                      onClick={() => handleAddToCart(product)}
                      disabled={!product.inStock}
                      className="w-full mt-3"
                      iconName="ShoppingCart"
                      iconPosition="left"
                    >
                      {t.addToCart}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Mobile Navigation Dots */}
        <div className="flex justify-center space-x-2 mt-4 lg:hidden">
          {Array.from({ length: Math.ceil(relatedProducts.length / itemsPerView.mobile) }).map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index * itemsPerView.mobile)}
              className={`w-2 h-2 rounded-full premium-transition ${
                Math.floor(currentIndex / itemsPerView.mobile) === index
                  ? 'bg-accent' :'bg-border hover:bg-accent'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default RelatedProducts;