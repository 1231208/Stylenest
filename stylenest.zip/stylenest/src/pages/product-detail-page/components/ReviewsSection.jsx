import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const ReviewsSection = ({ productId, reviews, averageRating, totalReviews }) => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [sortBy, setSortBy] = useState('newest');
  const [filterRating, setFilterRating] = useState('all');
  const [showAllReviews, setShowAllReviews] = useState(false);

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      reviews: 'Reviews',
      writeReview: 'Write a Review',
      sortBy: 'Sort by',
      filterBy: 'Filter by rating',
      newest: 'Newest',
      oldest: 'Oldest',
      highest: 'Highest Rating',
      lowest: 'Lowest Rating',
      mostHelpful: 'Most Helpful',
      allRatings: 'All Ratings',
      verified: 'Verified Purchase',
      helpful: 'Helpful',
      notHelpful: 'Not Helpful',
      showMore: 'Show More Reviews',
      showLess: 'Show Less Reviews',
      outOf: 'out of',
      stars: 'stars'
    },
    es: {
      reviews: 'Reseñas',
      writeReview: 'Escribir Reseña',
      sortBy: 'Ordenar por',
      filterBy: 'Filtrar por calificación',
      newest: 'Más Recientes',
      oldest: 'Más Antiguos',
      highest: 'Calificación Más Alta',
      lowest: 'Calificación Más Baja',
      mostHelpful: 'Más Útiles',
      allRatings: 'Todas las Calificaciones',
      verified: 'Compra Verificada',
      helpful: 'Útil',
      notHelpful: 'No Útil',
      showMore: 'Mostrar Más Reseñas',
      showLess: 'Mostrar Menos Reseñas',
      outOf: 'de',
      stars: 'estrellas'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const renderStars = (rating, size = 16) => {
    return [...Array(5)].map((_, i) => (
      <Icon
        key={i}
        name="Star"
        size={size}
        className={i < Math.floor(rating) ? 'text-accent fill-current' : 'text-border'}
      />
    ));
  };

  const getRatingDistribution = () => {
    const distribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    reviews.forEach(review => {
      distribution[review.rating]++;
    });
    return distribution;
  };

  const ratingDistribution = getRatingDistribution();
  const displayedReviews = showAllReviews ? reviews : reviews.slice(0, 3);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(currentLanguage === 'es' ? 'es-ES' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      {/* Reviews Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-heading font-bold text-text-primary">
          {t.reviews} ({totalReviews})
        </h2>
        <Button variant="outline" iconName="Edit" iconPosition="left">
          {t.writeReview}
        </Button>
      </div>

      {/* Rating Summary */}
      <div className="bg-surface rounded-premium p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Overall Rating */}
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start space-x-2 mb-2">
              <span className="text-3xl font-bold text-text-primary">{averageRating}</span>
              <div className="flex space-x-1">
                {renderStars(averageRating, 20)}
              </div>
            </div>
            <p className="text-text-secondary">
              Based on {totalReviews} {t.reviews}
            </p>
          </div>

          {/* Rating Distribution */}
          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map((rating) => (
              <div key={rating} className="flex items-center space-x-3">
                <span className="text-sm text-text-secondary w-8">{rating}</span>
                <Icon name="Star" size={14} className="text-accent fill-current" />
                <div className="flex-1 bg-border rounded-full h-2">
                  <div
                    className="bg-accent h-2 rounded-full"
                    style={{
                      width: `${totalReviews > 0 ? (ratingDistribution[rating] / totalReviews) * 100 : 0}%`
                    }}
                  />
                </div>
                <span className="text-sm text-text-secondary w-8">
                  {ratingDistribution[rating]}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Filters and Sorting */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-3 sm:space-y-0">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <label className="text-sm font-medium text-text-primary">{t.sortBy}:</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="text-sm border border-border rounded-premium px-3 py-1 bg-background text-text-primary focus:ring-2 focus:ring-accent focus:border-accent"
            >
              <option value="newest">{t.newest}</option>
              <option value="oldest">{t.oldest}</option>
              <option value="highest">{t.highest}</option>
              <option value="lowest">{t.lowest}</option>
              <option value="helpful">{t.mostHelpful}</option>
            </select>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <label className="text-sm font-medium text-text-primary">{t.filterBy}:</label>
          <select
            value={filterRating}
            onChange={(e) => setFilterRating(e.target.value)}
            className="text-sm border border-border rounded-premium px-3 py-1 bg-background text-text-primary focus:ring-2 focus:ring-accent focus:border-accent"
          >
            <option value="all">{t.allRatings}</option>
            <option value="5">5 {t.stars}</option>
            <option value="4">4 {t.stars}</option>
            <option value="3">3 {t.stars}</option>
            <option value="2">2 {t.stars}</option>
            <option value="1">1 {t.stars}</option>
          </select>
        </div>
      </div>

      {/* Reviews List */}
      <div className="space-y-6">
        {displayedReviews.map((review) => (
          <div key={review.id} className="border-b border-border pb-6 last:border-b-0 last:pb-0">
            <div className="flex items-start space-x-4">
              {/* User Avatar */}
              <div className="w-12 h-12 bg-surface rounded-full flex items-center justify-center flex-shrink-0">
                {review.userAvatar ? (
                  <Image
                    src={review.userAvatar}
                    alt={review.userName}
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <Icon name="User" size={24} className="text-text-secondary" />
                )}
              </div>

              {/* Review Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h4 className="font-medium text-text-primary">{review.userName}</h4>
                    <div className="flex items-center space-x-2 mt-1">
                      <div className="flex space-x-1">
                        {renderStars(review.rating)}
                      </div>
                      <span className="text-sm text-text-secondary">
                        {formatDate(review.date)}
                      </span>
                      {review.verified && (
                        <span className="text-xs bg-success text-success-foreground px-2 py-1 rounded-premium">
                          {t.verified}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <p className="text-text-primary mb-3 leading-relaxed">
                  {review.comment}
                </p>

                {/* Review Images */}
                {review.images && review.images.length > 0 && (
                  <div className="flex space-x-2 mb-3">
                    {review.images.map((image, index) => (
                      <div key={index} className="w-16 h-16 rounded-premium overflow-hidden">
                        <Image
                          src={image}
                          alt={`Review image ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                )}

                {/* Helpful Actions */}
                <div className="flex items-center space-x-4">
                  <button className="flex items-center space-x-1 text-sm text-text-secondary hover:text-accent premium-transition">
                    <Icon name="ThumbsUp" size={14} />
                    <span>{t.helpful} ({review.helpfulCount || 0})</span>
                  </button>
                  <button className="flex items-center space-x-1 text-sm text-text-secondary hover:text-accent premium-transition">
                    <Icon name="ThumbsDown" size={14} />
                    <span>{t.notHelpful}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Show More/Less Button */}
      {reviews.length > 3 && (
        <div className="text-center">
          <Button
            variant="outline"
            onClick={() => setShowAllReviews(!showAllReviews)}
          >
            {showAllReviews ? t.showLess : t.showMore}
          </Button>
        </div>
      )}
    </div>
  );
};

export default ReviewsSection;