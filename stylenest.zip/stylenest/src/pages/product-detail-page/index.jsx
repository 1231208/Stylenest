import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import GlobalHeader from '../../components/ui/GlobalHeader';
import Icon from '../../components/AppIcon';
import ProductImageGallery from './components/ProductImageGallery';
import ProductInfo from './components/ProductInfo';
import ProductTabs from './components/ProductTabs';
import ReviewsSection from './components/ReviewsSection';
import RelatedProducts from './components/RelatedProducts';
import RecentlyViewed from './components/RecentlyViewed';

const ProductDetailPage = () => {
  const [searchParams] = useSearchParams();
  const productId = searchParams.get('id') || '1';
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
    
    // Mock product data
    const mockProduct = {
      id: productId,
      name: "Premium Cashmere Sweater",
      brand: "LuxeKnit",
      price: 189.99,
      originalPrice: 249.99,
      rating: 4.7,
      reviewCount: 234,
      inStock: true,
      stock: 15,
      images: [
        "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&h=600&fit=crop",
        "https://images.unsplash.com/photo-1583743814966-8936f37f4678?w=600&h=600&fit=crop",
        "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=600&h=600&fit=crop",
        "https://images.unsplash.com/photo-1571945153237-4929e783af4a?w=600&h=600&fit=crop"
      ],
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      colors: ['Beige', 'Navy', 'Black', 'Gray'],
      description: `Crafted from the finest cashmere fibers, this premium sweater offers unparalleled softness and warmth. The classic design features a comfortable crew neck and relaxed fit, making it perfect for both casual and professional settings.\n\nThis luxurious piece is designed to last, with reinforced seams and careful attention to detail. The natural breathability of cashmere ensures comfort throughout the day, while the timeless style makes it a versatile addition to any wardrobe.`,
      features: [
        "100% Premium Cashmere",
        "Reinforced seams for durability",
        "Machine washable (gentle cycle)",
        "Available in multiple colors",
        "Sustainable sourcing",
        "Hypoallergenic material"
      ],
      careInstructions: [
        "Machine wash cold on gentle cycle",
        "Use mild detergent, avoid bleach",
        "Lay flat to dry, do not wring",
        "Iron on low heat if needed",
        "Store folded to maintain shape",
        "Professional dry cleaning recommended"
      ],
      sizeChart: [
        { size: 'XS', chest: '32-34"', waist: '26-28"', hip: '34-36"' },
        { size: 'S', chest: '34-36"', waist: '28-30"', hip: '36-38"' },
        { size: 'M', chest: '36-38"', waist: '30-32"', hip: '38-40"' },
        { size: 'L', chest: '38-40"', waist: '32-34"', hip: '40-42"' },
        { size: 'XL', chest: '40-42"', waist: '34-36"', hip: '42-44"' }
      ]
    };

    // Mock reviews data
    const mockReviews = [
      {
        id: 1,
        userName: "Sarah Johnson",
        userAvatar: "https://randomuser.me/api/portraits/women/1.jpg",
        rating: 5,
        date: "2024-01-15",
        verified: true,
        comment: "Absolutely love this sweater! The cashmere is incredibly soft and the fit is perfect. I\'ve received so many compliments wearing it. Definitely worth the investment.",
        helpfulCount: 12,
        images: []
      },
      {
        id: 2,
        userName: "Michael Chen",
        userAvatar: "https://randomuser.me/api/portraits/men/2.jpg",
        rating: 4,
        date: "2024-01-10",
        verified: true,
        comment: "Great quality sweater, very comfortable and warm. The only reason I'm not giving 5 stars is that it's a bit pricey, but the quality justifies the cost.",
        helpfulCount: 8,
        images: []
      },
      {
        id: 3,
        userName: "Emma Rodriguez",
        userAvatar: "https://randomuser.me/api/portraits/women/3.jpg",
        rating: 5,
        date: "2024-01-05",
        verified: true,
        comment: "This is my second purchase from this brand and I\'m never disappointed. The cashmere is luxurious and the color is exactly as shown. Highly recommend!",
        helpfulCount: 15,
        images: [
          "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=200&h=200&fit=crop"
        ]
      }
    ];

    setProduct({ ...mockProduct, reviews: mockReviews });
    setLoading(false);
  }, [productId]);

  const translations = {
    en: {
      home: 'Home',
      loading: 'Loading...',
      addedToCart: 'Added to cart successfully!',
      addedToWishlist: 'Added to wishlist!',
      backToProducts: 'Back to Products'
    },
    es: {
      home: 'Inicio',
      loading: 'Cargando...',
      addedToCart: '¡Añadido al carrito exitosamente!',
      addedToWishlist: '¡Añadido a favoritos!',
      backToProducts: 'Volver a Productos'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const handleAddToCart = (cartItem) => {
    console.log('Adding to cart:', cartItem);
    // Add to cart logic here
    alert(t.addedToCart);
  };

  const handleAddToWishlist = () => {
    console.log('Adding to wishlist:', product);
    // Add to wishlist logic here
    alert(t.addedToWishlist);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <GlobalHeader />
        <div className="pt-20 flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <Icon name="Loader2" size={48} className="text-accent animate-spin mx-auto mb-4" />
            <p className="text-text-secondary">{t.loading}</p>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <GlobalHeader />
        <div className="pt-20 flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <Icon name="AlertCircle" size={48} className="text-error mx-auto mb-4" />
            <p className="text-text-primary mb-4">Product not found</p>
            <Link
              to="/product-catalog-browse"
              className="text-accent hover:text-accent-foreground premium-transition"
            >
              {t.backToProducts}
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <GlobalHeader />
      
      {/* Main Content */}
      <main className="pt-20">
        <div className="max-w-screen-2xl mx-auto px-5 lg:px-8">
          {/* Breadcrumb */}
          <nav className="py-4 text-sm" aria-label="Breadcrumb">
            <ol className="flex items-center space-x-2 text-text-secondary">
              <li>
                <Link to="/home-landing-page" className="hover:text-accent premium-transition">
                  {t.home}
                </Link>
              </li>
              <li>
                <Icon name="ChevronRight" size={16} />
              </li>
              <li>
                <Link to="/product-catalog-browse" className="hover:text-accent premium-transition">
                  Products
                </Link>
              </li>
              <li>
                <Icon name="ChevronRight" size={16} />
              </li>
              <li>
                <span className="text-text-primary font-medium">{product.brand}</span>
              </li>
              <li>
                <Icon name="ChevronRight" size={16} />
              </li>
              <li>
                <span className="text-text-primary font-medium truncate">{product.name}</span>
              </li>
            </ol>
          </nav>

          {/* Product Details */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 mb-12">
            {/* Product Images */}
            <div className="order-1">
              <ProductImageGallery 
                images={product.images} 
                productName={product.name} 
              />
            </div>

            {/* Product Information */}
            <div className="order-2">
              <div className="lg:sticky lg:top-24">
                <ProductInfo
                  product={product}
                  onAddToCart={handleAddToCart}
                  onAddToWishlist={handleAddToWishlist}
                />
              </div>
            </div>
          </div>

          {/* Product Details Tabs */}
          <div className="mb-12">
            <ProductTabs product={product} />
          </div>

          {/* Reviews Section */}
          <div className="mb-12">
            <ReviewsSection
              productId={product.id}
              reviews={product.reviews}
              averageRating={product.rating}
              totalReviews={product.reviewCount}
            />
          </div>

          {/* Related Products */}
          <div className="mb-12">
            <RelatedProducts
              currentProductId={product.id}
              category={product.category}
            />
          </div>

          {/* Recently Viewed */}
          <div className="mb-12">
            <RecentlyViewed />
          </div>
        </div>
      </main>

      {/* Mobile Sticky Footer */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-background border-t border-border p-4 z-navigation">
        <div className="flex space-x-3">
          <button
            onClick={handleAddToWishlist}
            className="w-12 h-12 border border-border rounded-premium flex items-center justify-center text-text-primary hover:text-accent hover:border-accent premium-transition"
            aria-label="Add to wishlist"
          >
            <Icon name="Heart" size={24} />
          </button>
          <button
            onClick={() => handleAddToCart({
              ...product,
              selectedSize: product.sizes?.[0] || '',
              selectedColor: product.colors?.[0] || '',
              quantity: 1
            })}
            disabled={!product.inStock}
            className="flex-1 bg-accent text-accent-foreground rounded-premium py-3 px-6 font-medium disabled:opacity-50 disabled:cursor-not-allowed premium-transition hover:bg-opacity-90"
          >
            Add to Cart
          </button>
        </div>
      </div>

      {/* Mobile Bottom Spacing */}
      <div className="lg:hidden h-20" />
    </div>
  );
};

export default ProductDetailPage;