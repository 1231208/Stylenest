import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const CartItem = ({ item, onUpdateQuantity, onRemoveItem, onMoveToWishlist, currentLanguage }) => {
  const [isUpdating, setIsUpdating] = useState(false);

  const translations = {
    en: {
      remove: 'Remove',
      moveToWishlist: 'Move to Wishlist',
      size: 'Size',
      color: 'Color',
      inStock: 'In Stock',
      outOfStock: 'Out of Stock',
      lowStock: 'Only {count} left'
    },
    es: {
      remove: 'Eliminar',
      moveToWishlist: 'Mover a Lista de Deseos',
      size: 'Talla',
      color: 'Color',
      inStock: 'En Stock',
      outOfStock: 'Agotado',
      lowStock: 'Solo quedan {count}'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const handleQuantityChange = async (newQuantity) => {
    if (newQuantity < 1 || newQuantity > 10) return;
    
    setIsUpdating(true);
    await new Promise(resolve => setTimeout(resolve, 300));
    onUpdateQuantity(item.id, newQuantity);
    setIsUpdating(false);
  };

  const getStockStatus = () => {
    if (item.stock === 0) return { text: t.outOfStock, color: 'text-error' };
    if (item.stock <= 3) return { text: t.lowStock.replace('{count}', item.stock), color: 'text-warning' };
    return { text: t.inStock, color: 'text-success' };
  };

  const stockStatus = getStockStatus();

  return (
    <div className="bg-background border border-border rounded-premium p-4 premium-shadow-sm">
      <div className="flex space-x-4">
        {/* Product Image */}
        <div className="flex-shrink-0 w-20 h-20 sm:w-24 sm:h-24 overflow-hidden rounded-premium">
          <Image
            src={item.image}
            alt={item.name}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Product Details */}
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start mb-2">
            <div className="flex-1 min-w-0">
              <h3 className="font-heading font-semibold text-text-primary truncate">
                {item.name}
              </h3>
              <p className="text-sm text-text-secondary truncate">
                {item.brand}
              </p>
            </div>
            <button
              onClick={() => onRemoveItem(item.id)}
              className="p-1 text-text-secondary hover:text-error premium-transition ml-2"
              aria-label={t.remove}
            >
              <Icon name="X" size={20} />
            </button>
          </div>

          {/* Variants */}
          <div className="flex flex-wrap gap-2 mb-2">
            {item.selectedSize && (
              <span className="text-xs bg-surface px-2 py-1 rounded-premium">
                {t.size}: {item.selectedSize}
              </span>
            )}
            {item.selectedColor && (
              <span className="text-xs bg-surface px-2 py-1 rounded-premium">
                {t.color}: {item.selectedColor}
              </span>
            )}
          </div>

          {/* Stock Status */}
          <p className={`text-xs font-medium mb-3 ${stockStatus.color}`}>
            {stockStatus.text}
          </p>

          {/* Price and Quantity */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="font-heading font-bold text-lg text-text-primary">
                ${item.price.toFixed(2)}
              </span>
              {item.originalPrice && item.originalPrice > item.price && (
                <span className="text-sm text-text-secondary line-through">
                  ${item.originalPrice.toFixed(2)}
                </span>
              )}
            </div>

            {/* Quantity Controls */}
            <div className="flex items-center space-x-2">
              <button
                onClick={() => handleQuantityChange(item.quantity - 1)}
                disabled={item.quantity <= 1 || isUpdating}
                className="w-8 h-8 flex items-center justify-center border border-border rounded-premium hover:border-accent disabled:opacity-50 disabled:cursor-not-allowed premium-transition"
              >
                <Icon name="Minus" size={16} />
              </button>
              
              <span className="w-8 text-center font-medium text-text-primary">
                {isUpdating ? '...' : item.quantity}
              </span>
              
              <button
                onClick={() => handleQuantityChange(item.quantity + 1)}
                disabled={item.quantity >= 10 || item.quantity >= item.stock || isUpdating}
                className="w-8 h-8 flex items-center justify-center border border-border rounded-premium hover:border-accent disabled:opacity-50 disabled:cursor-not-allowed premium-transition"
              >
                <Icon name="Plus" size={16} />
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex space-x-4 mt-3">
            <Button
              variant="ghost"
              onClick={() => onMoveToWishlist(item.id)}
              className="text-xs text-text-secondary hover:text-accent"
            >
              <Icon name="Heart" size={14} className="mr-1" />
              {t.moveToWishlist}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartItem;