import React from 'react';
import Icon from '../../../components/AppIcon';

const CartSummaryHeader = ({ itemCount, totalValue, currentLanguage }) => {
  const translations = {
    en: {
      shoppingCart: 'Shopping Cart',
      items: 'items',
      item: 'item',
      estimatedTotal: 'Estimated Total',
      continueshopping: 'Continue Shopping'
    },
    es: {
      shoppingCart: 'Carrito de Compras',
      items: 'artículos',
      item: 'artículo',
      estimatedTotal: 'Total Estimado',
      continueShop: 'Continuar Comprando'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  return (
    <div className="bg-surface border border-border rounded-premium p-6 mb-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div className="mb-4 sm:mb-0">
          <h1 className="font-heading font-bold text-2xl lg:text-3xl text-text-primary mb-2">
            {t.shoppingCart}
          </h1>
          <p className="text-text-secondary">
            {itemCount} {itemCount === 1 ? t.item : t.items} in your cart
          </p>
        </div>
        
        <div className="text-right">
          <p className="text-sm text-text-secondary mb-1">{t.estimatedTotal}</p>
          <p className="font-heading font-bold text-2xl text-accent">
            ${totalValue.toFixed(2)}
          </p>
        </div>
      </div>
      
      {/* Progress Indicator */}
      <div className="mt-6">
        <div className="flex items-center space-x-4 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 bg-accent rounded-full flex items-center justify-center">
              <Icon name="Check" size={16} className="text-accent-foreground" />
            </div>
            <span className="text-accent font-medium">Cart</span>
          </div>
          
          <div className="flex-1 h-px bg-border"></div>
          
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 border-2 border-border rounded-full flex items-center justify-center">
              <span className="text-xs text-text-secondary">2</span>
            </div>
            <span className="text-text-secondary">Checkout</span>
          </div>
          
          <div className="flex-1 h-px bg-border"></div>
          
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 border-2 border-border rounded-full flex items-center justify-center">
              <span className="text-xs text-text-secondary">3</span>
            </div>
            <span className="text-text-secondary">Payment</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartSummaryHeader;