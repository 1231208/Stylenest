import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Image from '../../../components/AppImage';

const EmptyCart = ({ currentLanguage }) => {
  const translations = {
    en: {
      emptyCart: 'Your cart is empty',
      emptyCartMessage: 'Looks like you haven\'t added anything to your cart yet. Start shopping to fill it up!',
      startShopping: 'Start Shopping',
      browseCategories: 'Browse Categories',
      trendingProducts: 'Trending Products',
      women: 'Women',
      men: 'Men',
      beauty: 'Beauty',
      children: 'Children'
    },
    es: {
      emptyCart: 'Tu carrito está vacío',
      emptyCartMessage: 'Parece que aún no has agregado nada a tu carrito. ¡Comienza a comprar para llenarlo!',
      startShopping: 'Comenzar a Comprar',
      browseCategories: 'Explorar Categorías',
      trendingProducts: 'Productos Tendencia',
      women: 'Mujeres',
      men: 'Hombres',
      beauty: 'Belleza',
      children: 'Niños'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const categories = [
    {
      name: t.women,
      path: '/product-catalog-browse?category=women',
      icon: 'User',
      image: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=300&h=200&fit=crop'
    },
    {
      name: t.men,
      path: '/product-catalog-browse?category=men',
      icon: 'User',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=200&fit=crop'
    },
    {
      name: t.beauty,
      path: '/product-catalog-browse?category=beauty',
      icon: 'Sparkles',
      image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=300&h=200&fit=crop'
    },
    {
      name: t.children,
      path: '/product-catalog-browse?category=children',
      icon: 'Baby',
      image: 'https://images.unsplash.com/photo-1503919545889-aef636e10ad4?w=300&h=200&fit=crop'
    }
  ];

  const trendingProducts = [
    {
      id: 1,
      name: "Premium Silk Dress",
      brand: "Luxury Brand",
      price: 299.99,
      image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=200&h=250&fit=crop"
    },
    {
      id: 2,
      name: "Designer Handbag",
      brand: "Fashion House",
      price: 599.99,
      image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=200&h=250&fit=crop"
    },
    {
      id: 3,
      name: "Luxury Perfume",
      brand: "Fragrance Co",
      price: 149.99,
      image: "https://images.unsplash.com/photo-1541643600914-78b084683601?w=200&h=250&fit=crop"
    }
  ];

  return (
    <div className="text-center py-12">
      {/* Empty Cart Icon */}
      <div className="w-32 h-32 mx-auto mb-8 bg-surface rounded-full flex items-center justify-center">
        <Icon name="ShoppingBag" size={64} className="text-text-secondary" />
      </div>

      {/* Empty Cart Message */}
      <h2 className="font-heading font-bold text-2xl text-text-primary mb-4">
        {t.emptyCart}
      </h2>
      <p className="text-text-secondary mb-8 max-w-md mx-auto">
        {t.emptyCartMessage}
      </p>

      {/* Start Shopping Button */}
      <Link to="/product-catalog-browse">
        <Button variant="primary" className="mb-12">
          <Icon name="ShoppingBag" size={20} className="mr-2" />
          {t.startShopping}
        </Button>
      </Link>

      {/* Browse Categories */}
      <div className="mb-12">
        <h3 className="font-heading font-semibold text-xl text-text-primary mb-6">
          {t.browseCategories}
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {categories.map((category) => (
            <Link
              key={category.path}
              to={category.path}
              className="group bg-background border border-border rounded-premium overflow-hidden premium-shadow-sm hover:premium-shadow-md premium-transition premium-hover-scale"
            >
              <div className="aspect-video overflow-hidden">
                <Image
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover group-hover:scale-105 premium-transition-long"
                />
              </div>
              <div className="p-4">
                <div className="flex items-center justify-center space-x-2">
                  <Icon name={category.icon} size={20} className="text-accent" />
                  <span className="font-medium text-text-primary group-hover:text-accent premium-transition">
                    {category.name}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Trending Products */}
      <div>
        <h3 className="font-heading font-semibold text-xl text-text-primary mb-6">
          {t.trendingProducts}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {trendingProducts.map((product) => (
            <Link
              key={product.id}
              to={`/product-detail-page?id=${product.id}`}
              className="group bg-background border border-border rounded-premium overflow-hidden premium-shadow-sm hover:premium-shadow-md premium-transition premium-hover-scale"
            >
              <div className="aspect-[4/5] overflow-hidden">
                <Image
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 premium-transition-long"
                />
              </div>
              <div className="p-4">
                <h4 className="font-heading font-semibold text-text-primary group-hover:text-accent premium-transition truncate">
                  {product.name}
                </h4>
                <p className="text-sm text-text-secondary mb-2">{product.brand}</p>
                <p className="font-bold text-accent">${product.price}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default EmptyCart;