import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const OrderSummary = ({ 
  subtotal, 
  shipping, 
  tax, 
  discount, 
  total, 
  onApplyPromoCode, 
  onProceedToCheckout,
  currentLanguage 
}) => {
  const navigate = useNavigate();
  const [promoCode, setPromoCode] = useState('');
  const [promoError, setPromoError] = useState('');
  const [isApplyingPromo, setIsApplyingPromo] = useState(false);

  const translations = {
    en: {
      orderSummary: 'Order Summary',
      subtotal: 'Subtotal',
      shipping: 'Shipping',
      tax: 'Tax',
      discount: 'Discount',
      total: 'Total',
      promoCode: 'Promo Code',
      apply: 'Apply',
      proceedToCheckout: 'Proceed to Checkout',
      freeShipping: 'Free',
      calculated: 'Calculated at checkout',
      enterPromoCode: 'Enter promo code',
      invalidPromoCode: 'Invalid promo code',
      promoApplied: 'Promo code applied successfully'
    },
    es: {
      orderSummary: 'Resumen del Pedido',
      subtotal: 'Subtotal',
      shipping: 'Envío',
      tax: 'Impuestos',
      discount: 'Descuento',
      total: 'Total',
      promoCode: 'Código Promocional',
      apply: 'Aplicar',
      proceedToCheckout: 'Proceder al Pago',
      freeShipping: 'Gratis',
      calculated: 'Calculado en el checkout',
      enterPromoCode: 'Ingresa código promocional',
      invalidPromoCode: 'Código promocional inválido',
      promoApplied: 'Código promocional aplicado exitosamente'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const handleApplyPromoCode = async () => {
    if (!promoCode.trim()) return;
    
    setIsApplyingPromo(true);
    setPromoError('');
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock promo codes
    const validPromoCodes = ['SAVE10', 'WELCOME20', 'FASHION15'];
    
    if (validPromoCodes.includes(promoCode.toUpperCase())) {
      onApplyPromoCode(promoCode.toUpperCase());
      setPromoCode('');
    } else {
      setPromoError(t.invalidPromoCode);
    }
    
    setIsApplyingPromo(false);
  };

  const handleProceedToCheckout = () => {
    navigate('/checkout');
  };

  const SummaryRow = ({ label, value, isTotal = false, isDiscount = false }) => (
    <div className={`flex justify-between items-center ${isTotal ? 'pt-3 border-t border-border' : ''}`}>
      <span className={`${isTotal ? 'font-heading font-semibold text-lg' : 'text-sm'} text-text-primary`}>
        {label}
      </span>
      <span className={`${isTotal ? 'font-heading font-bold text-lg' : 'text-sm font-medium'} ${
        isDiscount ? 'text-success' : 'text-text-primary'
      }`}>
        {isDiscount && value > 0 ? '-' : ''}${value.toFixed(2)}
      </span>
    </div>
  );

  return (
    <div className="bg-surface border border-border rounded-premium p-6 premium-shadow-sm sticky top-24">
      <h2 className="font-heading font-bold text-xl text-text-primary mb-6">
        {t.orderSummary}
      </h2>

      <div className="space-y-4 mb-6">
        <SummaryRow label={t.subtotal} value={subtotal} />
        
        <SummaryRow 
          label={t.shipping} 
          value={shipping} 
        />
        
        <SummaryRow label={t.tax} value={tax} />
        
        {discount > 0 && (
          <SummaryRow 
            label={t.discount} 
            value={discount} 
            isDiscount={true} 
          />
        )}
        
        <SummaryRow 
          label={t.total} 
          value={total} 
          isTotal={true} 
        />
      </div>

      {/* Promo Code Section */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-text-primary mb-2">
          {t.promoCode}
        </label>
        <div className="flex space-x-2">
          <Input
            type="text"
            placeholder={t.enterPromoCode}
            value={promoCode}
            onChange={(e) => {
              setPromoCode(e.target.value);
              setPromoError('');
            }}
            className="flex-1"
          />
          <Button
            variant="outline"
            onClick={handleApplyPromoCode}
            disabled={!promoCode.trim() || isApplyingPromo}
            loading={isApplyingPromo}
          >
            {t.apply}
          </Button>
        </div>
        {promoError && (
          <p className="text-xs text-error mt-1">{promoError}</p>
        )}
      </div>

      {/* Checkout Button */}
      <Button
        variant="primary"
        onClick={handleProceedToCheckout}
        fullWidth
        className="h-12 text-lg font-semibold"
      >
        <Icon name="CreditCard" size={20} className="mr-2" />
        {t.proceedToCheckout}
      </Button>

      {/* Security Badge */}
      <div className="flex items-center justify-center space-x-2 mt-4 text-xs text-text-secondary">
        <Icon name="Shield" size={16} />
        <span>Secure checkout with SSL encryption</span>
      </div>
    </div>
  );
};

export default OrderSummary;