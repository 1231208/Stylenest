import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const RecommendedProducts = ({ currentLanguage }) => {
  const translations = {
    en: {
      recommendedForYou: 'Recommended for You',
      recentlyViewed: 'Recently Viewed',
      addToCart: 'Add to Cart',
      quickView: 'Quick View'
    },
    es: {
      recommendedForYou: 'Recomendado para Ti',
      recentlyViewed: 'Visto Recientemente',
      addToCart: 'Agregar al Carrito',
      quickView: 'Vista Rápida'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const recommendedProducts = [
    {
      id: 101,
      name: "Elegant Evening Gown",
      brand: "Luxury Couture",
      price: 899.99,
      originalPrice: 1199.99,
      image: "https://images.unsplash.com/photo-1566479179817-c0b0c5c8b7d4?w=300&h=400&fit=crop",
      rating: 4.8,
      isNew: false,
      onSale: true
    },
    {
      id: 102,
      name: "Designer Leather Jacket",
      brand: "Urban Style",
      price: 449.99,
      originalPrice: null,
      image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=300&h=400&fit=crop",
      rating: 4.6,
      isNew: true,
      onSale: false
    },
    {
      id: 103,
      name: "Premium Skincare Set",
      brand: "Beauty Essentials",
      price: 199.99,
      originalPrice: 249.99,
      image: "https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=300&h=400&fit=crop",
      rating: 4.9,
      isNew: false,
      onSale: true
    },
    {
      id: 104,
      name: "Casual Summer Dress",
      brand: "Comfort Wear",
      price: 89.99,
      originalPrice: null,
      image: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=300&h=400&fit=crop",
      rating: 4.4,
      isNew: false,
      onSale: false
    }
  ];

  const recentlyViewedProducts = [
    {
      id: 201,
      name: "Classic White Sneakers",
      brand: "Sport Elite",
      price: 129.99,
      image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=300&h=400&fit=crop",
      rating: 4.5
    },
    {
      id: 202,
      name: "Silk Scarf Collection",
      brand: "Accessories Plus",
      price: 79.99,
      image: "https://images.unsplash.com/photo-1601924994987-69e26d50dc26?w=300&h=400&fit=crop",
      rating: 4.7
    },
    {
      id: 203,
      name: "Vintage Denim Jacket",
      brand: "Retro Fashion",
      price: 159.99,
      image: "https://images.unsplash.com/photo-1544966503-7cc5ac882d5f?w=300&h=400&fit=crop",
      rating: 4.3
    }
  ];

  const ProductCard = ({ product, showAddToCart = true }) => (
    <div className="group bg-background border border-border rounded-premium overflow-hidden premium-shadow-sm hover:premium-shadow-md premium-transition">
      <div className="relative aspect-[3/4] overflow-hidden">
        <Link to={`/product-detail-page?id=${product.id}`}>
          <Image
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 premium-transition-long"
          />
        </Link>
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col space-y-2">
          {product.isNew && (
            <span className="bg-accent text-accent-foreground text-xs font-medium px-2 py-1 rounded-premium">
              New
            </span>
          )}
          {product.onSale && (
            <span className="bg-error text-error-foreground text-xs font-medium px-2 py-1 rounded-premium">
              Sale
            </span>
          )}
        </div>

        {/* Quick Actions */}
        <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 premium-transition">
          <button className="w-8 h-8 bg-background bg-opacity-90 rounded-full flex items-center justify-center text-text-primary hover:text-accent premium-transition">
            <Icon name="Heart" size={16} />
          </button>
        </div>
      </div>

      <div className="p-4">
        <Link to={`/product-detail-page?id=${product.id}`}>
          <h3 className="font-heading font-semibold text-text-primary group-hover:text-accent premium-transition truncate mb-1">
            {product.name}
          </h3>
        </Link>
        
        <p className="text-sm text-text-secondary mb-2">{product.brand}</p>
        
        {/* Rating */}
        <div className="flex items-center space-x-1 mb-2">
          <div className="flex space-x-1">
            {[...Array(5)].map((_, i) => (
              <Icon
                key={i}
                name="Star"
                size={12}
                className={i < Math.floor(product.rating) ? 'text-accent fill-current' : 'text-border'}
              />
            ))}
          </div>
          <span className="text-xs text-text-secondary">({product.rating})</span>
        </div>

        {/* Price */}
        <div className="flex items-center space-x-2 mb-3">
          <span className="font-bold text-text-primary">${product.price}</span>
          {product.originalPrice && (
            <span className="text-sm text-text-secondary line-through">
              ${product.originalPrice}
            </span>
          )}
        </div>

        {/* Add to Cart Button */}
        {showAddToCart && (
          <Button
            variant="outline"
            fullWidth
            className="text-sm"
            onClick={() => console.log('Add to cart:', product.id)}
          >
            <Icon name="ShoppingBag" size={16} className="mr-2" />
            {t.addToCart}
          </Button>
        )}
      </div>
    </div>
  );

  return (
    <div className="space-y-12">
      {/* Recommended Products */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-heading font-bold text-2xl text-text-primary">
            {t.recommendedForYou}
          </h2>
          <Link
            to="/product-catalog-browse"
            className="text-accent hover:text-accent-foreground premium-transition font-medium"
          >
            View All
          </Link>
        </div>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {recommendedProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Recently Viewed */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-heading font-bold text-2xl text-text-primary">
            {t.recentlyViewed}
          </h2>
        </div>
        
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-6">
          {recentlyViewedProducts.map((product) => (
            <ProductCard key={product.id} product={product} showAddToCart={false} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default RecommendedProducts;