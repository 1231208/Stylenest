import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import GlobalHeader from '../../components/ui/GlobalHeader';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import CartSummaryHeader from './components/CartSummaryHeader';
import CartItem from './components/CartItem';
import OrderSummary from './components/OrderSummary';
import EmptyCart from './components/EmptyCart';
import RecommendedProducts from './components/RecommendedProducts';

const ShoppingCart = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [cartItems, setCartItems] = useState([]);
  const [appliedPromoCode, setAppliedPromoCode] = useState('');
  const [showUndoRemove, setShowUndoRemove] = useState(null);
  const [removedItem, setRemovedItem] = useState(null);

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
    
    // Mock cart data
    const mockCartItems = [
      {
        id: 1,
        name: "Premium Silk Evening Dress",
        brand: "Luxury Couture",
        price: 299.99,
        originalPrice: 399.99,
        quantity: 1,
        selectedSize: "M",
        selectedColor: "Black",
        image: "https://images.unsplash.com/photo-1566479179817-c0b0c5c8b7d4?w=300&h=400&fit=crop",
        stock: 5
      },
      {
        id: 2,
        name: "Designer Leather Handbag",
        brand: "Fashion House",
        price: 599.99,
        originalPrice: null,
        quantity: 1,
        selectedSize: null,
        selectedColor: "Brown",
        image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=300&h=400&fit=crop",
        stock: 3
      },
      {
        id: 3,
        name: "Luxury Perfume Set",
        brand: "Fragrance Co",
        price: 149.99,
        originalPrice: 199.99,
        quantity: 2,
        selectedSize: "50ml",
        selectedColor: null,
        image: "https://images.unsplash.com/photo-1541643600914-78b084683601?w=300&h=400&fit=crop",
        stock: 10
      }
    ];
    
    setCartItems(mockCartItems);
  }, []);

  const translations = {
    en: {
      pageTitle: 'Shopping Cart - StyleNest',
      continueShopping: 'Continue Shopping',
      bulkActions: 'Bulk Actions',
      selectAll: 'Select All',
      removeSelected: 'Remove Selected',
      moveToWishlist: 'Move to Wishlist',
      itemRemoved: 'Item removed from cart',
      undo: 'Undo',
      freeShippingMessage: 'Add ${amount} more for free shipping!',
      secureCheckout: 'Secure Checkout'
    },
    es: {
      pageTitle: 'Carrito de Compras - StyleNest',
      continueShopping: 'Continuar Comprando',
      bulkActions: 'Acciones Masivas',
      selectAll: 'Seleccionar Todo',
      removeSelected: 'Eliminar Seleccionados',
      moveToWishlist: 'Mover a Lista de Deseos',
      itemRemoved: 'Artículo eliminado del carrito',
      undo: 'Deshacer',
      freeShippingMessage: '¡Agrega ${amount} más para envío gratis!',
      secureCheckout: 'Pago Seguro'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  // Calculate totals
  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const freeShippingThreshold = 100;
  const shipping = subtotal >= freeShippingThreshold ? 0 : 9.99;
  const tax = subtotal * 0.08; // 8% tax
  
  // Apply discount based on promo code
  let discount = 0;
  if (appliedPromoCode === 'SAVE10') discount = subtotal * 0.1;
  else if (appliedPromoCode === 'WELCOME20') discount = subtotal * 0.2;
  else if (appliedPromoCode === 'FASHION15') discount = subtotal * 0.15;
  
  const total = subtotal + shipping + tax - discount;
  const itemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleUpdateQuantity = (itemId, newQuantity) => {
    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === itemId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const handleRemoveItem = (itemId) => {
    const itemToRemove = cartItems.find(item => item.id === itemId);
    setRemovedItem(itemToRemove);
    setCartItems(prevItems => prevItems.filter(item => item.id !== itemId));
    
    // Show undo option
    setShowUndoRemove(itemId);
    setTimeout(() => {
      setShowUndoRemove(null);
      setRemovedItem(null);
    }, 5000);
  };

  const handleUndoRemove = () => {
    if (removedItem) {
      setCartItems(prevItems => [...prevItems, removedItem]);
      setShowUndoRemove(null);
      setRemovedItem(null);
    }
  };

  const handleMoveToWishlist = (itemId) => {
    console.log('Move to wishlist:', itemId);
    handleRemoveItem(itemId);
  };

  const handleApplyPromoCode = (promoCode) => {
    setAppliedPromoCode(promoCode);
  };

  const handleProceedToCheckout = () => {
    console.log('Proceed to checkout with items:', cartItems);
    // Navigate to checkout page
  };

  const freeShippingRemaining = Math.max(0, freeShippingThreshold - subtotal);

  if (cartItems.length === 0) {
    return (
      <>
        <Helmet>
          <title>{t.pageTitle}</title>
          <meta name="description" content="Review and manage your StyleNest shopping cart. Premium fashion and beauty products ready for checkout." />
        </Helmet>
        
        <div className="min-h-screen bg-background">
          <GlobalHeader />
          
          <main className="pt-20 pb-12">
            <div className="max-w-screen-2xl mx-auto px-5 lg:px-8">
              <EmptyCart currentLanguage={currentLanguage} />
            </div>
          </main>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>{t.pageTitle}</title>
        <meta name="description" content="Review and manage your StyleNest shopping cart. Premium fashion and beauty products ready for checkout." />
      </Helmet>
      
      <div className="min-h-screen bg-background">
        <GlobalHeader />
        
        <main className="pt-20 pb-12">
          <div className="max-w-screen-2xl mx-auto px-5 lg:px-8">
            {/* Cart Summary Header */}
            <CartSummaryHeader
              itemCount={itemCount}
              totalValue={total}
              currentLanguage={currentLanguage}
            />

            {/* Free Shipping Progress */}
            {freeShippingRemaining > 0 && (
              <div className="bg-accent bg-opacity-10 border border-accent border-opacity-30 rounded-premium p-4 mb-6">
                <div className="flex items-center space-x-3">
                  <Icon name="Truck" size={20} className="text-accent" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-accent">
                      {t.freeShippingMessage.replace('{amount}', freeShippingRemaining.toFixed(2))}
                    </p>
                    <div className="w-full bg-background rounded-full h-2 mt-2">
                      <div 
                        className="bg-accent h-2 rounded-full premium-transition"
                        style={{ width: `${Math.min(100, (subtotal / freeShippingThreshold) * 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Undo Remove Notification */}
            {showUndoRemove && (
              <div className="bg-surface border border-border rounded-premium p-4 mb-6 flex items-center justify-between">
                <span className="text-text-primary">{t.itemRemoved}</span>
                <Button
                  variant="ghost"
                  onClick={handleUndoRemove}
                  className="text-accent hover:text-accent-foreground"
                >
                  {t.undo}
                </Button>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2">
                {/* Continue Shopping */}
                <div className="mb-6">
                  <Link
                    to="/product-catalog-browse"
                    className="inline-flex items-center space-x-2 text-accent hover:text-accent-foreground premium-transition"
                  >
                    <Icon name="ArrowLeft" size={20} />
                    <span className="font-medium">{t.continueShopping}</span>
                  </Link>
                </div>

                {/* Cart Items List */}
                <div className="space-y-4">
                  {cartItems.map((item) => (
                    <CartItem
                      key={item.id}
                      item={item}
                      onUpdateQuantity={handleUpdateQuantity}
                      onRemoveItem={handleRemoveItem}
                      onMoveToWishlist={handleMoveToWishlist}
                      currentLanguage={currentLanguage}
                    />
                  ))}
                </div>
              </div>

              {/* Order Summary */}
              <div className="lg:col-span-1">
                <OrderSummary
                  subtotal={subtotal}
                  shipping={shipping}
                  tax={tax}
                  discount={discount}
                  total={total}
                  onApplyPromoCode={handleApplyPromoCode}
                  onProceedToCheckout={handleProceedToCheckout}
                  currentLanguage={currentLanguage}
                />
              </div>
            </div>

            {/* Recommended Products */}
            <div className="mt-16">
              <RecommendedProducts currentLanguage={currentLanguage} />
            </div>
          </div>
        </main>
      </div>
    </>
  );
};

export default ShoppingCart;