import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const DashboardStats = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [stats, setStats] = useState({
    totalOrders: 24,
    activeOrders: 3,
    savedItems: 18,
    rewardPoints: 2450,
    accountCompletion: 85,
    membershipTier: 'Gold'
  });

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      totalOrders: 'Total Orders',
      activeOrders: 'Active Orders',
      savedItems: 'Saved Items',
      rewardPoints: 'Reward Points',
      accountCompletion: 'Profile Complete',
      membershipTier: 'Membership',
      viewAll: 'View All',
      manage: 'Manage',
      complete: 'Complete Profile'
    },
    es: {
      totalOrders: 'Pedidos Totales',
      activeOrders: 'Pedidos Activos',
      savedItems: 'Artículos Guardados',
      rewardPoints: 'Puntos de Recompensa',
      accountCompletion: 'Perfil Completo',
      membershipTier: 'Membresía',
      viewAll: 'Ver Todo',
      manage: 'Gestionar',
      complete: 'Completar Perfil'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const statCards = [
    {
      title: t.totalOrders,
      value: stats.totalOrders,
      icon: 'Package',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      action: t.viewAll,
      path: '/user-account-dashboard/orders'
    },
    {
      title: t.activeOrders,
      value: stats.activeOrders,
      icon: 'Truck',
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      action: t.viewAll,
      path: '/user-account-dashboard/orders'
    },
    {
      title: t.savedItems,
      value: stats.savedItems,
      icon: 'Heart',
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      action: t.manage,
      path: '/user-account-dashboard/wishlist'
    },
    {
      title: t.rewardPoints,
      value: stats.rewardPoints.toLocaleString(),
      icon: 'Star',
      color: 'text-accent',
      bgColor: 'bg-accent bg-opacity-10',
      action: t.viewAll,
      path: '/user-account-dashboard/rewards'
    }
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
      {statCards.map((card, index) => (
        <div
          key={index}
          className="bg-background border border-border rounded-premium p-4 lg:p-6 premium-shadow-sm hover:premium-shadow-md premium-transition"
        >
          <div className="flex items-center justify-between mb-3">
            <div className={`w-10 h-10 lg:w-12 lg:h-12 ${card.bgColor} rounded-premium flex items-center justify-center`}>
              <Icon name={card.icon} size={20} className={card.color} />
            </div>
            <button className="text-xs lg:text-sm text-accent hover:text-accent-foreground premium-transition">
              {card.action}
            </button>
          </div>
          <div className="space-y-1">
            <p className="text-2xl lg:text-3xl font-bold text-text-primary">{card.value}</p>
            <p className="text-xs lg:text-sm text-text-secondary">{card.title}</p>
          </div>
        </div>
      ))}
      
      {/* Profile Completion Card */}
      <div className="col-span-2 lg:col-span-4 bg-gradient-to-r from-accent to-accent-foreground rounded-premium p-4 lg:p-6 text-accent-foreground">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h3 className="font-heading font-semibold text-lg mb-2">{t.accountCompletion}</h3>
            <div className="flex items-center space-x-4">
              <div className="flex-1 bg-accent-foreground bg-opacity-20 rounded-full h-2">
                <div 
                  className="bg-accent-foreground h-2 rounded-full premium-transition"
                  style={{ width: `${stats.accountCompletion}%` }}
                />
              </div>
              <span className="text-sm font-medium">{stats.accountCompletion}%</span>
            </div>
          </div>
          <button className="ml-4 bg-accent-foreground text-accent px-4 py-2 rounded-premium text-sm font-medium hover:bg-opacity-90 premium-transition">
            {t.complete}
          </button>
        </div>
      </div>
    </div>
  );
};

export default DashboardStats;