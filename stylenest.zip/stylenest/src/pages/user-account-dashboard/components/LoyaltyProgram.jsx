import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const LoyaltyProgram = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [loyaltyData, setLoyaltyData] = useState({
    currentTier: 'Gold',
    points: 2450,
    pointsToNextTier: 550,
    nextTier: 'Platinum',
    totalSpent: 4890,
    availableRewards: [
      {
        id: 1,
        title: '10% Off Next Purchase',
        points: 500,
        description: 'Valid for 30 days on any item',
        type: 'discount'
      },
      {
        id: 2,
        title: 'Free Shipping',
        points: 200,
        description: 'Free shipping on your next order',
        type: 'shipping'
      },
      {
        id: 3,
        title: 'Exclusive Beauty Sample',
        points: 300,
        description: 'Premium skincare sample set',
        type: 'product'
      }
    ]
  });

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      loyaltyProgram: 'Loyalty Program',
      currentTier: 'Current Tier',
      rewardPoints: 'Reward Points',
      pointsToNext: 'Points to Next Tier',
      totalSpent: 'Total Spent',
      availableRewards: 'Available Rewards',
      redeemReward: 'Redeem',
      viewAllRewards: 'View All Rewards',
      earnMore: 'Earn More Points',
      tierBenefits: 'Tier Benefits',
      points: 'points',
      bronze: 'Bronze',
      silver: 'Silver',
      gold: 'Gold',
      platinum: 'Platinum',
      diamond: 'Diamond'
    },
    es: {
      loyaltyProgram: 'Programa de Lealtad',
      currentTier: 'Nivel Actual',
      rewardPoints: 'Puntos de Recompensa',
      pointsToNext: 'Puntos para Siguiente Nivel',
      totalSpent: 'Total Gastado',
      availableRewards: 'Recompensas Disponibles',
      redeemReward: 'Canjear',
      viewAllRewards: 'Ver Todas las Recompensas',
      earnMore: 'Ganar Más Puntos',
      tierBenefits: 'Beneficios del Nivel',
      points: 'puntos',
      bronze: 'Bronce',
      silver: 'Plata',
      gold: 'Oro',
      platinum: 'Platino',
      diamond: 'Diamante'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const getTierColor = (tier) => {
    switch (tier.toLowerCase()) {
      case 'bronze':
        return 'text-orange-600 bg-orange-50';
      case 'silver':
        return 'text-gray-600 bg-gray-50';
      case 'gold':
        return 'text-accent bg-accent bg-opacity-10';
      case 'platinum':
        return 'text-purple-600 bg-purple-50';
      case 'diamond':
        return 'text-blue-600 bg-blue-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const getRewardIcon = (type) => {
    switch (type) {
      case 'discount':
        return 'Percent';
      case 'shipping':
        return 'Truck';
      case 'product':
        return 'Gift';
      default:
        return 'Star';
    }
  };

  const handleRedeemReward = (rewardId) => {
    console.log('Redeem reward:', rewardId);
    // Redeem reward logic
  };

  const progressPercentage = ((loyaltyData.points / (loyaltyData.points + loyaltyData.pointsToNextTier)) * 100);

  return (
    <div className="mb-8">
      <h2 className="font-heading font-bold text-xl text-text-primary mb-6">{t.loyaltyProgram}</h2>
      
      {/* Tier Status Card */}
      <div className="bg-gradient-to-r from-accent to-accent-foreground rounded-premium p-6 text-accent-foreground mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-heading font-bold text-2xl mb-1">{loyaltyData.currentTier} Member</h3>
            <p className="text-accent-foreground text-opacity-80">
              {loyaltyData.points.toLocaleString()} {t.points} • ${loyaltyData.totalSpent.toLocaleString()} {t.totalSpent}
            </p>
          </div>
          <div className="w-16 h-16 bg-accent-foreground bg-opacity-20 rounded-full flex items-center justify-center">
            <Icon name="Crown" size={32} className="text-accent-foreground" />
          </div>
        </div>
        
        {/* Progress to Next Tier */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>{t.pointsToNext} {loyaltyData.nextTier}</span>
            <span>{loyaltyData.pointsToNextTier} {t.points}</span>
          </div>
          <div className="w-full bg-accent-foreground bg-opacity-20 rounded-full h-2">
            <div 
              className="bg-accent-foreground h-2 rounded-full premium-transition"
              style={{ width: `${progressPercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Available Rewards */}
      <div className="bg-background border border-border rounded-premium p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-heading font-semibold text-lg text-text-primary">{t.availableRewards}</h3>
          <Button variant="ghost" className="text-accent hover:text-accent-foreground">
            {t.viewAllRewards}
          </Button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {loyaltyData.availableRewards.map((reward) => (
            <div
              key={reward.id}
              className="border border-border rounded-premium p-4 hover:border-accent premium-transition"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-accent bg-opacity-10 rounded-premium flex items-center justify-center">
                  <Icon name={getRewardIcon(reward.type)} size={20} className="text-accent" />
                </div>
                <span className="text-sm font-medium text-accent">{reward.points} {t.points}</span>
              </div>
              
              <h4 className="font-semibold text-text-primary mb-2">{reward.title}</h4>
              <p className="text-sm text-text-secondary mb-4">{reward.description}</p>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleRedeemReward(reward.id)}
                className="w-full"
                disabled={loyaltyData.points < reward.points}
              >
                {t.redeemReward}
              </Button>
            </div>
          ))}
        </div>
        
        {/* Earn More Points CTA */}
        <div className="mt-6 pt-6 border-t border-border text-center">
          <p className="text-text-secondary mb-4">Want to earn more points?</p>
          <Button variant="primary" className="mr-4">
            {t.earnMore}
          </Button>
          <Button variant="ghost" className="text-accent hover:text-accent-foreground">
            {t.tierBenefits}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default LoyaltyProgram;