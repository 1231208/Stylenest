import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const PersonalizedRecommendations = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [recommendations, setRecommendations] = useState([
    {
      id: 1,
      name: 'Elegant Evening Dress',
      brand: 'Chanel',
      price: 899.99,
      originalPrice: 1199.99,
      image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400',
      rating: 4.8,
      reviews: 124,
      isOnSale: true,
      discount: 25,
      category: 'Dresses'
    },
    {
      id: 2,
      name: 'Premium Skincare Set',
      brand: 'La Mer',
      price: 299.99,
      originalPrice: null,
      image: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400',
      rating: 4.9,
      reviews: 89,
      isOnSale: false,
      discount: 0,
      category: 'Beauty'
    },
    {
      id: 3,
      name: 'Designer Leather Boots',
      brand: 'Gucci',
      price: 1299.99,
      originalPrice: null,
      image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=400',
      rating: 4.7,
      reviews: 67,
      isOnSale: false,
      discount: 0,
      category: 'Shoes'
    },
    {
      id: 4,
      name: 'Luxury Silk Scarf',
      brand: 'Hermès',
      price: 449.99,
      originalPrice: 599.99,
      image: 'https://images.unsplash.com/photo-1601924994987-69e26d50dc26?w=400',
      rating: 4.6,
      reviews: 45,
      isOnSale: true,
      discount: 25,
      category: 'Accessories'
    }
  ]);

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      recommendedForYou: 'Recommended For You',
      basedOnHistory: 'Based on your purchase history and preferences',
      viewAll: 'View All',
      addToCart: 'Add to Cart',
      addToWishlist: 'Add to Wishlist',
      reviews: 'reviews',
      review: 'review',
      off: 'off',
      sale: 'Sale'
    },
    es: {
      recommendedForYou: 'Recomendado Para Ti',
      basedOnHistory: 'Basado en tu historial de compras y preferencias',
      viewAll: 'Ver Todo',
      addToCart: 'Agregar al Carrito',
      addToWishlist: 'Agregar a Lista de Deseos',
      reviews: 'reseñas',
      review: 'reseña',
      off: 'descuento',
      sale: 'Oferta'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const handleAddToCart = (productId) => {
    console.log('Add to cart:', productId);
    // Add to cart logic
  };

  const handleAddToWishlist = (productId) => {
    console.log('Add to wishlist:', productId);
    // Add to wishlist logic
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Icon key={i} name="Star" size={14} className="text-accent fill-current" />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <Icon key="half" name="Star" size={14} className="text-accent fill-current opacity-50" />
      );
    }

    const remainingStars = 5 - Math.ceil(rating);
    for (let i = 0; i < remainingStars; i++) {
      stars.push(
        <Icon key={`empty-${i}`} name="Star" size={14} className="text-border" />
      );
    }

    return stars;
  };

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="font-heading font-bold text-xl text-text-primary mb-1">
            {t.recommendedForYou}
          </h2>
          <p className="text-sm text-text-secondary">{t.basedOnHistory}</p>
        </div>
        <Link to="/product-catalog-browse?recommended=true">
          <Button variant="ghost" className="text-accent hover:text-accent-foreground">
            {t.viewAll}
            <Icon name="ArrowRight" size={16} className="ml-2" />
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        {recommendations.map((product) => (
          <div
            key={product.id}
            className="bg-background border border-border rounded-premium overflow-hidden premium-shadow-sm hover:premium-shadow-md premium-transition group"
          >
            {/* Product Image */}
            <div className="relative aspect-square overflow-hidden bg-surface">
              <Image
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-105 premium-transition"
              />
              
              {/* Sale Badge */}
              {product.isOnSale && (
                <div className="absolute top-2 left-2 bg-error text-error-foreground px-2 py-1 rounded-premium text-xs font-medium">
                  {product.discount}% {t.off}
                </div>
              )}
              
              {/* Wishlist Button */}
              <button
                onClick={() => handleAddToWishlist(product.id)}
                className="absolute top-2 right-2 w-8 h-8 bg-background bg-opacity-80 hover:bg-opacity-100 rounded-full flex items-center justify-center premium-transition opacity-0 group-hover:opacity-100"
              >
                <Icon name="Heart" size={16} className="text-text-primary hover:text-error" />
              </button>
            </div>

            {/* Product Info */}
            <div className="p-4">
              <div className="mb-2">
                <p className="text-xs text-text-secondary font-medium">{product.brand}</p>
                <h3 className="font-medium text-text-primary text-sm lg:text-base line-clamp-2">
                  {product.name}
                </h3>
              </div>

              {/* Rating */}
              <div className="flex items-center space-x-2 mb-3">
                <div className="flex space-x-1">
                  {renderStars(product.rating)}
                </div>
                <span className="text-xs text-text-secondary">
                  ({product.reviews} {product.reviews === 1 ? t.review : t.reviews})
                </span>
              </div>

              {/* Price */}
              <div className="flex items-center space-x-2 mb-4">
                <span className="font-bold text-text-primary">
                  ${product.price}
                </span>
                {product.originalPrice && (
                  <span className="text-sm text-text-secondary line-through">
                    ${product.originalPrice}
                  </span>
                )}
              </div>

              {/* Add to Cart Button */}
              <Button
                variant="primary"
                size="sm"
                onClick={() => handleAddToCart(product.id)}
                className="w-full"
              >
                <Icon name="ShoppingCart" size={16} className="mr-2" />
                {t.addToCart}
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PersonalizedRecommendations;