import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const QuickActions = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      quickActions: 'Quick Actions',
      orderHistory: 'Order History',
      orderHistoryDesc: 'View and track your orders',
      wishlist: 'Wishlist',
      wishlistDesc: 'Manage saved items',
      addresses: 'Addresses',
      addressesDesc: 'Shipping & billing addresses',
      paymentMethods: 'Payment Methods',
      paymentMethodsDesc: 'Manage payment options',
      preferences: 'Preferences',
      preferencesDesc: 'Account settings',
      support: 'Help & Support',
      supportDesc: 'Get help and contact us'
    },
    es: {
      quickActions: 'Acciones Rápidas',
      orderHistory: 'Historial de Pedidos',
      orderHistoryDesc: 'Ver y rastrear tus pedidos',
      wishlist: 'Lista de Deseos',
      wishlistDesc: 'Gestionar artículos guardados',
      addresses: 'Direcciones',
      addressesDesc: 'Direcciones de envío y facturación',
      paymentMethods: 'Métodos de Pago',
      paymentMethodsDesc: 'Gestionar opciones de pago',
      preferences: 'Preferencias',
      preferencesDesc: 'Configuración de cuenta',
      support: 'Ayuda y Soporte',
      supportDesc: 'Obtener ayuda y contactarnos'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const actionItems = [
    {
      title: t.orderHistory,
      description: t.orderHistoryDesc,
      icon: 'Package',
      path: '/user-account-dashboard/orders',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: t.wishlist,
      description: t.wishlistDesc,
      icon: 'Heart',
      path: '/user-account-dashboard/wishlist',
      color: 'text-red-600',
      bgColor: 'bg-red-50'
    },
    {
      title: t.addresses,
      description: t.addressesDesc,
      icon: 'MapPin',
      path: '/user-account-dashboard/addresses',
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: t.paymentMethods,
      description: t.paymentMethodsDesc,
      icon: 'CreditCard',
      path: '/user-account-dashboard/payment-methods',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      title: t.preferences,
      description: t.preferencesDesc,
      icon: 'Settings',
      path: '/user-account-dashboard/preferences',
      color: 'text-gray-600',
      bgColor: 'bg-gray-50'
    },
    {
      title: t.support,
      description: t.supportDesc,
      icon: 'HelpCircle',
      path: '/user-account-dashboard/support',
      color: 'text-accent',
      bgColor: 'bg-accent bg-opacity-10'
    }
  ];

  return (
    <div className="mb-8">
      <h2 className="font-heading font-bold text-xl text-text-primary mb-6">{t.quickActions}</h2>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
        {actionItems.map((item, index) => (
          <Link
            key={index}
            to={item.path}
            className="bg-background border border-border rounded-premium p-4 lg:p-6 premium-shadow-sm hover:premium-shadow-md premium-transition group"
          >
            <div className={`w-12 h-12 ${item.bgColor} rounded-premium flex items-center justify-center mb-4 group-hover:scale-110 premium-transition`}>
              <Icon name={item.icon} size={24} className={item.color} />
            </div>
            <h3 className="font-heading font-semibold text-text-primary mb-2 group-hover:text-accent premium-transition">
              {item.title}
            </h3>
            <p className="text-sm text-text-secondary">{item.description}</p>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;