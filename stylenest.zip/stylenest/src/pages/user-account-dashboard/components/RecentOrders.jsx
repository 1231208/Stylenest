import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const RecentOrders = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [recentOrders, setRecentOrders] = useState([
    {
      id: 'ORD-2024-001',
      date: '2024-01-15',
      status: 'delivered',
      total: 299.99,
      items: [
        {
          id: 1,
          name: 'Premium Silk Blouse',
          image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400',
          price: 149.99,
          quantity: 1
        },
        {
          id: 2,
          name: 'Designer Leather Handbag',
          image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400',
          price: 149.99,
          quantity: 1
        }
      ],
      trackingNumber: 'TRK123456789'
    },
    {
      id: 'ORD-2024-002',
      date: '2024-01-12',
      status: 'shipped',
      total: 189.99,
      items: [
        {
          id: 3,
          name: 'Luxury Face Cream Set',
          image: 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400',
          price: 89.99,
          quantity: 1
        },
        {
          id: 4,
          name: 'Premium Lipstick Collection',
          image: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=400',
          price: 99.99,
          quantity: 1
        }
      ],
      trackingNumber: 'TRK987654321'
    },
    {
      id: 'ORD-2024-003',
      date: '2024-01-10',
      status: 'processing',
      total: 449.99,
      items: [
        {
          id: 5,
          name: 'Designer Winter Coat',
          image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400',
          price: 449.99,
          quantity: 1
        }
      ],
      trackingNumber: null
    }
  ]);

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
  }, []);

  const translations = {
    en: {
      recentOrders: 'Recent Orders',
      viewAllOrders: 'View All Orders',
      orderNumber: 'Order',
      orderDate: 'Ordered on',
      status: 'Status',
      total: 'Total',
      items: 'items',
      item: 'item',
      trackOrder: 'Track Order',
      reorder: 'Reorder',
      viewDetails: 'View Details',
      delivered: 'Delivered',
      shipped: 'Shipped',
      processing: 'Processing',
      cancelled: 'Cancelled',
      noOrders: 'No recent orders found',
      startShopping: 'Start Shopping'
    },
    es: {
      recentOrders: 'Pedidos Recientes',
      viewAllOrders: 'Ver Todos los Pedidos',
      orderNumber: 'Pedido',
      orderDate: 'Pedido el',
      status: 'Estado',
      total: 'Total',
      items: 'artículos',
      item: 'artículo',
      trackOrder: 'Rastrear Pedido',
      reorder: 'Reordenar',
      viewDetails: 'Ver Detalles',
      delivered: 'Entregado',
      shipped: 'Enviado',
      processing: 'Procesando',
      cancelled: 'Cancelado',
      noOrders: 'No se encontraron pedidos recientes',
      startShopping: 'Comenzar a Comprar'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const getStatusColor = (status) => {
    switch (status) {
      case 'delivered':
        return 'text-green-600 bg-green-50';
      case 'shipped':
        return 'text-blue-600 bg-blue-50';
      case 'processing':
        return 'text-yellow-600 bg-yellow-50';
      case 'cancelled':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(currentLanguage === 'es' ? 'es-ES' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleTrackOrder = (trackingNumber) => {
    console.log('Track order:', trackingNumber);
  };

  const handleReorder = (orderId) => {
    console.log('Reorder:', orderId);
  };

  if (recentOrders.length === 0) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-heading font-bold text-xl text-text-primary">{t.recentOrders}</h2>
        </div>
        <div className="bg-background border border-border rounded-premium p-8 text-center">
          <Icon name="Package" size={48} className="text-text-secondary mx-auto mb-4" />
          <h3 className="font-heading font-semibold text-text-primary mb-2">{t.noOrders}</h3>
          <Link to="/product-catalog-browse">
            <Button variant="primary">{t.startShopping}</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="font-heading font-bold text-xl text-text-primary">{t.recentOrders}</h2>
        <Link to="/user-account-dashboard/orders">
          <Button variant="ghost" className="text-accent hover:text-accent-foreground">
            {t.viewAllOrders}
            <Icon name="ArrowRight" size={16} className="ml-2" />
          </Button>
        </Link>
      </div>

      <div className="space-y-4 lg:space-y-6">
        {recentOrders.map((order) => (
          <div
            key={order.id}
            className="bg-background border border-border rounded-premium p-4 lg:p-6 premium-shadow-sm"
          >
            {/* Order Header */}
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4 pb-4 border-b border-border">
              <div className="space-y-2 lg:space-y-0 lg:flex lg:items-center lg:space-x-6">
                <div>
                  <p className="font-semibold text-text-primary">{t.orderNumber} #{order.id}</p>
                  <p className="text-sm text-text-secondary">{t.orderDate} {formatDate(order.date)}</p>
                </div>
                <div className="flex items-center space-x-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                    {t[order.status]}
                  </span>
                  <span className="font-semibold text-text-primary">${order.total}</span>
                </div>
              </div>
              
              <div className="flex items-center space-x-2 mt-4 lg:mt-0">
                {order.trackingNumber && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleTrackOrder(order.trackingNumber)}
                  >
                    {t.trackOrder}
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleReorder(order.id)}
                >
                  {t.reorder}
                </Button>
              </div>
            </div>

            {/* Order Items */}
            <div className="space-y-3">
              {order.items.slice(0, 2).map((item) => (
                <div key={item.id} className="flex items-center space-x-4">
                  <div className="w-16 h-16 lg:w-20 lg:h-20 rounded-premium overflow-hidden bg-surface">
                    <Image
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-text-primary truncate">{item.name}</h4>
                    <p className="text-sm text-text-secondary">
                      {t.quantity}: {item.quantity} • ${item.price}
                    </p>
                  </div>
                </div>
              ))}
              
              {order.items.length > 2 && (
                <p className="text-sm text-text-secondary pl-20 lg:pl-24">
                  +{order.items.length - 2} more {order.items.length - 2 === 1 ? t.item : t.items}
                </p>
              )}
            </div>

            {/* View Details Link */}
            <div className="mt-4 pt-4 border-t border-border">
              <Link
                to={`/user-account-dashboard/orders/${order.id}`}
                className="text-accent hover:text-accent-foreground text-sm font-medium premium-transition"
              >
                {t.viewDetails} →
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentOrders;