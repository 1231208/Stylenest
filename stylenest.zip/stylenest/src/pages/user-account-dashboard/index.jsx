import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import GlobalHeader from '../../components/ui/GlobalHeader';
import AccountSidebar from '../../components/ui/AccountSidebar';
import DashboardStats from './components/DashboardStats';
import QuickActions from './components/QuickActions';
import RecentOrders from './components/RecentOrders';
import PersonalizedRecommendations from './components/PersonalizedRecommendations';
import LoyaltyProgram from './components/LoyaltyProgram';
import Icon from '../../components/AppIcon';

const UserAccountDashboard = () => {
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [userInfo, setUserInfo] = useState({
    name: 'Sarah Johnson',
    email: 'sarah.johnson@example.com',
    avatar: null,
    memberSince: '2022-03-15'
  });

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') || 'en';
    setCurrentLanguage(savedLanguage);
    
    const savedUserInfo = localStorage.getItem('userInfo');
    if (savedUserInfo) {
      setUserInfo(JSON.parse(savedUserInfo));
    }
  }, []);

  const translations = {
    en: {
      pageTitle: 'My Account Dashboard - StyleNest',
      dashboard: 'Dashboard',
      welcome: 'Welcome back',
      memberSince: 'Member since',
      menu: 'Menu'
    },
    es: {
      pageTitle: 'Panel de Mi Cuenta - StyleNest',
      dashboard: 'Panel',
      welcome: 'Bienvenido de nuevo',
      memberSince: 'Miembro desde',
      menu: 'Menú'
    }
  };

  const t = translations[currentLanguage] || translations.en;

  const formatMemberSince = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(currentLanguage === 'es' ? 'es-ES' : 'en-US', {
      year: 'numeric',
      month: 'long'
    });
  };

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <div className="min-h-screen bg-surface">
      <Helmet>
        <title>{t.pageTitle}</title>
        <meta name="description" content="Manage your StyleNest account, view orders, track shipments, and access personalized recommendations." />
      </Helmet>

      <GlobalHeader />

      <div className="pt-16 lg:pt-18">
        <div className="max-w-screen-2xl mx-auto px-5 lg:px-8 py-6 lg:py-8">
          <div className="flex flex-col lg:flex-row gap-6 lg:gap-8">
            {/* Mobile Sidebar Toggle */}
            <div className="lg:hidden">
              <button
                onClick={toggleSidebar}
                className="flex items-center space-x-2 p-3 bg-background border border-border rounded-premium w-full text-left premium-shadow-sm"
              >
                <Icon name="Menu" size={20} className="text-text-primary" />
                <span className="font-medium text-text-primary">{t.menu}</span>
              </button>
            </div>

            {/* Sidebar */}
            <div className={`
              lg:block lg:sticky lg:top-24 lg:h-fit
              ${isSidebarOpen ? 'block' : 'hidden'}
            `}>
              <AccountSidebar />
            </div>

            {/* Mobile Sidebar Overlay */}
            {isSidebarOpen && (
              <div 
                className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-navigation-overlay"
                onClick={() => setIsSidebarOpen(false)}
              />
            )}

            {/* Main Content */}
            <div className="flex-1 min-w-0">
              {/* Welcome Section */}
              <div className="bg-background border border-border rounded-premium p-6 lg:p-8 premium-shadow-sm mb-6 lg:mb-8">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="font-heading font-bold text-2xl lg:text-3xl text-text-primary mb-2">
                      {t.welcome}, {userInfo.name.split(' ')[0]}!
                    </h1>
                    <p className="text-text-secondary">
                      {t.memberSince} {formatMemberSince(userInfo.memberSince)}
                    </p>
                  </div>
                  <div className="hidden lg:block w-16 h-16 bg-accent rounded-full flex items-center justify-center">
                    {userInfo.avatar ? (
                      <img
                        src={userInfo.avatar}
                        alt={userInfo.name}
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <Icon name="User" size={32} className="text-accent-foreground" />
                    )}
                  </div>
                </div>
              </div>

              {/* Dashboard Stats */}
              <DashboardStats />

              {/* Quick Actions */}
              <QuickActions />

              {/* Recent Orders */}
              <RecentOrders />

              {/* Personalized Recommendations */}
              <PersonalizedRecommendations />

              {/* Loyalty Program */}
              <LoyaltyProgram />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserAccountDashboard;