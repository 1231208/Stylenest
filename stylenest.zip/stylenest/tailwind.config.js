/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html"
  ],
  theme: {
    extend: {
      colors: {
        // Primary Colors
        'primary': '#1A1A1A', // deep-charcoal
        'primary-foreground': '#FEFEFE', // warm-white
        
        // Secondary Colors
        'secondary': '#6B7280', // balanced-gray
        'secondary-foreground': '#FEFEFE', // warm-white
        
        // Accent Colors
        'accent': '#D4AF37', // refined-gold
        'accent-foreground': '#1A1A1A', // deep-charcoal
        
        // Background Colors
        'background': '#FEFEFE', // warm-white
        'surface': '#F8F9FA', // subtle-off-white
        
        // Text Colors
        'text-primary': '#111827', // near-black
        'text-secondary': '#6B7280', // medium-gray
        
        // Status Colors
        'success': '#059669', // professional-green
        'success-foreground': '#FEFEFE', // warm-white
        
        'warning': '#D97706', // sophisticated-amber
        'warning-foreground': '#FEFEFE', // warm-white
        
        'error': '#DC2626', // clear-red
        'error-foreground': '#FEFEFE', // warm-white
        
        // Border Colors
        'border': '#E5E7EB', // hairline-border
        'border-light': '#F3F4F6', // light-border
      },
      fontFamily: {
        'heading': ['Inter', 'system-ui', 'sans-serif'],
        'body': ['Inter', 'system-ui', 'sans-serif'],
        'caption': ['Inter', 'system-ui', 'sans-serif'],
        'data': ['JetBrains Mono', 'Consolas', 'monospace'],
      },
      fontWeight: {
        'normal': '400',
        'medium': '500',
        'semibold': '600',
        'bold': '700',
      },
      fontSize: {
        'xs': ['0.75rem', { lineHeight: '1rem' }],
        'sm': ['0.875rem', { lineHeight: '1.25rem' }],
        'base': ['1rem', { lineHeight: '1.5rem' }],
        'lg': ['1.125rem', { lineHeight: '1.75rem' }],
        'xl': ['1.25rem', { lineHeight: '1.75rem' }],
        '2xl': ['1.5rem', { lineHeight: '2rem' }],
        '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
        '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
        '5xl': ['3rem', { lineHeight: '1' }],
        '6xl': ['3.75rem', { lineHeight: '1' }],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '128': '32rem',
      },
      borderRadius: {
        'premium': '8px',
        'lg': '12px',
        'xl': '16px',
      },
      boxShadow: {
        'premium-sm': '0 1px 3px rgba(0, 0, 0, 0.1)',
        'premium-md': '0 4px 6px rgba(0, 0, 0, 0.05)',
        'premium-lg': '0 10px 15px rgba(0, 0, 0, 0.1)',
        'premium-elevation': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
      },
      animation: {
        'fade-in': 'fadeIn 150ms ease-out',
        'fade-out': 'fadeOut 150ms ease-in',
        'scale-in': 'scaleIn 200ms cubic-bezier(0.4, 0.0, 0.2, 1)',
        'slide-up': 'slideUp 300ms cubic-bezier(0.4, 0.0, 0.2, 1)',
        'slide-down': 'slideDown 300ms cubic-bezier(0.4, 0.0, 0.2, 1)',
        'elastic': 'elastic 300ms cubic-bezier(0.68, -0.55, 0.265, 1.55)',
        'shimmer': 'shimmer 1.5s infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        fadeOut: {
          '0%': { opacity: '1' },
          '100%': { opacity: '0' },
        },
        scaleIn: {
          '0%': { transform: 'scale(0.95)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideDown: {
          '0%': { transform: 'translateY(-10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        elastic: {
          '0%': { transform: 'scale(1)' },
          '50%': { transform: 'scale(1.1)' },
          '100%': { transform: 'scale(1)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
      transitionTimingFunction: {
        'premium': 'cubic-bezier(0.4, 0.0, 0.2, 1)',
        'elastic': 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
      },
      zIndex: {
        'navigation': '1000',
        'navigation-menu': '1010',
        'navigation-overlay': '1020',
        'modal': '1030',
      },
      backdropBlur: {
        'loading': '8px',
      },
    },
  },
  plugins: [
    require('@tailwindcss/typography'),
    require('@tailwindcss/forms'),
    require('@tailwindcss/aspect-ratio'),
  ],
}